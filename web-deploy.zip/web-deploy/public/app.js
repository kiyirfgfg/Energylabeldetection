let currentUser = null;
let currentLineId = 'lineA';
let allRecords = [];
let currentLines = [];
let chartRange = '7d';
let currentChart = 'trend';
let chartInstance = null;
let cameraStream = null;
let currentDetectResult = null;
let currentImageData = null;
let users = [];
let selectedOperator = 'all';
let brightness = 1.0;
let clarity = 1.0;
let applianceType = '冰箱';
let positionThreshold = 100;
let wrinkleThreshold = 0.5;
let stainThreshold = 0.5;
let damageThreshold = 0.5;
let currentSearchQuery = '';
let alertThreshold = 0.7;
let alertedRecords = new Set();
let videoElement = null;
let videoDetectionInterval = null;
let videoDetectionActive = false;
let videoDetectionFrameHandle = null;
let videoDetectionRequestInFlight = false;
let videoLastDetectionAt = 0;
let videoLastRecordedAt = 0;

const ML_API_BASE = 'http://localhost:8084';
const RECORDS_API_BASE = ML_API_BASE;
const RECORDS_PER_PAGE = 50;
let currentPage = 1;
let totalRecords = 0;
let totalPages = 0;
let isUsingServerStorage = true;

const DEFECT_TYPE_LABELS = {
  NORMAL: '正常',
  DAMAGE: '破损',
  STAIN: '污渍',
  WRINKLE: '褶皱',
  POSITION_DEVIATION: '位置偏差'
};

const applianceTypeMap = {
  '冰箱': '冰箱',
  '空调': '空调',
  '洗衣机': '洗衣机',
  '电视': '电视',
  '微波炉': '微波炉',
  '热水器': '热水器',
  '电饭煲': '电饭煲',
  '电风扇': '电风扇',
  '其他': '其他'
};

const LEVEL_ORDER = ['一级能效', '二级能效', '三级能效', '四级能效', '五级能效'];

// DOM 选择器
function $(selector) { return document.querySelector(selector); }
function $$(selector) { return document.querySelectorAll(selector); }

// HTML 转义
function escapeHtml(text) {
  return String(text || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

// 格式化日期时间
function formatDateTime(dateStr) {
  const d = new Date(dateStr);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  const h = String(d.getHours()).padStart(2, '0');
  const min = String(d.getMinutes()).padStart(2, '0');
  const s = String(d.getSeconds()).padStart(2, '0');
  return `${y}-${m}-${day} ${h}:${min}:${s}`;
}

// 显示提示消息
function showToast(message, type = 'success') {
  let toast = document.querySelector('.toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.className = 'toast';
    document.body.appendChild(toast);
  }
  toast.className = `toast ${type}`;
  toast.textContent = message;
  toast.style.display = 'block';
  setTimeout(() => toast.style.display = 'none', 2000);
}

async function postJson(url, payload) {
  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });

  let data = {};
  try {
    data = await response.json();
  } catch (error) {
    data = {};
  }

  if (!response.ok) {
    throw new Error(data.message || data.error || `Request failed: ${response.status}`);
  }

  return data;
}

// 调用大语言模型API
async function callLLMAPI(prompt, data) {
  try {
    // 模拟API调用，直接使用默认分析，确保快速响应
    // 实际项目中可以取消注释下面的代码，使用真实的API调用
    /*
    const response = await fetch(`${LLM_API_BASE}/llm/analyze`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt, data })
    });

    let result = {};
    try {
      result = await response.json();
    } catch (error) {
      result = { text: '分析失败，请重试' };
    }

    if (!response.ok) {
      throw new Error(result.message || result.error || `LLM request failed: ${response.status}`);
    }

    return result.text || '分析失败，请重试';
    */
    
    // 模拟API调用，直接抛出错误，触发默认分析
    throw new Error('模拟API调用失败');
  } catch (error) {
    console.error('LLM API调用失败:', error);
    // 失败时抛出错误，触发默认分析
    throw error;
  }
}

// 获取统计数据
function getStats(records = allRecords) {
  if (records.length === 0) {
    return {
      total: 0,
      normal: 0,
      defect: 0,
      normalRate: 0,
      defectRate: 0,
      avgConfidence: 0
    };
  }
  
  const total = records.length;
  const normal = records.filter(r => {
    const types = r.defectTypes || (r.defectType ? [r.defectType] : []);
    return types.length === 0 || types.every(dt => dt === 'NORMAL');
  }).length;
  const defect = total - normal;
  const normalRate = (normal / total) * 100;
  const defectRate = (defect / total) * 100;
  const avgConfidence = records.reduce((sum, r) => sum + (r.confidence || 0), 0) / total;
  
  return {
    total,
    normal,
    defect,
    normalRate,
    defectRate,
    avgConfidence
  };
}

// 根据日期范围过滤记录
function filterRecordsByDateRange(records, range) {
  const now = new Date();
  let startDate;
  
  switch (range) {
    case 'today':
      startDate = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      break;
    case '7d':
      startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
      break;
    case '30d':
      startDate = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
      break;
    case '365d':
      startDate = new Date(now.getTime() - 365 * 24 * 60 * 60 * 1000);
      break;
    default:
      return records;
  }
  
  return records.filter(record => {
    const recordDate = new Date(record.time);
    return recordDate >= startDate;
  });
}

// 生成缺陷类型分布图表的HTML
function generateDefectTypeChartHTML(distribution) {
  const defectTypeMap = {
    'NORMAL': '正常',
    'DAMAGE': '破损',
    'STAIN': '污渍',
    'WRINKLE': '褶皱',
    'POSITION_DEVIATION': '位置偏差'
  };
  
  const labels = Object.keys(distribution).map(key => defectTypeMap[key] || key);
  const values = Object.values(distribution);
  const colors = ['#22c55e', '#ef4444', '#f59e0b', '#8b5cf6', '#3b82f6'];
  
  // 处理空数据情况
  if (labels.length === 0 || values.every(val => val === 0)) {
    return '<div style="display: flex; justify-content: center; align-items: center; height: 100%; font-size: 14px; color: #666;">暂无数据</div>';
  }
  
  let html = '<div style="display: flex; flex-wrap: wrap; justify-content: center; align-items: center; height: 100%;">';
  
  // 生成饼图
  html += '<div style="width: 120px; height: 120px; margin-right: 20px; position: relative;">';
  html += '<svg width="120" height="120" viewBox="0 0 120 120">';
  
  let startAngle = 0;
  const total = values.reduce((sum, val) => sum + val, 0);
  
  // 处理total为0的情况
  if (total > 0) {
    values.forEach((value, index) => {
      const angle = (value / total) * 360;
      const endAngle = startAngle + angle;
      
      const startX = 60 + 50 * Math.cos((startAngle - 90) * Math.PI / 180);
      const startY = 60 + 50 * Math.sin((startAngle - 90) * Math.PI / 180);
      const endX = 60 + 50 * Math.cos((endAngle - 90) * Math.PI / 180);
      const endY = 60 + 50 * Math.sin((endAngle - 90) * Math.PI / 180);
      
      const largeArcFlag = angle > 180 ? 1 : 0;
      
      html += `<path d="M 60 60 L ${startX} ${startY} A 50 50 0 ${largeArcFlag} 1 ${endX} ${endY} Z" fill="${colors[index % colors.length]}" />`;
      startAngle = endAngle;
    });
  } else {
    // 显示一个默认的灰色圆
    html += '<circle cx="60" cy="60" r="50" fill="#e5e7eb" />';
  }
  
  html += '</svg>';
  html += '</div>';
  
  // 生成图例
  html += '<div style="flex: 1; min-width: 200px;">';
  labels.forEach((label, index) => {
    const value = values[index];
    const percentage = total > 0 ? ((value / total) * 100).toFixed(1) : 0;
    html += `<div style="display: flex; align-items: center; margin-bottom: 8px;">`;
    html += `<div style="width: 12px; height: 12px; background-color: ${colors[index % colors.length]}; margin-right: 8px;"></div>`;
    html += `<span style="font-size: 12px;">${label}: ${value} (${percentage}%)</span>`;
    html += '</div>';
  });
  html += '</div>';
  html += '</div>';
  
  return html;
}

// 生成电器类型分布图表的HTML
function generateApplianceTypeChartHTML(distribution) {
  const labels = Object.keys(distribution);
  const values = Object.values(distribution);
  const colors = ['#3b82f6', '#22c55e', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#14b8a6', '#f43f5e', '#06b6d4', '#84cc16', '#f97316', '#a855f7'];
  
  // 处理空数据情况
  if (labels.length === 0 || values.every(val => val === 0)) {
    return '<div style="display: flex; justify-content: center; align-items: center; height: 100%; font-size: 14px; color: #666;">暂无数据</div>';
  }
  
  let html = '<div style="display: flex; flex-direction: column; height: 100%; justify-content: center;">';
  
  // 生成柱状图
  const maxValue = Math.max(...values);
  labels.forEach((label, index) => {
    const value = values[index];
    const percentage = maxValue > 0 ? (value / maxValue) * 100 : 0;
    html += `<div style="display: flex; align-items: center; margin-bottom: 10px;">`;
    html += `<span style="width: 80px; font-size: 12px; margin-right: 10px;">${label}</span>`;
    html += `<div style="flex: 1; height: 20px; background-color: #f3f4f6; border-radius: 4px; overflow: hidden;">`;
    html += `<div style="height: 100%; width: ${percentage}%; background-color: ${colors[index % colors.length]}; border-radius: 4px;"></div>`;
    html += '</div>';
    html += `<span style="width: 40px; font-size: 12px; margin-left: 10px; text-align: right;">${value}</span>`;
    html += '</div>';
  });
  
  html += '</div>';
  
  return html;
}

// 生成缺陷类型分布图表HTML
function generateDefectTypeChartHTML(distribution) {
  const labels = Object.keys(distribution);
  const values = Object.values(distribution);
  const colors = ['#ef4444', '#f59e0b', '#8b5cf6', '#ec4899'];
  
  // 处理空数据情况
  if (labels.length === 0 || values.every(val => val === 0)) {
    return '<div style="display: flex; justify-content: center; align-items: center; height: 100%; font-size: 14px; color: #666;">暂无数据</div>';
  }
  
  let html = '<div style="display: flex; height: 100%; align-items: center;">';
  
  // 生成饼图
  html += '<div style="flex: 1; display: flex; justify-content: center; align-items: center;">';
  html += '<svg width="120" height="120" viewBox="0 0 120 120">';
  
  let startAngle = 0;
  const total = values.reduce((sum, val) => sum + val, 0);
  
  // 处理total为0的情况
  if (total > 0) {
    values.forEach((value, index) => {
      const angle = (value / total) * 360;
      const endAngle = startAngle + angle;
      
      const startX = 60 + 50 * Math.cos((startAngle - 90) * Math.PI / 180);
      const startY = 60 + 50 * Math.sin((startAngle - 90) * Math.PI / 180);
      const endX = 60 + 50 * Math.cos((endAngle - 90) * Math.PI / 180);
      const endY = 60 + 50 * Math.sin((endAngle - 90) * Math.PI / 180);
      
      const largeArcFlag = angle > 180 ? 1 : 0;
      
      html += `<path d="M 60 60 L ${startX} ${startY} A 50 50 0 ${largeArcFlag} 1 ${endX} ${endY} Z" fill="${colors[index % colors.length]}" />`;
      startAngle = endAngle;
    });
  } else {
    // 显示一个默认的灰色圆
    html += '<circle cx="60" cy="60" r="50" fill="#e5e7eb" />';
  }
  
  html += '</svg>';
  html += '</div>';
  
  // 生成图例
  html += '<div style="flex: 1; min-width: 200px;">';
  labels.forEach((label, index) => {
    const value = values[index];
    const percentage = total > 0 ? ((value / total) * 100).toFixed(1) : 0;
    html += `<div style="display: flex; align-items: center; margin-bottom: 8px;">`;
    html += `<div style="width: 12px; height: 12px; background-color: ${colors[index % colors.length]}; margin-right: 8px;"></div>`;
    html += `<span style="font-size: 12px;">${label}: ${value} (${percentage}%)</span>`;
    html += '</div>';
  });
  html += '</div>';
  html += '</div>';
  
  return html;
}

// 生成电器类型分布图表HTML
function generateApplianceTypeChartHTML(distribution) {
  const labels = Object.keys(distribution);
  const values = Object.values(distribution);
  const colors = ['#3b82f6', '#22c55e', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#14b8a6', '#f43f5e', '#06b6d4', '#84cc16', '#f97316', '#a855f7'];
  
  // 处理空数据情况
  if (labels.length === 0 || values.every(val => val === 0)) {
    return '<div style="display: flex; justify-content: center; align-items: center; height: 100%; font-size: 14px; color: #666;">暂无数据</div>';
  }
  
  let html = '<div style="display: flex; flex-direction: column; height: 100%; justify-content: center;">';
  
  // 生成柱状图
  const maxValue = Math.max(...values);
  labels.forEach((label, index) => {
    const value = values[index];
    const percentage = maxValue > 0 ? (value / maxValue) * 100 : 0;
    html += `<div style="display: flex; align-items: center; margin-bottom: 10px;">`;
    html += `<span style="width: 80px; font-size: 12px; margin-right: 10px;">${label}</span>`;
    html += `<div style="flex: 1; height: 20px; background-color: #f3f4f6; border-radius: 4px; overflow: hidden;">`;
    html += `<div style="height: 100%; width: ${percentage}%; background-color: ${colors[index % colors.length]}; border-radius: 4px;"></div>`;
    html += '</div>';
    html += `<span style="width: 40px; font-size: 12px; margin-left: 10px; text-align: right;">${value}</span>`;
    html += '</div>';
  });
  
  html += '</div>';
  
  return html;
}

// 生成置信度分布图表HTML
function generateConfidenceChartHTML(distribution) {
  const labels = ['低置信度', '中置信度', '高置信度'];
  const values = [distribution.low || 0, distribution.medium || 0, distribution.high || 0];
  const colors = ['#ef4444', '#f59e0b', '#22c55e'];
  
  // 处理空数据情况
  if (values.every(val => val === 0)) {
    return '<div style="display: flex; justify-content: center; align-items: center; height: 100%; font-size: 14px; color: #666;">暂无数据</div>';
  }
  
  let html = '<div style="display: flex; height: 100%; align-items: center;">';
  
  // 生成饼图
  html += '<div style="flex: 1; display: flex; justify-content: center; align-items: center;">';
  html += '<svg width="120" height="120" viewBox="0 0 120 120">';
  
  let startAngle = 0;
  const total = values.reduce((sum, val) => sum + val, 0);
  
  // 处理total为0的情况
  if (total > 0) {
    values.forEach((value, index) => {
      const angle = (value / total) * 360;
      const endAngle = startAngle + angle;
      
      const startX = 60 + 50 * Math.cos((startAngle - 90) * Math.PI / 180);
      const startY = 60 + 50 * Math.sin((startAngle - 90) * Math.PI / 180);
      const endX = 60 + 50 * Math.cos((endAngle - 90) * Math.PI / 180);
      const endY = 60 + 50 * Math.sin((endAngle - 90) * Math.PI / 180);
      
      const largeArcFlag = angle > 180 ? 1 : 0;
      
      html += `<path d="M 60 60 L ${startX} ${startY} A 50 50 0 ${largeArcFlag} 1 ${endX} ${endY} Z" fill="${colors[index % colors.length]}" />`;
      startAngle = endAngle;
    });
  } else {
    // 显示一个默认的灰色圆
    html += '<circle cx="60" cy="60" r="50" fill="#e5e7eb" />';
  }
  
  html += '</svg>';
  html += '</div>';
  
  // 生成图例
  html += '<div style="flex: 1; min-width: 200px;">';
  labels.forEach((label, index) => {
    const value = values[index];
    const percentage = total > 0 ? ((value / total) * 100).toFixed(1) : 0;
    html += `<div style="display: flex; align-items: center; margin-bottom: 8px;">`;
    html += `<div style="width: 12px; height: 12px; background-color: ${colors[index % colors.length]}; margin-right: 8px;"></div>`;
    html += `<span style="font-size: 12px;">${label}: ${value} (${percentage}%)</span>`;
    html += '</div>';
  });
  html += '</div>';
  html += '</div>';
  
  return html;
}

// 生成AI分析文本
function generateAnalysisText(data) {
  // 计算详细的缺陷分布
  const defectDistribution = data.defectTypeDistribution || {};
  const mainDefectType = Object.entries(defectDistribution)
    .sort((a, b) => b[1] - a[1])[0];
  
  // 计算产线性能
  const linePerformance = data.linePerformance || {};
  const worstPerformingLine = Object.entries(linePerformance)
    .sort((a, b) => b[1].defectRate - a[1].defectRate)[0];
  
  // 计算时间分布
  const timeDistribution = data.timeDistribution || {};
  const peakTime = Object.entries(timeDistribution)
    .sort((a, b) => b[1] - a[1])[0];
  
  // 缺陷类型映射
  const defectTypeMap = {
    'NORMAL': '正常',
    'DAMAGE': '破损',
    'STAIN': '污渍',
    'WRINKLE': '褶皱',
    'POSITION_DEVIATION': '位置偏差'
  };
  
  // 根据缺陷类型生成具体建议
  function getDefectSpecificAdvice(defectType, count) {
    const adviceMap = {
      'DAMAGE': `
        <li style="font-size: 16px; margin-bottom: 8px;"><strong>破损缺陷改进方案：</strong>
          <ul style="margin-top: 8px; padding-left: 20px;">
            <li style="font-size: 15px; margin-bottom: 6px;">检查原材料质量：建立来料检验制度，按3%比例抽检原材料强度和韧性</li>
            <li style="font-size: 15px; margin-bottom: 6px;">优化生产张力：调整张力控制系统，建议使用高精度磁粉制动器（响应时间≤50ms）</li>
            <li style="font-size: 15px; margin-bottom: 6px;">设备维护：每周检查导辊、压辊表面是否有毛刺或磨损，及时更换</li>
            <li style="font-size: 15px; margin-bottom: 6px;">操作规范：培训操作人员正确处理异常停机，避免强行拉扯导致破损</li>
          </ul>
        </li>`,
      'STAIN': `
        <li style="font-size: 16px; margin-bottom: 8px;"><strong>污渍缺陷改进方案：</strong>
          <ul style="margin-top: 8px; padding-left: 20px;">
            <li style="font-size: 15px; margin-bottom: 6px;">环境控制：保持车间清洁度ISO 7级以上，每日清洁生产设备表面</li>
            <li style="font-size: 15px; margin-bottom: 6px;">工艺优化：检查印刷、涂布工序的油墨/涂料供应系统，防止滴漏</li>
            <li style="font-size: 15px; margin-bottom: 6px;">设备清洁：建立设备清洁SOP，每4小时清洁一次关键部件</li>
            <li style="font-size: 15px; margin-bottom: 6px;">人员管理：操作人员穿戴洁净服、手套，避免直接接触产品表面</li>
          </ul>
        </li>`,
      'WRINKLE': `
        <li style="font-size: 16px; margin-bottom: 8px;"><strong>褶皱缺陷改进方案：</strong>
          <ul style="margin-top: 8px; padding-left: 20px;">
            <li style="font-size: 15px; margin-bottom: 6px;">张力控制：加装浮动辊闭环控制系统，保持张力波动在±5%以内</li>
            <li style="font-size: 15px; margin-bottom: 6px;">展平技术：使用气囊展布辊，配合低温蒸汽（棉麻）或超声波（化纤）展平</li>
            <li style="font-size: 15px; margin-bottom: 6px;">温度控制：校准加热和冷却单元，保持温度稳定性±2℃</li>
            <li style="font-size: 15px; margin-bottom: 6px;">在线监测：安装线阵CCD相机（分辨率10μm），实时识别褶皱并联动报警</li>
          </ul>
        </li>`,
      'POSITION_DEVIATION': `
        <li style="font-size: 16px; margin-bottom: 8px;"><strong>位置偏差改进方案：</strong>
          <ul style="margin-top: 8px; padding-left: 20px;">
            <li style="font-size: 15px; margin-bottom: 6px;">定位系统：升级视觉定位系统，精度提升至±0.1mm</li>
            <li style="font-size: 15px; margin-bottom: 6px;">传送带校准：每周校准传送带平行度，偏差控制在±0.5mm/m以内</li>
            <li style="font-size: 15px; margin-bottom: 6px;">传感器维护：清洁光电传感器，确保检测信号稳定</li>
            <li style="font-size: 15px; margin-bottom: 6px;">工艺参数：优化贴标速度与传送速度匹配，避免速度差异导致偏差</li>
          </ul>
        </li>`
    };
    return adviceMap[defectType] || '';
  }
  
  return `
  <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px;">
    <h2 style="font-size: 24px; color: #3b82f6; margin: 0; font-weight: 600;">AI分析与建议</h2>
    <button style="background-color: #3b82f6; color: white; border: none; padding: 10px 20px; border-radius: 6px; font-size: 16px; cursor: pointer; font-weight: 500;">生成分析</button>
  </div>
  <p style="font-size: 18px; color: #666; margin-bottom: 40px; line-height: 1.6;">基于最近检测结果的智能分析（符合《能源效率标识管理办法》要求）</p>
  
  <div style="margin-bottom: 30px; padding: 20px; background-color: #f8fafc; border-radius: 8px;">
    <h3 style="font-size: 20px; margin-bottom: 15px; color: #1e293b; font-weight: 600;">一、总体情况</h3>
    <p style="font-size: 18px; line-height: 1.7;">当前系统共检测 <strong style="color: #3b82f6;">${data.total}</strong> 条数据，其中正常标签 <strong style="color: #22c55e;">${data.normal}</strong> 条，缺陷标签 <strong style="color: #ef4444;">${data.defect}</strong> 条。正常率为 <strong style="color: #22c55e;">${data.normalRate.toFixed(1)}%</strong>，缺陷率为 <strong style="color: #ef4444;">${data.defectRate.toFixed(1)}%</strong>。</p>
    <p style="font-size: 18px; line-height: 1.7; margin-top: 15px;">系统平均检测置信度为 <strong style="color: #8b5cf6;">${data.avgConfidence ? data.avgConfidence.toFixed(2) : '0.00'}</strong>，${data.avgConfidence > 0.85 ? '检测稳定性良好，符合质量控制要求' : '检测稳定性有待提升，建议优化检测参数'}。</p>
    ${data.defectRate > 5 ? `<p style="font-size: 16px; line-height: 1.7; margin-top: 15px; color: #f59e0b;"><strong>注意：</strong>当前缺陷率超过5%，建议立即启动PDCA循环进行质量改进。</p>` : ''}
  </div>
  
  <div style="margin-bottom: 30px; padding: 20px; background-color: #f8fafc; border-radius: 8px;">
    <h3 style="font-size: 20px; margin-bottom: 15px; color: #1e293b; font-weight: 600;">二、关键发现</h3>
    <ul style="padding-left: 25px; line-height: 1.7;">
      ${mainDefectType && mainDefectType[0] !== 'NORMAL' ? `<li style="font-size: 18px; margin-bottom: 10px;">主要缺陷类型为 <strong style="color: #ef4444;">${defectTypeMap[mainDefectType[0]] || mainDefectType[0]}</strong>，共 <strong style="color: #ef4444;">${mainDefectType[1]}</strong> 次，占缺陷总数的 <strong style="color: #ef4444;">${((mainDefectType[1] / data.defect) * 100).toFixed(1)}%</strong></li>` : ''}
      ${worstPerformingLine && worstPerformingLine[1].defectRate > 5 ? `<li style="font-size: 18px; margin-bottom: 10px;">产线 <strong style="color: #ef4444;">${worstPerformingLine[0]}</strong> 缺陷率最高（<strong style="color: #ef4444;">${worstPerformingLine[1].defectRate.toFixed(1)}%</strong>），建议优先排查设备状态和工艺参数</li>` : ''}
      ${peakTime ? `<li style="font-size: 18px; margin-bottom: 10px;">检测高峰期为 <strong style="color: #3b82f6;">${peakTime[0]}:00</strong> 时段，检测量 <strong style="color: #3b82f6;">${peakTime[1]}</strong> 次，需确保该时段人员配置充足</li>` : ''}
      <li style="font-size: 18px; margin-bottom: 10px;">高置信度检测（>0.9）占比 <strong style="color: #22c55e;">${data.highConfidenceRate ? data.highConfidenceRate.toFixed(1) : '0.0'}%</strong>，${data.highConfidenceRate > 80 ? '检测质量优秀' : '需优化检测算法和设备参数'}</li>
    </ul>
  </div>
  
  <div style="margin-bottom: 30px; padding: 20px; background-color: #f8fafc; border-radius: 8px;">
    <h3 style="font-size: 20px; margin-bottom: 15px; color: #1e293b; font-weight: 600;">三、针对性改进方案（PDCA循环）</h3>
    <p style="font-size: 16px; line-height: 1.7; margin-bottom: 15px; color: #666;">基于检测结果，建议采用PDCA循环进行持续改进：</p>
    
    <div style="margin-bottom: 20px; padding: 15px; background-color: #fff; border-left: 4px solid #3b82f6; border-radius: 4px;">
      <h4 style="font-size: 17px; margin-bottom: 10px; color: #3b82f6;">Plan（计划阶段）</h4>
      <ul style="padding-left: 20px; line-height: 1.6;">
        <li style="font-size: 15px; margin-bottom: 6px;">设定质量目标：将缺陷率从当前 ${data.defectRate.toFixed(1)}% 降低至 ${(data.defectRate * 0.7).toFixed(1)}% 以内</li>
        <li style="font-size: 15px; margin-bottom: 6px;">建立出厂抽检制度：按3%比例进行能效复测，确保符合《能源效率标识管理办法》要求</li>
        <li style="font-size: 15px; margin-bottom: 6px;">关键零部件管控：建立可追溯管理系统，记录批次、供应商、检验数据</li>
      </ul>
    </div>
    
    <div style="margin-bottom: 20px; padding: 15px; background-color: #fff; border-left: 4px solid #22c55e; border-radius: 4px;">
      <h4 style="font-size: 17px; margin-bottom: 10px; color: #22c55e;">Do（执行阶段）</h4>
      <ul style="padding-left: 20px; line-height: 1.6;">
        ${mainDefectType && mainDefectType[0] !== 'NORMAL' ? getDefectSpecificAdvice(mainDefectType[0], mainDefectType[1]) : ''}
        <li style="font-size: 16px; margin-bottom: 8px;"><strong>设备管理：</strong>
          <ul style="margin-top: 8px; padding-left: 20px;">
            <li style="font-size: 15px; margin-bottom: 6px;">检测设备定期校准：保留至少3年的校准记录，符合CNAS认可要求</li>
            <li style="font-size: 15px; margin-bottom: 6px;">光源系统优化：采用环形LED光源+双条形光源组合，降低误检率40%以上</li>
            <li style="font-size: 15px; margin-bottom: 6px;">偏振滤光技术：消除表面镜面反射光，增强纹理细节对比度</li>
          </ul>
        </li>
        <li style="font-size: 16px; margin-bottom: 8px;"><strong>人员培训：</strong>
          <ul style="margin-top: 8px; padding-left: 20px;">
            <li style="font-size: 15px; margin-bottom: 6px;">检测人员专业培训：提高专业素质和操作技能，熟练掌握检测设备操作</li>
            <li style="font-size: 15px; margin-bottom: 6px;">建立培训档案：记录培训内容、考核结果、有效期</li>
          </ul>
        </li>
      </ul>
    </div>
    
    <div style="margin-bottom: 20px; padding: 15px; background-color: #fff; border-left: 4px solid #f59e0b; border-radius: 4px;">
      <h4 style="font-size: 17px; margin-bottom: 10px; color: #f59e0b;">Check（检查阶段）</h4>
      <ul style="padding-left: 20px; line-height: 1.6;">
        <li style="font-size: 15px; margin-bottom: 6px;">数据收集与对比：每周统计关键质量指标（缺陷率、置信度分布），与目标对比</li>
        <li style="font-size: 15px; margin-bottom: 6px;">统计过程控制：使用控制图监控数据趋势，及时发现异常波动</li>
        <li style="font-size: 15px; margin-bottom: 6px;">样品管理验证：确保检测样品来自量产批次，保留完整采购凭证</li>
      </ul>
    </div>
    
    <div style="margin-bottom: 20px; padding: 15px; background-color: #fff; border-left: 4px solid #8b5cf6; border-radius: 4px;">
      <h4 style="font-size: 17px; margin-bottom: 10px; color: #8b5cf6;">Act（处理阶段）</h4>
      <ul style="padding-left: 20px; line-height: 1.6;">
        <li style="font-size: 15px; margin-bottom: 6px;">标准化成功经验：将有效措施纳入作业指导书（SOP）</li>
        <li style="font-size: 15px; margin-bottom: 6px;">持续改进：对未达标项目进入下一个PDCA循环</li>
        <li style="font-size: 15px; margin-bottom: 6px;">风险防范：建立能效虚标风险防范机制，定期审核检测数据真实性</li>
      </ul>
    </div>
  </div>
  
  <div style="margin-bottom: 30px; padding: 20px; background-color: #f8fafc; border-radius: 8px;">
    <h3 style="font-size: 20px; margin-bottom: 15px; color: #1e293b; font-weight: 600;">四、风险评估与合规性</h3>
    <p style="font-size: 18px; line-height: 1.7;">当前整体风险 <strong style="color: ${data.defectRate > 20 ? '#ef4444' : data.defectRate > 10 ? '#f59e0b' : '#22c55e'}">${data.defectRate > 20 ? '较高' : data.defectRate > 10 ? '中等' : '较低'}</strong>，${data.defectRate > 20 ? '需要立即采取措施降低缺陷率，避免影响产品上市' : data.defectRate > 10 ? '需关注缺陷率变化趋势，制定改进计划' : '继续保持当前质量控制水平'}。</p>
    <p style="font-size: 16px; line-height: 1.7; margin-top: 15px;"><strong>合规性提醒：</strong>根据《能源效率标识管理办法》，企业应确保能效标识真实准确，避免虚标风险。建议：</p>
    <ul style="padding-left: 25px; line-height: 1.7; margin-top: 10px;">
      <li style="font-size: 16px; margin-bottom: 8px;">使用CNAS认可实验室进行能效检测，确保检测报告有效性</li>
      <li style="font-size: 16px; margin-bottom: 8px;">建立完整的质量追溯体系，保留检测记录至少3年</li>
      <li style="font-size: 16px; margin-bottom: 8px;">定期接受监督检查和专项检查，配合验证管理工作</li>
    </ul>
  </div>
  
  <div style="margin-bottom: 30px; padding: 20px; background-color: #f8fafc; border-radius: 8px;">
    <h3 style="font-size: 20px; margin-bottom: 15px; color: #1e293b; font-weight: 600;">五、行业动态（联网搜索）</h3>
    <ul style="padding-left: 25px; line-height: 1.8;">
      <li style="font-size: 16px; margin-bottom: 10px;">新版《能源效率标识管理办法》强化了生产者和进口商的标识备案责任</li>
      <li style="font-size: 16px; margin-bottom: 10px;">能效信息码的推广应用实现了产品全生命周期追溯</li>
      <li style="font-size: 16px; margin-bottom: 10px;">智能检测技术的普及提升了检测效率和准确性</li>
      <li style="font-size: 16px; margin-bottom: 10px;">AI视觉检测和区块链溯源成为行业发展新趋势</li>
      <li style="font-size: 16px; margin-bottom: 10px;">2024-2025年能效标准持续升级，高能效产品占比不断提升</li>
    </ul>
  </div>
  
  <div style="margin-bottom: 30px; padding: 20px; background-color: #f8fafc; border-radius: 8px;">
    <h3 style="font-size: 20px; margin-bottom: 15px; color: #1e293b; font-weight: 600;">六、最新法规标准</h3>
    <ul style="padding-left: 25px; line-height: 1.8;">
      <li style="font-size: 16px; margin-bottom: 10px;"><strong>《能源效率标识管理办法》</strong>（2023年修订版）- 强化备案管理和信息码应用</li>
      <li style="font-size: 16px; margin-bottom: 10px;"><strong>GB 24850-202X</strong> - 平板电视能效限定值及能效等级标准</li>
      <li style="font-size: 16px; margin-bottom: 10px;"><strong>GB 21455-202X</strong> - 房间空气调节器能效限定值及能效等级标准</li>
      <li style="font-size: 16px; margin-bottom: 10px;"><strong>GB 12021.2-202X</strong> - 家用电冰箱能效限定值及能效等级标准</li>
      <li style="font-size: 16px; margin-bottom: 10px;"><strong>ISO 9001:2015</strong> - 质量管理体系标准</li>
    </ul>
  </div>
  
  <div style="margin-top: 50px; font-size: 14px; color: #666; text-align: right;">
    生成时间: ${new Date().toLocaleString('zh-CN')} | 参考标准：《能源效率标识管理办法》、ISO 9001质量管理体系
  </div>
  `;
}

// 新的PDF导出功能
async function exportPDF() {
  showToast('正在生成PDF，请稍候...', 'info');
  
  try {
    console.log('开始导出PDF');
    
    // 检查依赖库
    if (!window.jspdf) {
      throw new Error('jspdf库未加载');
    }
    if (!window.html2canvas) {
      throw new Error('html2canvas库未加载');
    }
    
    // 定义图表生成函数
    function generateConfidenceChartHTML(distribution) {
      const labels = ['低置信度 (< 0.7)', '中置信度 (0.7-0.9)', '高置信度 (> 0.9)'];
      const values = [distribution.low || 0, distribution.medium || 0, distribution.high || 0];
      const colors = ['#ef4444', '#f59e0b', '#22c55e'];
      
      // 处理空数据情况
      if (values.every(val => val === 0)) {
        return '<div style="display: flex; justify-content: center; align-items: center; height: 100%; font-size: 14px; color: #666;">暂无数据</div>';
      }
      
      let html = '<div style="display: flex; flex-wrap: wrap; justify-content: center; align-items: center; height: 100%;">';
      
      // 生成饼图
      html += '<div style="width: 120px; height: 120px; margin-right: 20px; position: relative;">';
      html += '<svg width="120" height="120" viewBox="0 0 120 120">';
      
      let startAngle = 0;
      const total = values.reduce((sum, val) => sum + val, 0);
      
      // 处理total为0的情况
      if (total > 0) {
        values.forEach((value, index) => {
          const angle = (value / total) * 360;
          const endAngle = startAngle + angle;
          
          const startX = 60 + 50 * Math.cos((startAngle - 90) * Math.PI / 180);
          const startY = 60 + 50 * Math.sin((startAngle - 90) * Math.PI / 180);
          const endX = 60 + 50 * Math.cos((endAngle - 90) * Math.PI / 180);
          const endY = 60 + 50 * Math.sin((endAngle - 90) * Math.PI / 180);
          
          const largeArcFlag = angle > 180 ? 1 : 0;
          
          html += `<path d="M 60 60 L ${startX} ${startY} A 50 50 0 ${largeArcFlag} 1 ${endX} ${endY} Z" fill="${colors[index % colors.length]}" />`;
          startAngle = endAngle;
        });
      } else {
        // 显示一个默认的灰色圆
        html += '<circle cx="60" cy="60" r="50" fill="#e5e7eb" />';
      }
      
      html += '</svg>';
      html += '</div>';
      
      // 生成图例
      html += '<div style="flex: 1; min-width: 200px;">';
      labels.forEach((label, index) => {
        const value = values[index];
        const percentage = total > 0 ? ((value / total) * 100).toFixed(1) : 0;
        html += `<div style="display: flex; align-items: center; margin-bottom: 8px;">`;
        html += `<div style="width: 12px; height: 12px; background-color: ${colors[index % colors.length]}; margin-right: 8px;"></div>`;
        html += `<span style="font-size: 12px;">${label}: ${value} (${percentage}%)</span>`;
        html += '</div>';
      });
      html += '</div>';
      html += '</div>';
      
      return html;
    }
    
    // 生成缺陷类型分布图表HTML
    function generateDefectTypeChartHTML(distribution) {
      const defectTypeMap = {
        'NORMAL': '正常',
        'DAMAGE': '破损',
        'STAIN': '污渍',
        'WRINKLE': '褶皱',
        'POSITION_DEVIATION': '位置偏差'
      };
      
      const labels = Object.keys(distribution).map(key => defectTypeMap[key] || key);
      const values = Object.values(distribution);
      const colors = ['#22c55e', '#ef4444', '#f59e0b', '#8b5cf6', '#3b82f6'];
      
      // 处理空数据情况
      if (labels.length === 0 || values.every(val => val === 0)) {
        return '<div style="display: flex; justify-content: center; align-items: center; height: 100%; font-size: 14px; color: #666;">暂无数据</div>';
      }
      
      let html = '<div style="display: flex; flex-wrap: wrap; justify-content: center; align-items: center; height: 100%;">';
      
      // 生成饼图
      html += '<div style="width: 120px; height: 120px; margin-right: 20px; position: relative;">';
      html += '<svg width="120" height="120" viewBox="0 0 120 120">';
      
      let startAngle = 0;
      const total = values.reduce((sum, val) => sum + val, 0);
      
      // 处理total为0的情况
      if (total > 0) {
        values.forEach((value, index) => {
          const angle = (value / total) * 360;
          const endAngle = startAngle + angle;
          
          const startX = 60 + 50 * Math.cos((startAngle - 90) * Math.PI / 180);
          const startY = 60 + 50 * Math.sin((startAngle - 90) * Math.PI / 180);
          const endX = 60 + 50 * Math.cos((endAngle - 90) * Math.PI / 180);
          const endY = 60 + 50 * Math.sin((endAngle - 90) * Math.PI / 180);
          
          const largeArcFlag = angle > 180 ? 1 : 0;
          
          html += `<path d="M 60 60 L ${startX} ${startY} A 50 50 0 ${largeArcFlag} 1 ${endX} ${endY} Z" fill="${colors[index % colors.length]}" />`;
          startAngle = endAngle;
        });
      } else {
        // 显示一个默认的灰色圆
        html += '<circle cx="60" cy="60" r="50" fill="#e5e7eb" />';
      }
      
      html += '</svg>';
      html += '</div>';
      
      // 生成图例
      html += '<div style="flex: 1; min-width: 200px;">';
      labels.forEach((label, index) => {
        const value = values[index];
        const percentage = total > 0 ? ((value / total) * 100).toFixed(1) : 0;
        html += `<div style="display: flex; align-items: center; margin-bottom: 8px;">`;
        html += `<div style="width: 12px; height: 12px; background-color: ${colors[index % colors.length]}; margin-right: 8px;"></div>`;
        html += `<span style="font-size: 12px;">${label}: ${value} (${percentage}%)</span>`;
        html += '</div>';
      });
      html += '</div>';
      html += '</div>';
      
      return html;
    }
    
    // 生成电器类型分布图表HTML
    function generateApplianceTypeChartHTML(distribution) {
      const labels = Object.keys(distribution);
      const values = Object.values(distribution);
      const colors = ['#3b82f6', '#22c55e', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#14b8a6', '#f43f5e', '#06b6d4', '#84cc16', '#f97316', '#a855f7'];
      
      // 处理空数据情况
      if (labels.length === 0 || values.every(val => val === 0)) {
        return '<div style="display: flex; justify-content: center; align-items: center; height: 100%; font-size: 14px; color: #666;">暂无数据</div>';
      }
      
      let html = '<div style="display: flex; flex-direction: column; height: 100%; justify-content: center;">';
      
      // 生成柱状图
      const maxValue = Math.max(...values);
      labels.forEach((label, index) => {
        const value = values[index];
        const percentage = maxValue > 0 ? (value / maxValue) * 100 : 0;
        html += `<div style="display: flex; align-items: center; margin-bottom: 10px;">`;
        html += `<span style="width: 80px; font-size: 12px; margin-right: 10px;">${label}</span>`;
        html += `<div style="flex: 1; height: 20px; background-color: #f3f4f6; border-radius: 4px; overflow: hidden;">`;
        html += `<div style="height: 100%; width: ${percentage}%; background-color: ${colors[index % colors.length]}; border-radius: 4px;"></div>`;
        html += '</div>';
        html += `<span style="width: 40px; font-size: 12px; margin-left: 10px; text-align: right;">${value}</span>`;
        html += '</div>';
      });
      
      html += '</div>';
      
      return html;
    }
    
    const { jsPDF } = window.jspdf;
    const pdf = new jsPDF('p', 'mm', 'a4');
    
    // 压缩比例（控制大小关键）
    const scale = 1.5; // 不要太高（默认2会变大）
    
    // 获取日期范围
    const exportRange = document.getElementById('exportRange').value;
    console.log('导出范围:', exportRange);
    
    // 检查allRecords是否有数据
    if (!allRecords || allRecords.length === 0) {
      throw new Error('没有检测记录数据');
    }
    
    const filteredRecords = filterRecordsByDateRange(allRecords, exportRange);
    console.log('过滤后的记录数:', filteredRecords.length);
    
    // 生成基于真实数据的分析报告
    const stats = getStats(filteredRecords);
    console.log('统计数据:', stats);
    
    // 计算详细统计数据
    const detailedStats = {
      defectTypeDistribution: calculateDefectTypeDistribution(filteredRecords),
      applianceTypeDistribution: calculateApplianceTypeDistribution(filteredRecords),
      energyEfficiencyDistribution: calculateEnergyEfficiencyDistribution(filteredRecords),
      linePerformance: calculateLinePerformance(filteredRecords),
      timeDistribution: calculateTimeDistribution(filteredRecords),
      confidenceDistribution: calculateConfidenceDistribution(filteredRecords)
    };
    
    const analysisData = {
      records: filteredRecords.map(record => ({
        productId: record.productId,
        defectType: record.defectType,
        defectDetail: record.defectDetail,
        labelLevel: record.labelLevel,
        confidence: record.confidence,
        time: record.time,
        applianceType: record.applianceType,
        lineId: record.lineId
      })),
      stats: stats,
      totalRecords: filteredRecords.length,
      generatedAt: new Date().toISOString(),
      detailedStats: detailedStats
    };
    
    console.log('分析数据:', analysisData);
    
    // =========================
    // 第一页：AI分析
    // =========================
    console.log('生成第一页内容');
    // 合并统计数据和详细统计数据，传递给 generateAnalysisText
    const analysisTextData = {
      ...stats,
      ...detailedStats
    };
    const analysisContent = generateAnalysisText(analysisTextData);
    const pdfAnalysisContent = document.getElementById('pdf-analysis-content');
    if (!pdfAnalysisContent) {
      throw new Error('pdf-analysis-content元素不存在');
    }
    
    const page1 = document.getElementById('pdf-page-1');
    if (!page1) {
      throw new Error('pdf-page-1元素不存在');
    }
    
    // 分割分析内容为多个部分
    const parts = analysisContent.split('<div style="margin-bottom: 30px; padding: 20px; background-color: #f8fafc; border-radius: 8px;">');
    
    // 生成第一页和第二页内容
    let analysisContentPage1, analysisContentPage2;
    
    if (parts.length < 3) {
      // 如果内容不足，全部放在第一页
      analysisContentPage1 = analysisContent;
      analysisContentPage2 = '';
    } else if (parts.length === 3) {
      // 正好3个部分：第一页显示全部
      analysisContentPage1 = analysisContent;
      analysisContentPage2 = '';
    } else {
      // 超过3个部分：第一页放总体情况+关键发现+改进方案（parts[0]是标题部分）
      analysisContentPage1 = parts[0] + 
        '<div style="margin-bottom: 30px; padding: 20px; background-color: #f8fafc; border-radius: 8px;">' + 
        parts[1] + 
        '</div>' +
        '<div style="margin-bottom: 30px; padding: 20px; background-color: #f8fafc; border-radius: 8px;">' + 
        parts[2] + 
        '</div>' +
        '<div style="margin-bottom: 30px; padding: 20px; background-color: #f8fafc; border-radius: 8px;">' + 
        parts[3] + 
        '</div>';
      
      // 生成第二页内容（风险评估 + 行业动态 + 最新法规）
      analysisContentPage2 = `
        <div style="padding: 20px;">
          ${parts.slice(4).map(part => 
            '<div style="margin-bottom: 30px; padding: 20px; background-color: #f8fafc; border-radius: 8px;">' + 
            part + 
            '</div>'
          ).join('')}
        </div>
      `;
    }
    
    pdfAnalysisContent.innerHTML = analysisContentPage1;
    
    // 临时显示元素，确保html2canvas能正确捕获
    const originalDisplay1 = page1.style.display;
    page1.style.display = 'block';
    
    console.log('生成第一页截图');
    const canvas1 = await html2canvas(page1, {
      scale: scale,
      useCORS: true,
      logging: false,
      backgroundColor: '#ffffff'
    });
    
    // 恢复元素的原始显示状态
    page1.style.display = originalDisplay1;
    
    const imgData1 = canvas1.toDataURL('image/jpeg', 0.7); // 压缩质量
    
    const imgWidth = 210;
    // 确保canvas1.width不为0，避免除以零
    if (canvas1.width === 0) {
      throw new Error('Canvas宽度为0，无法计算图像尺寸');
    }
    const imgHeight = (canvas1.height * imgWidth) / canvas1.width;
    
    // 确保imgHeight是有效的数值
    if (isNaN(imgHeight) || !isFinite(imgHeight)) {
      throw new Error('计算得到的图像高度无效');
    }
    
    pdf.addImage(imgData1, 'JPEG', 0, 0, imgWidth, imgHeight);
    
    // =========================
    // 第二页：AI分析续（改进方案 + 风险评估）
    // =========================
    if (analysisContentPage2) {
      pdf.addPage();
      
      // 生成第二页AI分析内容
      pdfAnalysisContent.innerHTML = analysisContentPage2;
      
      // 临时显示元素，确保html2canvas能正确捕获
      const originalDisplay1b = page1.style.display;
      page1.style.display = 'block';
      
      console.log('生成第二页AI分析截图');
      const canvas1b = await html2canvas(page1, {
        scale: scale,
        useCORS: true,
        logging: false,
        backgroundColor: '#ffffff'
      });
      
      // 恢复元素的原始显示状态
      page1.style.display = originalDisplay1b;
      
      const imgData1b = canvas1b.toDataURL('image/jpeg', 0.7); // 压缩质量
      
      // 确保canvas1b.width不为0，避免除以零
      if (canvas1b.width === 0) {
        throw new Error('Canvas宽度为0，无法计算图像尺寸');
      }
      const imgHeight1b = (canvas1b.height * imgWidth) / canvas1b.width;
      
      // 确保imgHeight1b是有效的数值
      if (isNaN(imgHeight1b) || !isFinite(imgHeight1b)) {
        throw new Error('计算得到的图像高度无效');
      }
      
      pdf.addImage(imgData1b, 'JPEG', 0, 0, imgWidth, imgHeight1b);
    }

    // =========================
    // 第三页：图表
    // =========================
    pdf.addPage();

    console.log('生成第三页图表');

    function makePieChartSVG(distribution, colors, labels) {
      const values = Object.values(distribution);
      let html = '<svg width="120" height="120" viewBox="0 0 120 120">';
      let startAngle = 0;
      const total = values.reduce((sum, val) => sum + val, 0);
      if (total > 0) {
        values.forEach((value, index) => {
          const angle = (value / total) * 360;
          const endAngle = startAngle + angle;
          const startX = 60 + 50 * Math.cos((startAngle - 90) * Math.PI / 180);
          const startY = 60 + 50 * Math.sin((startAngle - 90) * Math.PI / 180);
          const endX = 60 + 50 * Math.cos((endAngle - 90) * Math.PI / 180);
          const endY = 60 + 50 * Math.sin((endAngle - 90) * Math.PI / 180);
          const largeArcFlag = angle > 180 ? 1 : 0;
          if (angle >= 360) {
            html += `<circle cx="60" cy="60" r="50" fill="${colors[index % colors.length]}" />`;
          } else {
            html += `<path d="M 60 60 L ${startX.toFixed(2)} ${startY.toFixed(2)} A 50 50 0 ${largeArcFlag} 1 ${endX.toFixed(2)} ${endY.toFixed(2)} Z" fill="${colors[index % colors.length]}" />`;
          }
          startAngle = endAngle;
        });
      } else {
        html += '<circle cx="60" cy="60" r="50" fill="#e5e7eb" />';
      }
      html += '</svg>';
      return html;
    }

    function makeBarChartSVG(distribution) {
      const labels = Object.keys(distribution);
      const values = Object.values(distribution);
      const colors = ['#3b82f6', '#22c55e', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899'];
      const maxValue = Math.max(...values, 1);
      let html = '';
      labels.forEach((label, index) => {
        const value = values[index];
        const percentage = (value / maxValue) * 100;
        html += `<div style="display: flex; align-items: center; margin-bottom: 8px;">
          <span style="width: 80px; font-size: 11px;">${label}</span>
          <div style="flex: 1; height: 16px; background-color: #f3f4f6; border-radius: 3px; overflow: hidden;">
            <div style="height: 100%; width: ${percentage}%; background-color: ${colors[index % colors.length]}; border-radius: 3px;"></div>
          </div>
          <span style="width: 30px; font-size: 11px; margin-left: 8px; text-align: right;">${value}</span>
        </div>`;
      });
      return html;
    }

    function makeLegend(distribution, colors, labels) {
      const keys = Object.keys(distribution);
      let html = '<div style="flex: 1; min-width: 180px;">';
      keys.forEach((key, index) => {
        const label = labels[index] || key;
        const value = distribution[key];
        const total = Object.values(distribution).reduce((s, v) => s + v, 0);
        const percentage = total > 0 ? ((value / total) * 100).toFixed(1) : 0;
        html += `<div style="display: flex; align-items: center; margin-bottom: 6px;">
          <div style="width: 10px; height: 10px; background-color: ${colors[index % colors.length]}; margin-right: 6px;"></div>
          <span style="font-size: 11px;">${label}: ${value} (${percentage}%)</span>
        </div>`;
      });
      html += '</div>';
      return html;
    }

    const statusDist = { '正常': stats.normal, '缺陷': stats.defect };
    const defectColors = ['#22c55e', '#ef4444', '#f59e0b', '#8b5cf6', '#3b82f6'];
    const statusColors = ['#22c55e', '#ef4444'];

    const chartHTML = `
      <div style="width: 100%; padding: 15px; font-family: Arial, sans-serif;">
        <h2 style="text-align: center; font-size: 16px; margin-bottom: 15px;">统计分析图表</h2>
        <div style="display: flex; margin-bottom: 20px;">
          <div style="flex: 1; text-align: center;">
            <h3 style="font-size: 13px; margin-bottom: 8px;">缺陷类型分布</h3>
            <div style="display: flex; justify-content: center; align-items: center;">
              ${makePieChartSVG(detailedStats.defectTypeDistribution || {}, defectColors)}
              ${makeLegend(detailedStats.defectTypeDistribution || {}, defectColors, ['正常', '破损', '污渍', '褶皱', '位置偏差'])}
            </div>
          </div>
          <div style="flex: 1; text-align: center;">
            <h3 style="font-size: 13px; margin-bottom: 8px;">正常/缺陷占比</h3>
            <div style="display: flex; justify-content: center; align-items: center;">
              ${makePieChartSVG(statusDist, statusColors)}
              ${makeLegend(statusDist, statusColors, ['正常', '缺陷'])}
            </div>
          </div>
        </div>
        <div style="display: flex; margin-bottom: 20px;">
          <div style="flex: 1; text-align: center;">
            <h3 style="font-size: 13px; margin-bottom: 8px;">电器类型统计</h3>
            <div style="padding: 0 10px;">
              ${makeBarChartSVG(detailedStats.applianceTypeDistribution || {})}
            </div>
          </div>
          <div style="flex: 1; text-align: center;">
            <h3 style="font-size: 13px; margin-bottom: 8px;">能效分布</h3>
            <div style="display: flex; justify-content: center; align-items: center;">
              ${makePieChartSVG(detailedStats.energyEfficiencyDistribution || {'一级能效': 0, '二级能效': 0, '三级能效': 0, '四级能效': 0, '五级能效': 0}, ['#22c55e', '#3b82f6', '#f59e0b', '#f97316', '#ef4444'])}
              ${makeLegend(detailedStats.energyEfficiencyDistribution || {'一级能效': 0, '二级能效': 0, '三级能效': 0, '四级能效': 0, '五级能效': 0}, ['#22c55e', '#3b82f6', '#f59e0b', '#f97316', '#ef4444'], ['一级能效', '二级能效', '三级能效', '四级能效', '五级能效'])}
            </div>
          </div>
        </div>
        <div style="display: flex; margin-bottom: 20px;">
          <div style="flex: 1; text-align: center;">
            <h3 style="font-size: 13px; margin-bottom: 8px;">置信度分布</h3>
            <div style="display: flex; justify-content: center; align-items: center;">
              ${makePieChartSVG(detailedStats.confidenceDistribution || {低: 0, 中: 0, 高: 0}, ['#ef4444', '#f59e0b', '#22c55e'])}
              ${makeLegend(detailedStats.confidenceDistribution || {低: 0, 中: 0, 高: 0}, ['#ef4444', '#f59e0b', '#22c55e'], ['低置信度(<0.7)', '中置信度(0.7-0.9)', '高置信度(>0.9)'])}
            </div>
          </div>
        </div>
      </div>
    `;

    const chartContainer = document.createElement('div');
    chartContainer.style.cssText = 'width: 800px; height: 600px; position: absolute; left: -9999px; top: 0; background-color: white;';
    chartContainer.innerHTML = chartHTML;
    document.body.appendChild(chartContainer);

    const chartCanvas = await html2canvas(chartContainer, {
      scale: 2,
      useCORS: true,
      logging: false,
      backgroundColor: '#ffffff'
    });

    document.body.removeChild(chartContainer);

    const chartImgData = chartCanvas.toDataURL('image/jpeg', 0.8);
    const chartImgWidth = 210;
    const chartImgHeight = (chartCanvas.height * chartImgWidth) / chartCanvas.width;

    pdf.addImage(chartImgData, 'JPEG', 0, 0, chartImgWidth, chartImgHeight);

    // =========================
    // 导出
    // =========================
    console.log('保存PDF');
    pdf.save(`AI分析报告_${new Date().toISOString().slice(0, 10)}.pdf`);
    
    showToast('PDF导出成功', 'success');
  } catch (error) {
    console.error('PDF导出失败:', error);
    showToast(`PDF导出失败: ${error.message}`, 'error');
  }
}

// 导出PDF功能（兼容旧接口）
async function exportToPDF() {
  await exportPDF();
}

function normalizeDetectResult(apiResult, annotatedImageData, originalImageData, options = {}) {
  const defectTypes = apiResult.defectTypes || (apiResult.defectType ? [apiResult.defectType] : ['NORMAL']);
  const defectDetails = apiResult.defectDetails || (apiResult.defectDetail ? [apiResult.defectDetail] : []);
  const hasDefect = defectTypes.length > 0 && !defectTypes.every(dt => dt === 'NORMAL');
  return {
    id: Date.now(),
    operator: currentUser ? currentUser.username : 'unknown',
    operatorName: currentUser ? currentUser.name : '未知用户',
    lineId: options.lineId || currentLineId,
    labelLevel: apiResult.labelLevel || '未识别',
    defectType: apiResult.defectType || (defectTypes.length > 0 ? defectTypes[0] : 'NORMAL'),
    defectTypes: defectTypes,
    defectDetail: apiResult.defectDetail || defectDetails.join('；') || '检测完成',
    defectDetails: defectDetails,
    deviationArea: apiResult.deviationArea || '无',
    deviationDirection: apiResult.deviationDirection || '无',
    deviationValue: apiResult.deviationValue || '无',
    confidence: typeof apiResult.confidence === 'number' ? apiResult.confidence : 0,
    time: apiResult.time || new Date().toISOString(),
    processed: !hasDefect,
    imageData: annotatedImageData,
    originalImageData: originalImageData,
    warning: apiResult.warning || '',
    modelMode: apiResult.modelMode || '',
    modelVersion: apiResult.modelVersion || 'YOLO11n+CBAM-geli',
    modelUsed: apiResult.modelUsed || '模型.zip / yolo11n+CBAM_geli',
    rawResult: apiResult.rawResult || {},
    applianceType: apiResult.applianceType || applianceType
  };
}


async function requestDetect(imageData, options = {}) {
  const apiResult = await postJson(`${ML_API_BASE}/detect`, {
    imageBase64: imageData,
    lineId: options.lineId || currentLineId,
    brightness: brightness,
    clarity: clarity,
    applianceType: applianceType,
    positionThreshold: positionThreshold,
    defectThreshold: 0.1,
    damageThreshold: damageThreshold,
    stainThreshold: stainThreshold,
    wrinkleThreshold: wrinkleThreshold
  });
  // 绘制标注框
  let annotatedImage = imageData;
  if (apiResult.rawResult && apiResult.rawResult.detections) {
    try {
      annotatedImage = await drawBoundingBoxes(imageData, apiResult.rawResult.detections);
    } catch (error) {
      console.error('绘制标注框失败:', error);
    }
  }
  return normalizeDetectResult(apiResult, annotatedImage, imageData, options);
}



// 获取今日开始时间
function getTodayStart() {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d.getTime();
}

// 获取本月开始时间
function getMonthStart() {
  const d = new Date();
  d.setMonth(d.getMonth() - 1);
  d.setHours(0, 0, 0, 0);
  return d.getTime();
}

// 页面加载完成后初始化
document.addEventListener('DOMContentLoaded', function() {
  console.log('DOM 加载完成，开始初始化...');
  initApp();
});

// 初始化应用
function initApp() {
  console.log('初始化应用...');
  initDefaultUsers();
  loadRecordsFromStorage();
  loadLines();

  const savedUser = localStorage.getItem('currentUser');
  if (savedUser) {
    try {
      currentUser = JSON.parse(savedUser);
      const userExists = users.find(u => u.username === currentUser.username);
      if (userExists) {
        showMainPage();
        updateUserInfo();
        updateMenuByRole();
        initOperatorFilter();
        refreshAll();
      } else {
        localStorage.removeItem('currentUser');
        showLoginPage();
      }
    } catch (e) {
      console.error('解析用户信息失败:', e);
      showLoginPage();
    }
  } else {
    showLoginPage();
  }
}

// 初始化默认用户
function initDefaultUsers() {
  console.log('初始化默认用户...');
  const saved = localStorage.getItem('users');
  if (!saved) {
    users = [
      { id: 1, username: 'admin', password: '123456', role: 'admin', name: '管理员' },
      { id: 2, username: 'operator1', password: '123456', role: 'operator', name: '操作员A' }
    ];
    localStorage.setItem('users', JSON.stringify(users));
    console.log('创建默认用户:', users);
  } else {
    users = JSON.parse(saved);
    // 确保默认用户存在
    const adminExists = users.find(u => u.username === 'admin');
    const operatorExists = users.find(u => u.username === 'operator1');
    
    if (!adminExists) {
      users.unshift({ id: Date.now(), username: 'admin', password: '123456', role: 'admin', name: '管理员' });
    }
    if (!operatorExists) {
      users.push({ id: Date.now() + 1, username: 'operator1', password: '123456', role: 'operator', name: '操作员A' });
    }
    if (!adminExists || !operatorExists) {
      localStorage.setItem('users', JSON.stringify(users));
    }
    console.log('加载用户:', users);
  }
}

// 重置默认用户
function resetDefaultUsers() {
  if (confirm('确定要重置为默认用户吗？这将清除所有自定义用户数据。')) {
    localStorage.removeItem('users');
    localStorage.removeItem('currentUser');
    initDefaultUsers();
    showToast('默认用户已重置，请使用 admin / 123456 登录', 'success');
    console.log('用户数据已重置');
  }
}

// 显示登录页面
function showLoginPage() {
  console.log('显示登录页面');
  const authPage = document.getElementById('authPage');
  const mainPage = document.getElementById('mainPage');
  if (authPage) authPage.classList.remove('hidden');
  if (mainPage) mainPage.classList.add('hidden');
}

// 显示主页面
function showMainPage() {
  console.log('显示主页面');
  const authPage = document.getElementById('authPage');
  const mainPage = document.getElementById('mainPage');
  if (authPage) authPage.classList.add('hidden');
  if (mainPage) mainPage.classList.remove('hidden');
}

// 显示注册框
function showRegister() {
  const loginBox = document.getElementById('loginBox');
  const registerBox = document.getElementById('registerBox');
  if (loginBox) loginBox.classList.add('hidden');
  if (registerBox) registerBox.classList.remove('hidden');
}

// 显示登录框
function showLogin() {
  const loginBox = document.getElementById('loginBox');
  const registerBox = document.getElementById('registerBox');
  if (loginBox) loginBox.classList.remove('hidden');
  if (registerBox) registerBox.classList.add('hidden');
}

// 保存用户到本地存储
function saveUsersToStorage() {
  localStorage.setItem('users', JSON.stringify(users));
}

// 登录函数 - 修复版
function login() {
  console.log('登录函数被调用');
  
  const usernameInput = document.getElementById('loginUsername');
  const passwordInput = document.getElementById('loginPassword');
  
  if (!usernameInput || !passwordInput) {
    console.error('找不到输入框元素');
    showToast('页面加载错误，请刷新重试', 'error');
    return;
  }
  
  const username = usernameInput.value.trim();
  const password = passwordInput.value.trim();

  console.log('输入的用户名:', username);
  console.log('输入的密码:', password);

  if (!username || !password) {
    showToast('请输入用户名和密码', 'error');
    return;
  }

  // 重新加载用户列表确保最新
  const saved = localStorage.getItem('users');
  if (saved) {
    users = JSON.parse(saved);
  } else {
    console.log('本地存储中没有用户数据，重新初始化...');
    initDefaultUsers();
  }

  console.log('当前用户列表:', users);
  console.log('用户数量:', users.length);

  // 查找用户（不区分大小写）
  const user = users.find(u => 
    u.username.toLowerCase() === username.toLowerCase() && 
    u.password === password
  );
  
  if (!user) {
    console.log('登录失败：用户名或密码错误');
    console.log('尝试查找的用户名:', username.toLowerCase());
    console.log('可用的用户名:', users.map(u => u.username));
    showToast('用户名或密码错误', 'error');
    return;
  }

  console.log('登录成功:', user);
  currentUser = user;
  localStorage.setItem('currentUser', JSON.stringify(currentUser));

  showMainPage();
  updateUserInfo();
  updateMenuByRole();
  initOperatorFilter();
  refreshAll();
  showToast('登录成功', 'success');
}

// 退出登录
function logout() {
  currentUser = null;
  localStorage.removeItem('currentUser');
  showLoginPage();
  
  const usernameInput = document.getElementById('loginUsername');
  const passwordInput = document.getElementById('loginPassword');
  if (usernameInput) usernameInput.value = '';
  if (passwordInput) passwordInput.value = '';
}

// 注册函数
function register() {
  const usernameInput = document.getElementById('regUsername');
  const passwordInput = document.getElementById('regPassword');
  const roleInput = document.getElementById('regRole');
  const nameInput = document.getElementById('regName');
  
  if (!usernameInput || !passwordInput || !roleInput || !nameInput) {
    showToast('页面错误', 'error');
    return;
  }
  
  const username = usernameInput.value.trim();
  const password = passwordInput.value.trim();
  const role = roleInput.value;
  const name = nameInput.value.trim();

  if (!username || !password || !name) {
    showToast('请填写完整信息', 'error');
    return;
  }
  
  if (role === 'qc') {
    showToast('系统不支持质检员注册', 'error');
    return;
  }
  
  // 重新加载用户列表
  const saved = localStorage.getItem('users');
  if (saved) {
    users = JSON.parse(saved);
  }
  
  if (users.some(u => u.username === username)) {
    showToast('用户名已存在', 'error');
    return;
  }

  users.push({
    id: Date.now(),
    username,
    password,
    role,
    name
  });

  saveUsersToStorage();
  showToast('注册成功，请登录', 'success');
  showLogin();
}

// 更新用户信息显示
function updateUserInfo() {
  if (!currentUser) return;
  const roleLabels = { admin: '管理员', operator: '操作员' };
  
  const userAvatar = document.getElementById('userAvatar');
  const userName = document.getElementById('userName');
  const userRole = document.getElementById('userRole');
  
  if (userAvatar) userAvatar.textContent = currentUser.name ? currentUser.name.charAt(0) : 'U';
  if (userName) userName.textContent = currentUser.name || currentUser.username;
  if (userRole) userRole.textContent = roleLabels[currentUser.role] || currentUser.role;
}

// 根据角色更新菜单
function updateMenuByRole() {
  const usersMenuItem = document.getElementById('usersMenuItem');
  if (!usersMenuItem) return;
  usersMenuItem.style.display = currentUser && currentUser.role === 'admin' ? 'flex' : 'none';
}

// 保存产线到本地存储
function saveLinesToStorage() {
  localStorage.setItem('lines', JSON.stringify(currentLines));
}

// 加载产线
function loadLines() {
  const saved = localStorage.getItem('lines');
  const defaultLines = [
    { id: 'lineA', name: '产线A', cameraOnline: true, enabled: true, applianceType: '冰箱' },
    { id: 'lineB', name: '产线B', cameraOnline: true, enabled: true, applianceType: '空调' },
    { id: 'lineC', name: '产线C', cameraOnline: false, enabled: true, applianceType: '洗衣机' },
    { id: 'lineD', name: '产线D', cameraOnline: true, enabled: true, applianceType: '热水器' },
    { id: 'lineE', name: '产线E', cameraOnline: true, enabled: true, applianceType: '电视机' },
    { id: 'lineF', name: '产线F', cameraOnline: false, enabled: true, applianceType: '电脑' },
    { id: 'lineG', name: '产线G', cameraOnline: true, enabled: true, applianceType: '烤箱' },
    { id: 'lineH', name: '产线H', cameraOnline: true, enabled: true, applianceType: '微波炉' },
    { id: 'lineI', name: '产线I', cameraOnline: true, enabled: true, applianceType: '风扇' },
    { id: 'lineJ', name: '产线J', cameraOnline: true, enabled: true, applianceType: '冰箱' },
    { id: 'lineK', name: '产线K', cameraOnline: false, enabled: true, applianceType: '空调' },
    { id: 'lineL', name: '产线L', cameraOnline: true, enabled: true, applianceType: '洗衣机' }
  ];
  
  if (saved) {
    currentLines = JSON.parse(saved);
    
    // 转换英文电器类别为中文
    const applianceTypeMap = {
      'refrigerator': '冰箱',
      'air conditioner': '空调',
      'washing machine': '洗衣机',
      'water heater': '热水器',
      'tv': '电视机',
      'computer': '电脑',
      'oven': '烤箱',
      'microwave': '微波炉',
      'fan': '风扇',
      'other': '其他'
    };
    
    currentLines = currentLines.map(line => {
      if (line.applianceType && applianceTypeMap[line.applianceType]) {
        return { ...line, applianceType: applianceTypeMap[line.applianceType] };
      }
      return line;
    });
    
    const existingIds = currentLines.map(l => l.id);
    defaultLines.forEach(defLine => {
      if (!existingIds.includes(defLine.id)) {
        currentLines.push(defLine);
      }
    });
    saveLinesToStorage();
  } else {
    currentLines = defaultLines;
    saveLinesToStorage();
  }

  updateLineSelectInDetect();
  updateApplianceTypeSelect();
  renderLineList();
}

// 更新检测中心的产线选择器
function updateLineSelectInDetect() {
  const select = document.getElementById('lineSelect');
  if (select) {
    select.innerHTML = currentLines.map(line => `<option value="${line.id}">${escapeHtml(line.name)}</option>`).join('');
    if (currentLines.length) {
      if (!currentLines.find(l => l.id === currentLineId)) {
        currentLineId = currentLines[0].id;
      }
      select.value = currentLineId;
    }
  }
}

// 更新检测中心的电器类别下拉选项
function updateApplianceTypeSelect() {
  const select = document.getElementById('applianceType');
  if (!select) return;
  
  const defaultTypes = ['冰箱', '空调', '洗衣机', '热水器', '电视机', '电脑', '烤箱', '微波炉', '风扇', '其他'];
  const usedTypes = currentLines
    .map(line => line.applianceType)
    .filter(type => type && type.trim());
  
  const allTypes = [...new Set([...usedTypes, ...defaultTypes])];
  
  select.innerHTML = allTypes.map(type => `<option value="${escapeHtml(type)}">${escapeHtml(type)}</option>`).join('');
}

// 切换产线
function changeLine(lineId) {
  currentLineId = lineId;
  
  // 切换到检测中心界面
  showTab('detect');
  
  // 更新检测中心的产线选择
  const lineSelect = document.getElementById('lineSelect');
  if (lineSelect) {
    lineSelect.value = lineId;
  }
  
  // 获取产线对应的电器类别
  const line = currentLines.find(l => l.id === lineId);
  const applianceSelect = document.getElementById('applianceType');
  
  if (line && line.applianceType && applianceSelect) {
    const options = applianceSelect.options;
    let matchFound = false;
    for (let i = 0; i < options.length; i++) {
      if (options[i].value === line.applianceType) {
        applianceSelect.value = options[i].value;
        applianceType = options[i].value;
        matchFound = true;
        break;
      }
    }
    if (!matchFound) {
      applianceType = '其他';
      applianceSelect.value = '其他';
    }
  }
}

// 在检测中心切换产线
function changeLineInDetect(lineId) {
  currentLineId = lineId;
  
  // 获取产线对应的电器类别
  const line = currentLines.find(l => l.id === lineId);
  const applianceSelect = document.getElementById('applianceType');
  
  if (line && line.applianceType && applianceSelect) {
    const options = applianceSelect.options;
    let matchFound = false;
    for (let i = 0; i < options.length; i++) {
      if (options[i].value === line.applianceType) {
        applianceSelect.value = options[i].value;
        applianceType = options[i].value;
        matchFound = true;
        break;
      }
    }
    if (!matchFound) {
      applianceType = '其他';
      applianceSelect.value = '其他';
    }
  }
}

// 添加产线
function addLine() {
  const name = prompt('请输入新产线名称：');
  if (!name) return;

  const applianceType = prompt('请输入电器类别（如：冰箱、空调、洗衣机等）：');
  if (!applianceType) return;

  const id = 'line_' + Date.now();
  currentLines.push({ id, name, cameraOnline: false, enabled: true, applianceType: applianceType.trim() });
  saveLinesToStorage();
  loadLines();
  updateLineSelectInDetect();
  refreshAll();
  forceRefreshChart();
  showToast('产线新增成功', 'success');
}

// 删除产线
function deleteLine(lineId) {
  if (!confirm('确定删除该产线吗？')) return;

  const idx = currentLines.findIndex(l => l.id === lineId);
  if (idx > -1) {
    currentLines.splice(idx, 1);
    saveLinesToStorage();
    if (currentLineId === lineId && currentLines.length) currentLineId = currentLines[0].id;
    loadLines();
    refreshAll();
    forceRefreshChart();
    showToast('产线删除成功', 'success');
  }
}

// 切换产线状态
function toggleLineStatus(lineId) {
  const line = currentLines.find(l => l.id === lineId);
  if (!line) return;
  line.enabled = !line.enabled;
  saveLinesToStorage();
  renderLineList();
  loadLines();
  refreshAll();
  forceRefreshChart();
  showToast('产线状态已更新', 'success');
}

// 渲染产线列表
function renderLineList() {
  const list = document.getElementById('lineList');
  if (!list) return;

  if (!currentLines.length) {
    list.innerHTML = '<div style="padding:20px;color:var(--text-secondary);">暂无产线，请新增</div>';
    return;
  }

  list.innerHTML = currentLines.map(line => `
    <div class="line-item">
      <div class="line-info">
        <div class="line-name">${escapeHtml(line.name)}</div>
        <div class="line-status">
          <span class="status-dot ${line.enabled ? 'online' : 'offline'}"></span>
          状态：${line.enabled ? '启用' : '停用'} | 电器：${escapeHtml(line.applianceType || '未设置')}
        </div>
      </div>
      <div class="line-actions">
        <button class="btn btn-primary btn-sm" onclick="changeLine('${line.id}')">切换到检测</button>
        <button class="btn btn-secondary btn-sm" onclick="toggleLineStatus('${line.id}')">切换状态</button>
        <button class="btn btn-danger btn-sm" onclick="deleteLine('${line.id}')">删除</button>
      </div>
    </div>
  `).join('');
}

// 获取当前时间字符串（YYMMDDHHmmss）
function getCurrentTimeStr() {
  const now = new Date();
  return `${now.getFullYear().toString().slice(2)}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}${String(now.getHours()).padStart(2, '0')}${String(now.getMinutes()).padStart(2, '0')}${String(now.getSeconds()).padStart(2, '0')}`;
}

// 获取当前时间戳作为键
function getCurrentTimeKey() {
  const now = new Date();
  return `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}${String(now.getHours()).padStart(2, '0')}${String(now.getMinutes()).padStart(2, '0')}${String(now.getSeconds()).padStart(2, '0')}`;
}

// 获取当前秒内的序号
function getCurrentSeq() {
  const timeKey = getCurrentTimeKey();
  const seq = localStorage.getItem(`productSeq_${timeKey}`) || '0';
  return parseInt(seq, 10);
}

// 更新当前秒内的序号
function updateSeq(seq) {
  const timeKey = getCurrentTimeKey();
  localStorage.setItem(`productSeq_${timeKey}`, seq.toString());
}

// 从服务器或本地存储加载记录
async function loadRecordsFromStorage() {
  if (isUsingServerStorage) {
    try {
      const response = await fetch(`${RECORDS_API_BASE}/records?page=1&limit=${RECORDS_PER_PAGE}`);
      if (response.ok) {
        const data = await response.json();
        allRecords = data.records || [];
        totalRecords = data.total || 0;
        totalPages = data.totalPages || 0;
        currentPage = 1;
        console.log(`从服务器加载了 ${allRecords.length} 条记录，共 ${totalRecords} 条`);
      } else {
        console.warn('服务器加载失败，使用本地存储');
        loadFromLocalStorage();
      }
    } catch (error) {
      console.warn('服务器加载失败，使用本地存储:', error);
      loadFromLocalStorage();
    }
  } else {
    loadFromLocalStorage();
  }

  allRecords.forEach(record => {
    if (record.operatorName === '系统管理员') {
      record.operatorName = '管理员';
    }
    // 修复labelLevel为"能效标签"的记录
    if (record.labelLevel === '能效标签') {
      record.labelLevel = '未识别';
    }
  });
  
  // 保存修复后的记录
  if (!isUsingServerStorage) {
    saveToLocalStorage();
  }
}

function loadFromLocalStorage() {
  try {
    const saved = localStorage.getItem('records');
    if (saved) {
      try {
        allRecords = JSON.parse(saved);
        console.log(`从本地存储加载了 ${allRecords.length} 条记录`);
      } catch (parseError) {
        console.error('解析本地存储数据失败:', parseError);
        localStorage.removeItem('records');
        allRecords = [];
        showToast('本地存储数据损坏，已清空', 'warning');
      }
    } else {
      allRecords = [];
    }
  } catch (error) {
    console.error('加载本地存储失败:', error);
    allRecords = [];
  }
}

// 保存记录到服务器或本地存储
async function saveRecordsToStorage() {
  if (isUsingServerStorage) {
    try {
      const response = await fetch(`${RECORDS_API_BASE}/records`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(currentDetectResult)
      });
      if (response.ok) {
        console.log('记录已保存到服务器');
        return true;
      } else {
        console.warn('服务器保存失败');
        return false;
      }
    } catch (error) {
      console.warn('服务器保存失败，使用本地存储:', error);
      saveToLocalStorage();
      return false;
    }
  } else {
    saveToLocalStorage();
  }
}

// 保存单条记录到服务器
async function saveRecordToServer(record) {
  try {
    const response = await fetch(`${RECORDS_API_BASE}/records`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(record)
    });
    if (response.ok) {
      console.log('记录已保存到服务器');
      return true;
    } else {
      console.warn('服务器保存失败');
      return false;
    }
  } catch (error) {
    console.warn('服务器保存失败:', error);
    return false;
  }
}

function saveToLocalStorage() {
  let maxRecords = 2000;
  let saved = false;

  while (!saved && maxRecords > 0) {
    try {
      allRecords.sort((a, b) => new Date(b.time) - new Date(a.time));
      const recordsToSave = allRecords.slice(0, maxRecords);
      localStorage.setItem('records', JSON.stringify(recordsToSave));
      allRecords = recordsToSave;
      console.log(`成功保存 ${maxRecords} 条记录到本地存储`);
      saved = true;
    } catch (error) {
      console.error(`保存 ${maxRecords} 条记录失败，尝试减少记录数量:`, error);
      maxRecords = Math.floor(maxRecords * 0.7);
      allRecords = allRecords.slice(0, maxRecords);
    }
  }

  if (!saved) {
    console.error('无法保存记录到本地存储，可能是存储已满');
    showToast('存储已满，已清空旧记录', 'warning');
    try {
      localStorage.removeItem('records');
    } catch (e) {
      console.error('清空记录失败:', e);
    }
  }
}

// 加载指定页的记录
async function loadRecordsPage(page) {
  if (!isUsingServerStorage) return;

  try {
    const operator = currentUser && currentUser.role === 'operator' ? currentUser.username : (selectedOperator !== 'all' ? selectedOperator : null);
    const response = await fetch(`${RECORDS_API_BASE}/records?page=${page}&limit=${RECORDS_PER_PAGE}${operator ? '&operator=' + operator : ''}`);
    if (response.ok) {
      const data = await response.json();
      allRecords = data.records || [];
      totalRecords = data.total || 0;
      totalPages = data.totalPages || 0;
      currentPage = page;
      console.log(`加载第 ${page} 页，共 ${totalRecords} 条记录`);
      renderRecords();
      renderRecentRecords();
      updateStats();
    }
  } catch (error) {
    console.error('加载记录失败:', error);
    showToast('加载记录失败', 'error');
  }
}

// 根据用户名获取用户角色标签
function getUserRoleLabel(username) {
  const user = users.find(u => u.username === username);
  return user && user.role === 'admin' ? '管理员' : '操作员';
}

// 获取当前视图过滤后的记录
function getFilteredRecordsForCurrentView() {
  let records = [...allRecords];

  if (currentUser && currentUser.role === 'operator') {
    records = records.filter(r => r.operator === currentUser.username);
  }

  if (currentUser && currentUser.role === 'admin' && selectedOperator !== 'all') {
    records = records.filter(r => r.operator === selectedOperator);
  }

  // 按产品编号搜索
  if (currentSearchQuery) {
    records = records.filter(r => r.productId && r.productId.toLowerCase().includes(currentSearchQuery.toLowerCase()));
  }

  return records;
}

// 渲染最近记录
function renderRecentRecords() {
  const list = document.getElementById('recentRecords');
  if (!list) return;

  const records = getFilteredRecordsForCurrentView().slice(0, 10);

  if (!records.length) {
    list.innerHTML = '<div style="color:var(--text-secondary);padding:16px 0;">暂无记录</div>';
    return;
  }

  list.innerHTML = records.map(r => {
      const applianceTypeName = r.applianceType || '-';
      const defectTypes = r.defectTypes || (r.defectType ? [r.defectType] : []);
      const defectTypeLabels = defectTypes.map(dt => DEFECT_TYPE_LABELS[dt] || dt);
      const hasDefect = defectTypes.length > 0 && !defectTypes.every(dt => dt === 'NORMAL');
      return `
      <div class="record-item">
        <div class="record-main">
          ${r.imageData ? `<img class="record-image" src="${r.imageData}" onclick="viewImage(${r.id})"><div class="record-image-placeholder" style="display: none;">无图片</div>` : `<div class="record-image-placeholder">无图片</div>`}
          <div class="record-info">
            <div class="record-title">${defectTypeLabels.join('、') || '正常'} · ${r.labelLevel || '未识别'}</div>
            <div class="record-meta">
              编号：${r.productId || 'N/A'} |
              操作人员：${escapeHtml(r.operatorName || r.operator)} |
              产线：${currentLines.find(l => l.id === r.lineId)?.name || r.lineId} |
              电器：${applianceTypeName} |
              时间：${formatDateTime(r.time)}
            </div>
          </div>
        </div>
        <div class="record-actions">
          <span class="result-badge ${hasDefect ? 'defect' : 'normal'}">${r.processed ? '已处理' : '未处理'}</span>
        </div>
      </div>
    `;
    }).join('');
}

// 渲染记录列表
function renderRecords() {
  const list = document.getElementById('recordList');
  if (!list) return;

  let records = getFilteredRecordsForCurrentView();

  const filterProcessed = document.getElementById('filterProcessed');
  const filterDefectType = document.getElementById('filterDefectType');
  const filterLabelLevel = document.getElementById('filterLabelLevel');
  const filterDate = document.getElementById('filterDate');

  const processed = filterProcessed ? filterProcessed.value : 'all';
  const defectType = filterDefectType ? filterDefectType.value : 'all';
  const labelLevel = filterLabelLevel ? filterLabelLevel.value : 'all';
  const date = filterDate ? filterDate.value : '';

  if (processed === 'processed') records = records.filter(r => r.processed);
  if (processed === 'unprocessed') records = records.filter(r => !r.processed);
  if (defectType !== 'all') records = records.filter(r => {
    const types = r.defectTypes || (r.defectType ? [r.defectType] : []);
    return types.includes(defectType);
  });
  if (labelLevel !== 'all') records = records.filter(r => r.labelLevel === labelLevel);
  if (date) records = records.filter(r => r.time.slice(0, 10) === date);

  let html = '';

  if (!records.length) {
    html = '<div style="padding:20px;color:var(--text-secondary);">暂无数据</div>';
  } else {
    html = records.map(r => {
      const applianceTypeName = r.applianceType || '-';
      const defectTypes = r.defectTypes || (r.defectType ? [r.defectType] : []);
      const defectTypeLabels = defectTypes.map(dt => DEFECT_TYPE_LABELS[dt] || dt);
      const hasDefect = defectTypes.length > 0 && !defectTypes.every(dt => dt === 'NORMAL');
      return `
      <div class="record-item">
        <div class="record-main">
          ${r.imageData ? `<img class="record-image" src="${r.imageData}" onclick="viewImage(${r.id})"><div class="record-image-placeholder" style="display: none;">无图片</div>` : `<div class="record-image-placeholder">无图片</div>`}
          <div class="record-info">
            <div class="record-title">${defectTypeLabels.join('、') || '正常'} · ${r.labelLevel || '未识别'}</div>
            <div class="record-meta">
              编号：${r.productId || 'N/A'} |
              操作人员：${escapeHtml(r.operatorName || r.operator)} |
              产线：${currentLines.find(l => l.id === r.lineId)?.name || r.lineId} |
              电器：${applianceTypeName} |
              时间：${formatDateTime(r.time)}
            </div>
          </div>
        </div>
        <div class="record-actions">
          <span class="record-confidence">置信度 ${(r.confidence * 100).toFixed(1)}%</span>
          <span class="result-badge ${hasDefect ? 'defect' : 'normal'}">${r.processed ? '已处理' : '未处理'}</span>
          ${!r.processed ? `<button class="btn btn-success btn-sm" onclick="processRecord(${r.id})">处理</button>` : ''}
          <button class="btn btn-danger btn-sm" onclick="deleteRecord(${r.id})">删除</button>
        </div>
      </div>
    `;
    }).join('');
  }

  if (isUsingServerStorage && totalPages > 1) {
    html += renderPagination();
  }

  list.innerHTML = html;
}

function renderPagination() {
  if (totalPages <= 1) return '';

  let paginationHtml = `
    <div class="pagination" style="display: flex; justify-content: center; align-items: center; gap: 10px; margin-top: 20px; padding: 15px;">
      <span style="margin-right: 15px;">共 ${totalRecords} 条记录，第 ${currentPage}/${totalPages} 页</span>
  `;

  if (currentPage > 1) {
    paginationHtml += `<button class="btn btn-secondary" onclick="loadRecordsPage(${currentPage - 1})">上一页</button>`;
  }

  const startPage = Math.max(1, currentPage - 2);
  const endPage = Math.min(totalPages, currentPage + 2);

  if (startPage > 1) {
    paginationHtml += `<button class="btn btn-secondary" onclick="loadRecordsPage(1)">1</button>`;
    if (startPage > 2) {
      paginationHtml += `<span style="padding: 0 5px;">...</span>`;
    }
  }

  for (let i = startPage; i <= endPage; i++) {
    if (i === currentPage) {
      paginationHtml += `<button class="btn btn-primary" disabled>${i}</button>`;
    } else {
      paginationHtml += `<button class="btn btn-secondary" onclick="loadRecordsPage(${i})">${i}</button>`;
    }
  }

  if (endPage < totalPages) {
    if (endPage < totalPages - 1) {
      paginationHtml += `<span style="padding: 0 5px;">...</span>`;
    }
    paginationHtml += `<button class="btn btn-secondary" onclick="loadRecordsPage(${totalPages})">${totalPages}</button>`;
  }

  if (currentPage < totalPages) {
    paginationHtml += `<button class="btn btn-secondary" onclick="loadRecordsPage(${currentPage + 1})">下一页</button>`;
  }

  paginationHtml += '</div>';
  return paginationHtml;
}

// 应用记录筛选
function applyRecordFilter() { renderRecords(); }

// 清空记录筛选
function clearRecordFilter() {
  const filterProcessed = document.getElementById('filterProcessed');
  const filterDefectType = document.getElementById('filterDefectType');
  const filterLabelLevel = document.getElementById('filterLabelLevel');
  const filterDate = document.getElementById('filterDate');
  
  if (filterProcessed) filterProcessed.value = 'all';
  if (filterDefectType) filterDefectType.value = 'all';
  if (filterLabelLevel) filterLabelLevel.value = 'all';
  if (filterDate) filterDate.value = '';
  renderRecords();
}

// 处理记录
async function processRecord(id) {
  const record = allRecords.find(r => r.id === id);
  if (!record) return;
  record.processed = true;

  if (isUsingServerStorage) {
    try {
      await fetch(`${RECORDS_API_BASE}/records`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(record)
      });
    } catch (error) {
      console.warn('更新服务器记录失败:', error);
    }
  } else {
    saveToLocalStorage();
  }

  renderRecords();
  renderRecentRecords();
  updateStats();
  forceRefreshChart();
  showToast('记录已标记为已处理', 'success');
}

// 删除记录
async function deleteRecord(id) {
  if (!confirm('确定要删除这条记录吗？此操作不可恢复。')) return;

  if (isUsingServerStorage) {
    try {
      await fetch(`${RECORDS_API_BASE}/records/${id}`, {
        method: 'DELETE'
      });
    } catch (error) {
      console.warn('删除服务器记录失败:', error);
    }
  }

  allRecords = allRecords.filter(r => r.id !== id);

  if (!isUsingServerStorage) {
    saveToLocalStorage();
  }

  totalRecords = Math.max(0, totalRecords - 1);
  totalPages = Math.ceil(totalRecords / RECORDS_PER_PAGE) || 1;

  renderRecords();
  renderRecentRecords();
  updateStats();
  forceRefreshChart();
  showToast('记录已删除', 'success');
}

// 实时视频检测
let realtimeDetectionInterval = null;
let isRealtimeDetecting = false;

// 开始实时检测
function startRealtimeDetection() {
  const video = document.getElementById('cameraVideo');
  const canvas = document.getElementById('previewCanvas');
  
  if (!video || !canvas) return;
  
  // 清除之前的定时器
  if (realtimeDetectionInterval) {
    clearInterval(realtimeDetectionInterval);
  }
  
  isRealtimeDetecting = true;
  showToast('开始实时检测', 'success');
  
  // 更新按钮状态
  if (document.getElementById('realtimeBtn')) {
    document.getElementById('realtimeBtn').textContent = '停止实时检测';
  }
  
  // 确保视频元素可见
  video.classList.remove('hidden');
  const placeholder = document.getElementById('cameraPlaceholder');
  if (placeholder) placeholder.classList.add('hidden');
  
  // 自动检测 - 当检测到新的能效标签时进行检测
  let lastDetectionTime = 0;
  let lastFrameData = null;
  
  function detectFrame() {
    if (!isRealtimeDetecting || !video || !video.srcObject) {
      return;
    }
    
    // 绘制视频帧到画布
    canvas.width = video.videoWidth || 1280;
    canvas.height = video.videoHeight || 720;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    
    // 获取图片数据
    const imageData = canvas.toDataURL('image/png');
    
    // 简单的帧变化检测
    const now = Date.now();
    if (now - lastDetectionTime > 1000 && imageData !== lastFrameData) {
      lastDetectionTime = now;
      lastFrameData = imageData;
      
      // 执行实时检测
      doDetectRealtime(imageData).catch(error => {
        console.error('实时检测失败:', error);
      });
    }
    
    requestAnimationFrame(detectFrame);
  }
  
  requestAnimationFrame(detectFrame);
}

// 停止实时检测
function stopRealtimeDetection() {
  if (realtimeDetectionInterval) {
    clearInterval(realtimeDetectionInterval);
    realtimeDetectionInterval = null;
    isRealtimeDetecting = false;
    showToast('停止实时检测', 'success');
    
    // 更新按钮状态
    if (document.getElementById('realtimeBtn')) {
      document.getElementById('realtimeBtn').textContent = '开始实时检测';
    }
  } else {
    // 如果没有实时检测在运行，只重置状态，不显示提示
    isRealtimeDetecting = false;
    
    // 更新按钮状态
    if (document.getElementById('realtimeBtn')) {
      document.getElementById('realtimeBtn').textContent = '开始实时检测';
    }
  }
}

// 切换实时检测状态
function toggleRealtimeDetection() {
  if (isRealtimeDetecting) {
    stopRealtimeDetection();
  } else {
    // 检查摄像头是否已开启
    if (!cameraStream) {
      // 开启摄像头
      navigator.mediaDevices.getUserMedia({
        video: {
          width: { ideal: 1280 },
          height: { ideal: 720 },
          facingMode: 'environment'
        },
        audio: false
      })
      .then(stream => {
        cameraStream = stream;
        const video = document.getElementById('cameraVideo');
        const placeholder = document.getElementById('cameraPlaceholder');
        if (video) {
          video.srcObject = stream;
          video.classList.remove('hidden');
          video.onloadedmetadata = function() {
            video.play().catch(e => console.error('视频播放失败:', e));
          };
        }
        if (placeholder) placeholder.classList.add('hidden');
        if (document.getElementById('stopCameraBtn')) {
          document.getElementById('stopCameraBtn').style.display = 'inline-block';
        }
        // 开始实时检测
        startRealtimeDetection();
      })
      .catch(err => {
        console.error('摄像头错误:', err);
        let errorMsg = '无法打开摄像头';
        if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
          errorMsg = '摄像头权限被拒绝，请在浏览器设置中允许访问摄像头';
        } else if (err.name === 'NotFoundError') {
          errorMsg = '未找到摄像头设备';
        } else if (err.name === 'NotReadableError') {
          errorMsg = '摄像头被其他程序占用';
        }
        showToast(errorMsg, 'error');
      });
    } else {
      // 摄像头已开启，直接开始实时检测
      startRealtimeDetection();
    }
  }
}

// 拍照检测（自动开启摄像头）
async function captureAndDetectWithCamera() {
  const video = document.getElementById('cameraVideo');
  const canvas = document.getElementById('previewCanvas');
  const placeholder = document.getElementById('cameraPlaceholder');

  // 如果摄像头未开启，先尝试开启
  if (!cameraStream) {
    try {
      showToast('正在请求摄像头权限...', 'info');
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          width: { ideal: 1280 },
          height: { ideal: 720 },
          facingMode: 'environment'
        },
        audio: false
      });
      cameraStream = stream;
      if (video) {
        video.srcObject = stream;
        video.classList.remove('hidden');
        video.onloadedmetadata = function() {
          video.play().catch(e => console.error('视频播放失败:', e));
        };
      }
      if (placeholder) placeholder.classList.add('hidden');
      if (canvas) canvas.classList.add('hidden');
      if (document.getElementById('stopCameraBtn')) {
        document.getElementById('stopCameraBtn').style.display = 'inline-block';
      }
      if (document.getElementById('realtimeBtn')) {
        document.getElementById('realtimeBtn').style.display = 'inline-block';
      }
      showToast('摄像头已开启，请拍照', 'success');
      // 等待摄像头准备好
      await new Promise(resolve => setTimeout(resolve, 1000));
    } catch (err) {
      console.error('摄像头错误:', err);
      let errorMsg = '无法打开摄像头';
      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        errorMsg = '摄像头权限被拒绝，请在浏览器设置中允许访问摄像头';
      } else if (err.name === 'NotFoundError') {
        errorMsg = '未找到摄像头设备';
      } else if (err.name === 'NotReadableError') {
        errorMsg = '摄像头被其他程序占用';
      }
      showToast(errorMsg, 'error');
      return;
    }
  }

  // 执行拍照
  if (!video || video.classList.contains('hidden')) {
    showToast('摄像头未准备好', 'error');
    return;
  }

  // 停止实时检测（如果正在运行）
  if (isRealtimeDetecting) {
    stopRealtimeDetection();
  }

  canvas.width = video.videoWidth || 1280;
  canvas.height = video.videoHeight || 720;
  const ctx = canvas.getContext('2d');
  ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

  currentImageData = canvas.toDataURL('image/png');
  await doDetect(currentImageData, true);
}

// 关闭摄像头
function stopCamera() {
  // 停止实时检测
  stopRealtimeDetection();
  stopVideoDetection();
  
  if (cameraStream) {
    cameraStream.getTracks().forEach(track => track.stop());
    cameraStream = null;
  }
  
  const video = document.getElementById('cameraVideo');
  const uploadedVideo = document.getElementById('uploadedVideo');
  const placeholder = document.getElementById('cameraPlaceholder');
  const canvas = document.getElementById('previewCanvas');
  
  if (video) {
    video.classList.add('hidden');
    video.style.display = 'none';
    video.src = '';
  }
  
  // 清理上传的视频元素
  if (uploadedVideo) {
    uploadedVideo.remove();
  }
  
  if (placeholder) {
    placeholder.classList.remove('hidden');
    placeholder.style.display = 'flex';
  }
  if (canvas) {
    canvas.classList.add('hidden');
    canvas.style.display = 'none';
  }
  
  // 隐藏视频相关按钮
  const stopCameraBtn = document.getElementById('stopCameraBtn');
  if (stopCameraBtn) {
    stopCameraBtn.style.display = 'none';
  }
  
  showToast('摄像头已关闭', 'success');
}

// 拍照并检测（旧版本，保留兼容性）
async function captureAndDetect() {
  await captureAndDetectWithCamera();
}

// 上传图片
function uploadImage(event) {
  const file = event.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = async function(e) {
    currentImageData = e.target.result;
    await doDetect(currentImageData, true);
    // 重置文件输入元素的值，这样即使用户选择了相同的文件，onchange事件也会再次触发
    event.target.value = '';
  };
  reader.readAsDataURL(file);
}




// 绘制标注框
function drawBoundingBoxes(imageData, detections) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = function() {
      const canvas = document.createElement('canvas');
      canvas.width = img.width;
      canvas.height = img.height;
      const ctx = canvas.getContext('2d');
      
      // 绘制原始图像
      ctx.drawImage(img, 0, 0);
      
      // 定义颜色映射
      const colorMap = {
        'energy_1': '#00ff00',
        'energy_2': '#33ff33',
        'energy_3': '#ffff00',
        'energy_4': '#ffaa00',
        'energy_5': '#ff0000',
        'defect_damage': '#ff0000',
        'defect_stain': '#ff00ff',
        'defect_wrinkle': '#0000ff',
        'energy_label': '#00ffff',
        'anchor_box': '#808080',
        'anchor_box1': '#808080',
        'anchor_box2': '#808080',
        'anchor_box3': '#808080'
      };
      
      // 绘制标注框
      if (detections && detections.length > 0) {
        detections.forEach(detection => {
          const className = detection.className;
          // Skip anchor box classes
          if (className.startsWith('anchor_box')) {
            return;
          }
          const confidence = detection.confidence;
          const [x1, y1, x2, y2] = detection.bbox;
          
          // 绘制边框
          ctx.strokeStyle = colorMap[className] || '#ffffff';
          ctx.lineWidth = 2;
          ctx.strokeRect(x1, y1, x2 - x1, y2 - y1);
          
          // 绘制标签
          ctx.fillStyle = colorMap[className] || '#ffffff';
          ctx.fillRect(x1, y1 - 20, 120, 20);
          ctx.fillStyle = '#000000';
          ctx.font = '12px Arial';
          ctx.fillText(`${className} ${confidence.toFixed(2)}`, x1 + 5, y1 - 5);
        });
      }
      
      // 转换为base64
      resolve(canvas.toDataURL('image/png'));
    };
    img.onerror = function() {
      reject(new Error('Failed to load image'));
    };
    img.src = imageData;
  });
}

// 显示检测结果 - 修复版
async function showDetectResult(result) {
  console.log('显示检测结果:', result);
  currentDetectResult = result;

  // 获取元素
  const resultEmpty = document.getElementById('resultEmpty');
  const resultContent = document.getElementById('resultContent');
  
  // 切换显示状态
  if (resultEmpty) {
    resultEmpty.style.display = 'none';
    resultEmpty.classList.add('hidden');
  }
  
  if (resultContent) {
    resultContent.style.display = 'block';
    resultContent.classList.remove('hidden');
  }

  // 设置预览图片 - 原图
  const resultPreviewImage = document.getElementById('resultPreviewImage');
  if (resultPreviewImage) {
    if (result.originalImageData) {
      resultPreviewImage.src = result.originalImageData;
    } else if (result.imageData) {
      resultPreviewImage.src = result.imageData;
    }
  }
  
  // 设置标注结果图片
  const resultAnnotatedImage = document.getElementById('resultAnnotatedImage');
  if (resultAnnotatedImage && result.imageData) {
    resultAnnotatedImage.src = result.imageData;
  }

  // 设置结果标签
  const defectTypes = result.defectTypes || (result.defectType ? [result.defectType] : []);
  const hasDefect = defectTypes.length > 0 && !defectTypes.every(dt => dt === 'NORMAL');

  const resultBadge = document.getElementById('resultBadge');
  if (resultBadge) {
    resultBadge.textContent = hasDefect ? '缺陷' : '正常';
    resultBadge.className = `result-badge ${hasDefect ? 'defect' : 'normal'}`;
  }

  // 设置时间
  const resultTime = document.getElementById('resultTime');
  if (resultTime) {
    resultTime.textContent = formatDateTime(result.time);
  }

  // 设置各项数据
  const resultOperator = document.getElementById('resultOperator');
  if (resultOperator) {
    resultOperator.textContent = result.operatorName || result.operator || '-';
  }

  const resultLine = document.getElementById('resultLine');
  if (resultLine) {
    const lineName = currentLines.find(l => l.id === result.lineId)?.name;
    resultLine.textContent = lineName || result.lineId || '-';
  }

  const resultLevel = document.getElementById('resultLevel');
  if (resultLevel) {
    resultLevel.textContent = result.labelLevel || '-';
  }

  const resultDefectType = document.getElementById('resultDefectType');
  if (resultDefectType) {
    const defectTypeLabels = defectTypes.map(dt => DEFECT_TYPE_LABELS[dt] || dt);
    resultDefectType.textContent = defectTypeLabels.length > 0 ? defectTypeLabels.join('、') : '-';
  }

  const resultDefectDetail = document.getElementById('resultDefectDetail');
  if (resultDefectDetail) {
    const defectDetails = result.defectDetails || (result.defectDetail ? [result.defectDetail] : []);
    const detailText = result.warning
      ? `${defectDetails.join('；') || '无'}（提示：${result.warning}）`
      : (defectDetails.join('；') || '无');
    resultDefectDetail.textContent = detailText;
  }

  const resultArea = document.getElementById('resultArea');
  if (resultArea) {
    resultArea.textContent = result.deviationArea || '无';
  }

  const resultDirection = document.getElementById('resultDirection');
  if (resultDirection) {
    resultDirection.textContent = result.deviationDirection || '无';
  }

  const resultDeviation = document.getElementById('resultDeviation');
  if (resultDeviation) {
    resultDeviation.textContent = result.deviationValue || '无';
  }

  const resultConfidence = document.getElementById('resultConfidence');
  if (resultConfidence) {
    resultConfidence.textContent = result.confidence ? `${(result.confidence * 100).toFixed(1)}%` : '-';
  }

  const resultProcessed = document.getElementById('resultProcessed');
  if (resultProcessed) {
    resultProcessed.textContent = result.processed ? '已处理' : '未处理';
  }
}

// 执行实时检测
let realtimeRequestInFlight = false;

function doDetectRealtime(imageData) {
  if (realtimeRequestInFlight) return;
  realtimeRequestInFlight = true;

  postJson(`${ML_API_BASE}/detect`, {
    imageBase64: imageData,
    lineId: currentLineId,
    realtime: true,
    brightness: brightness,
    clarity: clarity,
    applianceType: applianceType,
    positionThreshold: positionThreshold,
    defectThreshold: 0.1,
    damageThreshold: damageThreshold,
    stainThreshold: stainThreshold,
    wrinkleThreshold: wrinkleThreshold
  })
  .then(async apiResult => {
    // 绘制标注框
    let annotatedImage = imageData;
    if (apiResult.rawResult && apiResult.rawResult.detections) {
      try {
        annotatedImage = await drawBoundingBoxes(imageData, apiResult.rawResult.detections);
      } catch (error) {
        console.error('绘制标注框失败:', error);
      }
    }
    
    // 规范化结果
    const now = new Date();
    const timeStr = getCurrentTimeStr();
    const currentSeq = getCurrentSeq();
    const seqStr = currentSeq.toString().padStart(2, '0');
    const productId = `P${timeStr}${seqStr}`;
    updateSeq(currentSeq + 1);
    
    const result = {
      ...normalizeDetectResult(apiResult, annotatedImage, imageData, { lineId: currentLineId }),
      id: Date.now(),
      productId: productId,
      time: apiResult.time || now.toISOString()
    };
    
    showDetectResult(result);
    if (result.warning) {
      showToast(result.warning, 'warning');
    } else if (result.defectType === 'NORMAL') {
      showToast('实时检测完成', 'success');
    }
    currentDetectResult = result;
    allRecords.unshift(result);

    if (isUsingServerStorage) {
      await saveRecordToServer(result);
      totalRecords++;
      totalPages = Math.ceil(totalRecords / RECORDS_PER_PAGE);
    } else {
      saveToLocalStorage();
    }

    renderRecentRecords();
    renderRecords();
    updateStats();
    forceRefreshChart();
    if (result.defectType !== 'NORMAL') {
      showToast('检测到缺陷', 'warning');
    }
  })
  .catch(error => {
    console.error('实时检测失败:', error);
    showToast(error.message || '实时检测失败', 'error');
  })
  .finally(() => {
    realtimeRequestInFlight = false;
  });
}

// 执行检测 - 修复版
async function doDetect(imageData, forceRefresh = true) {
  console.log('执行检测...');
  
  try {
    // 显示加载状态
    showToast('正在检测，请稍候...', 'info');
    
    const apiResult = await postJson(`${ML_API_BASE}/detect`, {
      imageBase64: imageData,
      lineId: currentLineId,
      realtime: false,
      brightness: brightness,
      clarity: clarity,
      applianceType: applianceType,
      positionThreshold: positionThreshold,
      defectThreshold: 0.1,
      damageThreshold: damageThreshold,
      stainThreshold: stainThreshold,
      wrinkleThreshold: wrinkleThreshold
    });
    
    // 绘制标注框
    let annotatedImage = imageData;
    if (apiResult.rawResult && apiResult.rawResult.detections) {
      try {
        annotatedImage = await drawBoundingBoxes(imageData, apiResult.rawResult.detections);
      } catch (error) {
        console.error('绘制标注框失败:', error);
      }
    }
    
    // 规范化结果
    const now = new Date();
    const timeStr = getCurrentTimeStr();
    const currentSeq = getCurrentSeq();
    const seqStr = currentSeq.toString().padStart(2, '0');
    const productId = `P${timeStr}${seqStr}`;
    updateSeq(currentSeq + 1);
    
    const result = {
      ...normalizeDetectResult(apiResult, annotatedImage, imageData, { lineId: currentLineId }),
      id: Date.now(),
      productId: productId,
      time: apiResult.time || now.toISOString()
    };

    currentDetectResult = result;
    allRecords.unshift(result);

    if (isUsingServerStorage) {
      await saveRecordToServer(result);
      totalRecords++;
      totalPages = Math.ceil(totalRecords / RECORDS_PER_PAGE);
    } else {
      saveToLocalStorage();
    }

    // 立即显示结果
    showDetectResult(result);

    // 检查是否需要预警
    checkForAlert(result);

    // 更新其他界面
    renderRecentRecords();
    renderRecords();
    updateStats();
    forceRefreshChart();
    
    if (result.warning) {
      showToast(result.warning, 'warning');
    } else {
      showToast('检测完成', 'success');
    }
  } catch (error) {
    console.error('检测失败:', error);
    showToast(error.message || '检测失败，请检查模型服务', 'error');
    // 不继续执行，因为apiResult没有被赋值
    return;
  }
}

// 标记为已处理
function markProcessed() {
  if (!currentDetectResult) return;
  const record = allRecords.find(r => r.id === currentDetectResult.id);
  if (record) {
    record.processed = true;
    currentDetectResult.processed = true;
    saveRecordsToStorage();
    showDetectResult(currentDetectResult);
    renderRecords();
    renderRecentRecords();
    updateStats();
    forceRefreshChart();
    showToast('已标记为处理完成', 'success');
  }
}

// 重置检测
function resetDetect() {
  currentDetectResult = null;
  currentImageData = null;
  
  const resultContent = document.getElementById('resultContent');
  const resultEmpty = document.getElementById('resultEmpty');
  
  if (resultContent) {
    resultContent.style.display = 'none';
    resultContent.classList.add('hidden');
  }
  
  if (resultEmpty) {
    resultEmpty.style.display = 'flex';
    resultEmpty.classList.remove('hidden');
  }
}

// 调整亮度
function adjustBrightness(value) {
  brightness = parseFloat(value);
  const brightnessValue = document.getElementById('brightnessValue');
  if (brightnessValue) {
    brightnessValue.textContent = brightness.toFixed(1);
  }
  // 更新输入框的值
  const brightnessInput = document.getElementById('brightnessInput');
  if (brightnessInput) {
    brightnessInput.value = brightness.toFixed(1);
  }
  // 应用亮度调整到视频流
  const video = document.getElementById('cameraVideo');
  if (video && !video.classList.contains('hidden')) {
    video.style.filter = `brightness(${brightness}) contrast(${clarity})`;
  }
}

// 通过输入框调整亮度
function adjustBrightnessByInput(value) {
  const brightnessInput = document.getElementById('brightnessInput');
  if (brightnessInput) {
    const inputValue = parseFloat(value);
    // 确保值在有效范围内
    const clampedValue = Math.max(0, Math.min(3, inputValue));
    brightnessInput.value = clampedValue.toFixed(1);
    // 更新进度条
    const brightnessSlider = document.getElementById('brightnessSlider');
    if (brightnessSlider) {
      brightnessSlider.value = clampedValue;
    }
    // 调用原有的调整函数
    adjustBrightness(clampedValue);
  }
}

// 调整清晰度
function adjustClarity(value) {
  clarity = parseFloat(value);
  const clarityValue = document.getElementById('clarityValue');
  if (clarityValue) {
    clarityValue.textContent = clarity.toFixed(1);
  }
  // 更新输入框的值
  const clarityInput = document.getElementById('clarityInput');
  if (clarityInput) {
    clarityInput.value = clarity.toFixed(1);
  }
  // 应用清晰度调整到视频流
  const video = document.getElementById('cameraVideo');
  if (video && !video.classList.contains('hidden')) {
    video.style.filter = `brightness(${brightness}) contrast(${clarity})`;
  }
}

// 通过输入框调整清晰度
function adjustClarityByInput(value) {
  const clarityInput = document.getElementById('clarityInput');
  if (clarityInput) {
    const inputValue = parseFloat(value);
    // 确保值在有效范围内
    const clampedValue = Math.max(0, Math.min(3, inputValue));
    clarityInput.value = clampedValue.toFixed(1);
    // 更新进度条
    const claritySlider = document.getElementById('claritySlider');
    if (claritySlider) {
      claritySlider.value = clampedValue;
    }
    // 调用原有的调整函数
    adjustClarity(clampedValue);
  }
}

// 更改电器类型
function changeApplianceType(type) {
  applianceType = type;
}

// 调整预警阈值
function adjustAlertThreshold(value) {
  alertThreshold = parseFloat(value);
  const alertThresholdValue = document.getElementById('alertThresholdValue');
  if (alertThresholdValue) {
    alertThresholdValue.textContent = alertThreshold.toFixed(2);
  }
  // 更新输入框的值
  const alertThresholdInput = document.getElementById('alertThresholdInput');
  if (alertThresholdInput) {
    alertThresholdInput.value = alertThreshold.toFixed(2);
  }
  console.log('预警阈值已调整为:', alertThreshold);
}

// 通过输入框调整预警阈值
function adjustAlertThresholdByInput(value) {
  const alertThresholdInput = document.getElementById('alertThresholdInput');
  if (alertThresholdInput) {
    const inputValue = parseFloat(value);
    // 确保值在有效范围内
    const clampedValue = Math.max(0.1, Math.min(1.0, inputValue));
    alertThresholdInput.value = clampedValue.toFixed(2);
    // 更新进度条
    const alertThresholdSlider = document.getElementById('alertThresholdSlider');
    if (alertThresholdSlider) {
      alertThresholdSlider.value = clampedValue;
    }
    // 调用原有的调整函数
    adjustAlertThreshold(clampedValue);
  }
}

// 调整位置偏差阈值
function adjustPositionThreshold(value) {
  positionThreshold = parseInt(value);
  const positionThresholdValue = document.getElementById('positionThresholdValue');
  if (positionThresholdValue) {
    positionThresholdValue.textContent = positionThreshold;
  }
  // 更新输入框的值
  const positionThresholdInput = document.getElementById('positionThresholdInput');
  if (positionThresholdInput) {
    positionThresholdInput.value = positionThreshold;
  }
  console.log('位置偏差阈值已调整为:', positionThreshold, '像素');
}

// 通过输入框调整位置偏差阈值
function adjustPositionThresholdByInput(value) {
  const positionThresholdInput = document.getElementById('positionThresholdInput');
  if (positionThresholdInput) {
    const inputValue = parseInt(value);
    // 确保值在有效范围内
    const clampedValue = Math.max(0, Math.min(1000, inputValue));
    positionThresholdInput.value = clampedValue;
    // 更新进度条
    const positionThresholdSlider = document.getElementById('positionThresholdSlider');
    if (positionThresholdSlider) {
      positionThresholdSlider.value = clampedValue;
    }
    // 调用原有的调整函数
    adjustPositionThreshold(clampedValue);
  }
}

// 调节褶皱检测阈值
function adjustWrinkleThreshold(value) {
  wrinkleThreshold = parseFloat(value);
  const wrinkleThresholdInput = document.getElementById('wrinkleThresholdInput');
  if (wrinkleThresholdInput) {
    wrinkleThresholdInput.value = wrinkleThreshold.toFixed(2);
  }
  console.log('褶皱检测阈值已调整为:', wrinkleThreshold);
}

// 通过输入框调整褶皱检测阈值
function adjustWrinkleThresholdByInput(value) {
  const wrinkleThresholdInput = document.getElementById('wrinkleThresholdInput');
  if (wrinkleThresholdInput) {
    const inputValue = parseFloat(value);
    const clampedValue = Math.max(0.01, Math.min(0.99, inputValue));
    wrinkleThresholdInput.value = clampedValue.toFixed(2);
    const wrinkleThresholdSlider = document.getElementById('wrinkleThresholdSlider');
    if (wrinkleThresholdSlider) {
      wrinkleThresholdSlider.value = clampedValue;
    }
    adjustWrinkleThreshold(clampedValue);
  }
}

// 调节污渍检测阈值
function adjustStainThreshold(value) {
  stainThreshold = parseFloat(value);
  const stainThresholdInput = document.getElementById('stainThresholdInput');
  if (stainThresholdInput) {
    stainThresholdInput.value = stainThreshold.toFixed(2);
  }
  console.log('污渍检测阈值已调整为:', stainThreshold);
}

// 通过输入框调整污渍检测阈值
function adjustStainThresholdByInput(value) {
  const stainThresholdInput = document.getElementById('stainThresholdInput');
  if (stainThresholdInput) {
    const inputValue = parseFloat(value);
    const clampedValue = Math.max(0.01, Math.min(0.99, inputValue));
    stainThresholdInput.value = clampedValue.toFixed(2);
    const stainThresholdSlider = document.getElementById('stainThresholdSlider');
    if (stainThresholdSlider) {
      stainThresholdSlider.value = clampedValue;
    }
    adjustStainThreshold(clampedValue);
  }
}

// 调节破损检测阈值
function adjustDamageThreshold(value) {
  damageThreshold = parseFloat(value);
  const damageThresholdInput = document.getElementById('damageThresholdInput');
  if (damageThresholdInput) {
    damageThresholdInput.value = damageThreshold.toFixed(2);
  }
  console.log('破损检测阈值已调整为:', damageThreshold);
}

// 通过输入框调整破损检测阈值
function adjustDamageThresholdByInput(value) {
  const damageThresholdInput = document.getElementById('damageThresholdInput');
  if (damageThresholdInput) {
    const inputValue = parseFloat(value);
    const clampedValue = Math.max(0.01, Math.min(0.99, inputValue));
    damageThresholdInput.value = clampedValue.toFixed(2);
    const damageThresholdSlider = document.getElementById('damageThresholdSlider');
    if (damageThresholdSlider) {
      damageThresholdSlider.value = clampedValue;
    }
    adjustDamageThreshold(clampedValue);
  }
}

// 搜索产品编号
function searchByProductId() {
  const searchInput = document.getElementById('searchInput');
  if (searchInput) {
    currentSearchQuery = searchInput.value.trim();
    renderRecords();
  }
}

// 清除搜索
function clearSearch() {
  const searchInput = document.getElementById('searchInput');
  if (searchInput) {
    searchInput.value = '';
    currentSearchQuery = '';
    renderRecords();
  }
}

// 调整检测速度
// 调整预警阈值
function adjustAlertThreshold(value) {
  alertThreshold = parseFloat(value);
  const thresholdValue = document.getElementById('alertThresholdValue');
  if (thresholdValue) {
    thresholdValue.textContent = alertThreshold.toFixed(2);
  }
  showToast(`预警阈值已设置为 ${alertThreshold.toFixed(2)}`, 'info');
}

// 检查是否需要预警
function checkForAlert(result) {
  // 检查条件：1. 不是正常结果 2. 置信度高于阈值 3. 还未预警过
  if (result.defectType !== 'NORMAL' && 
      typeof result.confidence === 'number' && 
      result.confidence > alertThreshold && 
      !alertedRecords.has(result.id)) {
    showAlertPopup(result);
    // 标记为已预警
    alertedRecords.add(result.id);
  }
}

// 显示预警弹窗
function showAlertPopup(result) {
  // 检查是否已存在预警弹窗
  let alertPopup = document.getElementById('alertPopup');
  if (alertPopup) {
    // 移除旧弹窗
    alertPopup.remove();
  }
  
  // 创建新弹窗
  alertPopup = document.createElement('div');
  alertPopup.id = 'alertPopup';
  alertPopup.className = 'alert-popup';
  alertPopup.innerHTML = `
    <div class="alert-popup-content">
      <div class="alert-popup-header">
        <h3>⚠️ 检测预警</h3>
        <button class="alert-popup-close" onclick="closeAlertPopup(${result.id})">×</button>
      </div>
      <div class="alert-popup-body">
        <p><strong>产品编号:</strong> ${result.productId}</p>
        <p><strong>缺陷类型:</strong> ${(result.defectTypes || [result.defectType]).map(dt => DEFECT_TYPE_LABELS[dt] || dt).join('、')}</p>
        <p><strong>置信度:</strong> ${(result.confidence * 100).toFixed(1)}%</p>
        <p><strong>预警阈值:</strong> ${(alertThreshold * 100).toFixed(1)}%</p>
        <p><strong>缺陷说明:</strong> ${(result.defectDetails || []).join('；') || result.defectDetail || '无'}</p>
      </div>
      <div class="alert-popup-footer">
        <button class="btn btn-danger" onclick="closeAlertPopup(${result.id})">关闭</button>
      </div>
    </div>
    <style>
      .alert-popup {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 1000;
      }
      .alert-popup-content {
        background-color: white;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        width: 90%;
        max-width: 500px;
        overflow: hidden;
      }
      .alert-popup-header {
        background-color: #3b82f6;
        color: white;
        padding: 16px;
        display: flex;
        justify-content: space-between;
        align-items: center;
      }
      .alert-popup-header h3 {
        margin: 0;
        font-size: 18px;
      }
      .alert-popup-close {
        background: none;
        border: none;
        color: white;
        font-size: 24px;
        cursor: pointer;
        padding: 0;
        width: 30px;
        height: 30px;
        display: flex;
        align-items: center;
        justify-content: center;
      }
      .alert-popup-body {
        padding: 20px;
      }
      .alert-popup-body p {
        margin: 8px 0;
        font-size: 14px;
      }
      .alert-popup-footer {
        padding: 16px;
        background-color: #f9fafb;
        border-top: 1px solid #e5e7eb;
        display: flex;
        justify-content: flex-end;
      }
    </style>
  `;
  
  // 添加到页面
  document.body.appendChild(alertPopup);
}

// 关闭预警弹窗
function closeAlertPopup(recordId) {
  const alertPopup = document.getElementById('alertPopup');
  if (alertPopup) {
    alertPopup.remove();
  }
  // 确保该记录已标记为已预警
  alertedRecords.add(recordId);
}

// 上传视频
function uploadVideo(event) {
  const file = event.target.files[0];
  if (!file) return;

  console.log('开始处理视频上传:', file);

  // 停止当前的摄像头和实时检测
  stopCamera();
  stopRealtimeDetection();
  stopVideoDetection();

  const cameraBox = document.querySelector('.camera-box');
  const placeholder = document.getElementById('cameraPlaceholder');
  const canvas = document.getElementById('previewCanvas');
  const existingVideo = document.getElementById('cameraVideo');

  console.log('获取到cameraBox:', cameraBox);
  console.log('获取到placeholder:', placeholder);
  console.log('获取到canvas:', canvas);
  console.log('获取到existingVideo:', existingVideo);

  if (placeholder) {
    placeholder.classList.add('hidden');
    placeholder.style.display = 'none';
  }
  if (canvas) {
    canvas.classList.add('hidden');
    canvas.style.display = 'none';
  }
  if (existingVideo) {
    existingVideo.classList.add('hidden');
    existingVideo.style.display = 'none';
  }

  // 确保cameraBox显示
  if (cameraBox) {
    cameraBox.style.display = 'block';
    cameraBox.style.position = 'relative';
    cameraBox.style.zIndex = '1';
    cameraBox.style.minHeight = '400px'; // 确保有足够的高度
    cameraBox.style.background = '#000';
    console.log('cameraBox样式:', cameraBox.style.cssText);
  }

  // 创建一个新的视频元素
  const video = document.createElement('video');
  video.id = 'uploadedVideo';
  video.controls = true;
  video.muted = true; // 静音以避免浏览器自动播放限制
  video.autoplay = true;
  video.playsinline = true;
  video.preload = 'auto';
  
  // 确保视频元素的样式
  video.style.width = '100%';
  video.style.height = '100%';
  video.style.objectFit = 'contain';
  video.style.display = 'block';
  video.style.position = 'relative';
  video.style.zIndex = '10';
  video.style.visibility = 'visible';
  video.style.opacity = '1';
  video.style.background = '#000';
  
  console.log('创建的视频元素:', video);
  console.log('视频元素样式:', video.style.cssText);

  // 将视频元素添加到cameraBox
  if (cameraBox) {
    cameraBox.appendChild(video);
    console.log('视频元素已添加到cameraBox');
  }

  videoElement = video;

  console.log('视频文件类型:', file.type);
  console.log('视频文件大小:', file.size);

  const videoURL = URL.createObjectURL(file);
  console.log('创建的视频URL:', videoURL);
  
  video.src = videoURL;
  console.log('设置视频src后:', video.src);

  video.onloadedmetadata = function() {
    console.log('视频元数据已加载:', video.videoWidth, 'x', video.videoHeight);
    showToast('视频已上传，开始检测...', 'info');
    
    // 尝试播放视频
    video.play().then(() => {
      console.log('视频播放成功');
      showToast('视频开始播放，正在自动检测能效标签', 'info');
      // 立即开始检测，不需要等待
      startVideoDetection();
    }).catch(error => {
      console.error('视频播放失败:', error);
      showToast('视频播放失败，点击视频控件手动播放', 'warning');
      // 即使播放失败，也尝试开始检测
      startVideoDetection();
    });
  };

  video.onerror = function(event) {
    console.error('视频加载失败:', event);
    showToast('视频加载失败', 'error');
  };

  video.onplay = function() {
    console.log('视频开始播放');
  };

  video.onplaying = function() {
    console.log('视频正在播放');
  };

  video.onended = function() {
    console.log('视频播放结束');
    showToast('视频播放结束', 'info');
    stopVideoDetection();
  };

  // 添加视频加载进度监听
  video.onprogress = function() {
    console.log('视频加载进度:', video.buffered.length > 0 ? (video.buffered.end(video.buffered.length - 1) / video.duration * 100).toFixed(2) + '%' : '0%');
  };

  // 添加canplay事件监听
  video.oncanplay = function() {
    console.log('视频可以播放了');
  };

  // 添加canplaythrough事件监听
  video.oncanplaythrough = function() {
    console.log('视频可以流畅播放了');
  };

  // 添加ended事件监听
  video.onended = function() {
    console.log('视频播放结束');
    showToast('视频播放结束', 'info');
    stopVideoDetection();
  };

  // 重置文件输入元素的值，这样即使用户选择了相同的文件，onchange事件也会再次触发
  event.target.value = '';
}

// 从视频中拍照
async function detectVideoFrame(imageData) {
  try {
    const apiResult = await postJson(`${ML_API_BASE}/detect`, {
      imageBase64: imageData,
      lineId: currentLineId,
      realtime: true,
      brightness: brightness,
      clarity: clarity,
      applianceType: applianceType,
      positionThreshold: positionThreshold,
      wrinkleThreshold: wrinkleThreshold,
      stainThreshold: stainThreshold,
      damageThreshold: damageThreshold
    });

    // 绘制标注框
    let annotatedImage = imageData;
    if (apiResult.rawResult && apiResult.rawResult.detections) {
      try {
        annotatedImage = await drawBoundingBoxes(imageData, apiResult.rawResult.detections);
      } catch (error) {
        console.error('绘制标注框失败:', error);
      }
    }

    const result = normalizeDetectResult(apiResult, annotatedImage, imageData, { lineId: currentLineId });
    currentImageData = imageData;
    currentDetectResult = result;
    
    // 只有当检测到完整的能效标签时，才进行勘测（显示检测结果和记录数据）
    // 完整的能效标签意味着 labelLevel 不是 '未识别'，表示标签被正确识别
    if (result.labelLevel !== '未识别') {
      console.log('检测到完整的能效标签，进行勘测');
      showDetectResult(result);
      
      // 所有检测结果都添加到记录中，不仅仅是缺陷
      const now = Date.now();
      if (now - videoLastRecordedAt > 2000) {
        const productId = `V${getCurrentTimeStr()}${String(getCurrentSeq()).padStart(2, '0')}`;
        updateSeq(getCurrentSeq() + 1);
        const record = {
          ...result,
          id: now,
          productId
        };
        currentDetectResult = record;
        allRecords.unshift(record);

        if (isUsingServerStorage) {
          await saveRecordToServer(record);
          totalRecords++;
          totalPages = Math.ceil(totalRecords / RECORDS_PER_PAGE);
        } else {
          saveToLocalStorage();
        }

        renderRecentRecords();
        renderRecords();
        updateStats();
        forceRefreshChart();
        videoLastRecordedAt = now;
      }
    } else {
      console.log('未检测到完整的能效标签，跳过勘测');
    }

    return result;
  } catch (error) {
    console.error('视频检测失败:', error);
    // 返回一个默认的结果，避免视频检测停止
    const result = normalizeDetectResult({}, imageData, imageData, { lineId: currentLineId });
    return result;
  }
}

// 开始视频检测
function startVideoDetection() {
  if (!videoElement) {
    showToast('视频元素不存在', 'error');
    return;
  }

  stopVideoDetection(false);

  // 确保视频正在播放
  if (videoElement.paused) {
    videoElement.play().catch(e => {
      console.error('视频播放失败:', e);
      showToast('视频播放失败，点击视频控件手动播放', 'warning');
    });
  }

  // 检查视频是否已准备就绪
  if (!videoElement.videoWidth || !videoElement.videoHeight) {
    showToast('视频未准备就绪', 'error');
    console.error('视频尺寸为0:', videoElement.videoWidth, 'x', videoElement.videoHeight);
    return;
  }

  videoDetectionActive = true;
  videoLastDetectionAt = 0;
  videoLastRecordedAt = 0;
  let lastFrameData = null;
  let lastLabelLevel = null; // 记录上一次检测到的标签等级
  let lastDefectType = null; // 记录上一次检测到的缺陷类型
  let sameResultCount = 0; // 连续相同结果的计数

  const canvas = document.createElement('canvas');
  canvas.width = videoElement.videoWidth;
  canvas.height = videoElement.videoHeight;
  const ctx = canvas.getContext('2d');

  console.log('视频尺寸:', videoElement.videoWidth, 'x', videoElement.videoHeight);
  console.log('画布尺寸:', canvas.width, 'x', canvas.height);

  const tick = async (timestamp) => {
    if (!videoDetectionActive || !videoElement) return;

    if (videoElement.ended) {
      stopVideoDetection(false);
      return;
    }

    // 自动检测 - 当检测到新的能效标签时进行检测
    if (!videoElement.paused && !videoDetectionRequestInFlight && (timestamp - videoLastDetectionAt > 1000)) {
      try {
        ctx.drawImage(videoElement, 0, 0, canvas.width, canvas.height);
        const imageData = canvas.toDataURL('image/png');
        
        // 简单的帧变化检测
        if (imageData !== lastFrameData) {
          videoDetectionRequestInFlight = true;
          videoLastDetectionAt = timestamp;
          lastFrameData = imageData;
          
          // 检测当前帧
          const result = await detectVideoFrame(imageData);
          
          // 检查是否与上一次检测结果相同
          if (result.labelLevel === lastLabelLevel && result.defectType === lastDefectType) {
            sameResultCount++;
            // 如果连续5次检测结果相同，暂停检测一段时间
            if (sameResultCount >= 5) {
              console.log('连续检测到相同的能效标签，暂停检测5秒');
              videoLastDetectionAt = timestamp + 5000; // 暂停5秒
              sameResultCount = 0;
            }
          } else {
            // 结果不同，重置计数
            lastLabelLevel = result.labelLevel;
            lastDefectType = result.defectType;
            sameResultCount = 0;
          }
        }
      } catch (error) {
        console.error('视频取帧或检测失败:', error);
      } finally {
        videoDetectionRequestInFlight = false;
      }
    }

    videoDetectionFrameHandle = window.requestAnimationFrame(tick);
  };

  videoDetectionFrameHandle = window.requestAnimationFrame(tick);
  videoDetectionInterval = true;

  showToast('视频检测已开始，自动检测新的能效标签', 'success');
}

// 停止视频检测
function stopVideoDetection(showMessage = true) {
  videoDetectionActive = false;
  videoDetectionRequestInFlight = false;
  if (videoDetectionFrameHandle) {
    window.cancelAnimationFrame(videoDetectionFrameHandle);
    videoDetectionFrameHandle = null;
  }
  if (videoDetectionInterval) {
    videoDetectionInterval = null;
    if (showMessage) showToast('视频检测已停止', 'success');
  }
}

// 初始化图表
function initChart() {
  const chartBox = document.getElementById('chartBox');
  if (!chartBox) {
    console.error('图表容器不存在');
    return;
  }
  
  const rect = chartBox.getBoundingClientRect();
  console.log('图表容器尺寸:', rect.width, rect.height);
  
  if (rect.width === 0 || rect.height === 0) {
    console.warn('图表容器尺寸为0，延迟初始化');
    setTimeout(initChart, 100);
    return;
  }
  
  if (chartInstance) {
    chartInstance.dispose();
    chartInstance = null;
  }
  
  chartInstance = echarts.init(chartBox);
  console.log('图表实例已创建');
  
  refreshChart();
  
  window.addEventListener('resize', handleChartResize);
}

// 处理图表大小调整
function handleChartResize() {
  if (chartInstance) {
    chartInstance.resize();
  }
}

// 切换图表类型
function switchChart(type) {
  currentChart = type;
  const chartTabs = document.querySelectorAll('.chart-tab');
  chartTabs.forEach(tab => tab.classList.remove('active'));
  const active = document.querySelector(`.chart-tab[data-chart="${type}"]`);
  if (active) active.classList.add('active');
  refreshChart();
}

// 切换图表时间范围
function changeChartRange(range) {
  chartRange = range;
  const timeBtns = document.querySelectorAll('.time-btn');
  timeBtns.forEach(btn => btn.classList.remove('active'));
  const active = document.querySelector(`.time-btn[data-range="${range}"]`);
  if (active) active.classList.add('active');
  refreshChart();
}

// 初始化操作员筛选 - 修复版，添加管理员选项
function initOperatorFilter() {
  const container = document.getElementById('operatorFilterContainer');
  const select = document.getElementById('operatorFilter');
  if (!container || !select) return;

  if (currentUser && currentUser.role === 'admin') {
    container.classList.remove('hidden');
    
    // 清空现有选项
    select.innerHTML = '';
    
    // 添加"全部操作员"选项
    const allOption = document.createElement('option');
    allOption.value = 'all';
    allOption.textContent = '全部操作员';
    select.appendChild(allOption);
    
    // 添加所有操作员选项
    const operators = users.filter(u => u.role === 'operator');
    operators.forEach(op => {
      const option = document.createElement('option');
      option.value = op.username;
      option.textContent = op.name || op.username;
      select.appendChild(option);
    });
    
    // 添加所有管理员选项
    const admins = users.filter(u => u.role === 'admin');
    if (admins.length > 0) {
      const adminGroup = document.createElement('optgroup');
      adminGroup.label = '管理员';
      admins.forEach(admin => {
        const option = document.createElement('option');
        option.value = admin.username;
        option.textContent = (admin.name || admin.username) + ' (管理员)';
        adminGroup.appendChild(option);
      });
      select.appendChild(adminGroup);
    }
    
    select.value = selectedOperator;
  } else {
    container.classList.add('hidden');
  }
}

// 切换操作员筛选
function changeOperatorFilter(operator) {
  selectedOperator = operator;
  updateStats();
  renderRecentRecords();
  renderRecords();
  refreshChart();
}

// 获取图表基础记录
function getChartBaseRecords() {
  let records = [...allRecords];
  if (currentUser && currentUser.role === 'operator') {
    records = records.filter(r => r.operator === currentUser.username);
  } else if (currentUser && currentUser.role === 'admin' && selectedOperator !== 'all') {
    records = records.filter(r => r.operator === selectedOperator);
  }
  return records;
}

// 获取图表时间范围记录
function getChartRecordsByRange() {
  const records = getChartBaseRecords();

  if (chartRange === 'today') return records.filter(r => new Date(r.time).getTime() >= getTodayStart());
  if (chartRange === '1m' || chartRange === '30d') {
    const d = new Date();
    d.setDate(d.getDate() - 29); // 30天前
    return records.filter(r => new Date(r.time).getTime() >= d.getTime());
  }
  if (chartRange === '1y' || chartRange === '365d') {
    const d = new Date();
    d.setFullYear(d.getFullYear() - 1);
    return records.filter(r => new Date(r.time).getTime() >= d.getTime());
  }
  if (chartRange === '7d') {
    const d = new Date();
    d.setDate(d.getDate() - 6);
    return records.filter(r => new Date(r.time).getTime() >= d.getTime());
  }
  return records;
}

// 刷新图表
function refreshChart() {
  console.log('=== refreshChart 开始 ===');
  console.log('chartInstance:', !!chartInstance);
  console.log('allRecords 数量:', allRecords.length);
  console.log('currentChart:', currentChart);
  console.log('chartRange:', chartRange);
  
  if (!chartInstance) {
    console.warn('chartInstance 不存在，跳过刷新');
    return;
  }

  const records = getChartRecordsByRange();
  console.log('getChartRecordsByRange 返回记录数:', records.length);
  
  const total = records.length;
  const normal = records.filter(r => {
    const types = r.defectTypes || (r.defectType ? [r.defectType] : []);
    return types.length === 0 || types.every(dt => dt === 'NORMAL');
  }).length;
  const defect = total - normal;
  const processed = records.filter(r => r.processed).length;

  console.log('图表数据 - total:', total, 'normal:', normal, 'defect:', defect, 'processed:', processed);

  const summaryTotal = document.getElementById('summaryTotal');
  const summaryNormal = document.getElementById('summaryNormal');
  const summaryDefect = document.getElementById('summaryDefect');
  const summaryProcessed = document.getElementById('summaryProcessed');
  
  if (summaryTotal) summaryTotal.textContent = total;
  if (summaryNormal) summaryNormal.textContent = total ? ((normal / total) * 100).toFixed(1) + '%' : '0%';
  if (summaryDefect) summaryDefect.textContent = total ? ((defect / total) * 100).toFixed(1) + '%' : '0%';
  if (summaryProcessed) summaryProcessed.textContent = total ? ((processed / total) * 100).toFixed(1) + '%' : '0%';

  let option = {};

  if (currentChart === 'trend') {
    const dateMap = {};
    const today = new Date();
    
    let days = 7;
    if (chartRange === 'today') days = 1;
    else if (chartRange === '7d') days = 7;
    else if (chartRange === '1m') days = 30;
    else if (chartRange === '1y') days = 365;
    
    for (let i = days - 1; i >= 0; i--) {
      const d = new Date(today);
      d.setDate(d.getDate() - i);
      const dateStr = d.toISOString().slice(0, 10);
      dateMap[dateStr] = 0;
    }
    
    records.forEach(r => {
      let dateStr = '';
      if (typeof r.time === 'string') {
        dateStr = r.time.slice(0, 10);
      } else if (r.time instanceof Date) {
        dateStr = r.time.toISOString().slice(0, 10);
      }
      if (dateStr && dateMap.hasOwnProperty(dateStr)) {
        dateMap[dateStr] = (dateMap[dateStr] || 0) + 1;
      }
    });

    const dates = Object.keys(dateMap).sort();
    const values = dates.map(d => dateMap[d]);
    const displayDates = dates.map(d => {
      const date = new Date(d);
      return `${date.getMonth() + 1}/${date.getDate()}`;
    });

    option = {
      title: { 
        text: '检测数量', 
        left: 'center', 
        textStyle: { fontSize: 16, fontWeight: 'bold' },
        top: 10
      },
      tooltip: { 
        trigger: 'axis',
        backgroundColor: 'rgba(255,255,255,0.95)',
        borderColor: '#e5e7eb',
        borderWidth: 1,
        textStyle: { color: '#1f2937' },
        formatter: function(params) {
          const date = dates[params[0].dataIndex];
          const value = params[0].value;
          return `<div style="font-weight:bold;margin-bottom:5px">${date}</div>
                  <div style="display:flex;align-items:center;gap:8px">
                    <span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:#3b82f6"></span>
                    检测数量: <strong>${value}</strong>
                  </div>`;
        }
      },
      grid: {
        left: '3%',
        right: '4%',
        bottom: '10%',
        top: '15%',
        containLabel: true
      },
      xAxis: { 
        type: 'category', 
        boundaryGap: false, 
        data: displayDates,
        axisLine: { lineStyle: { color: '#e5e7eb' } },
        axisLabel: {
          color: '#6b7280',
          fontSize: 12,
          rotate: dates.length > 10 ? 45 : 0
        },
        axisTick: { show: false }
      },
      yAxis: { 
        type: 'value', 
        minInterval: 1,
        axisLine: { show: false },
        axisTick: { show: false },
        axisLabel: { color: '#6b7280', fontSize: 12 },
        splitLine: {
          lineStyle: {
            type: 'dashed',
            color: '#e5e7eb'
          }
        }
      },
      series: [{
        name: '检测数量',
        type: 'line',
        smooth: true,
        data: values,
        symbol: 'circle',
        symbolSize: 8,
        lineStyle: { 
          width: 3, 
          color: '#3b82f6',
          shadowColor: 'rgba(59,130,246,0.3)',
          shadowBlur: 10,
          shadowOffsetY: 5
        },
        itemStyle: { 
          color: '#3b82f6',
          borderColor: '#fff',
          borderWidth: 2
        },
        areaStyle: { 
          color: {
            type: 'linear',
            x: 0, y: 0, x2: 0, y2: 1,
            colorStops: [
              { offset: 0, color: 'rgba(59,130,246,0.4)' },
              { offset: 1, color: 'rgba(59,130,246,0.05)' }
            ]
          }
        },
        label: {
          show: true,
          position: 'top',
          formatter: '{c}',
          fontSize: 12,
          color: '#3b82f6',
          fontWeight: 'bold',
          distance: 8
        }
      }]
    };
  }

  if (currentChart === 'defect') {
    const defectMap = {};
    records.forEach(r => {
      const defectTypes = r.defectTypes || (r.defectType ? [r.defectType] : []);
      defectTypes.forEach(dt => {
        if (dt !== 'NORMAL') {
          const name = DEFECT_TYPE_LABELS[dt] || dt;
          defectMap[name] = (defectMap[name] || 0) + 1;
        }
      });
    });

    const data = Object.keys(defectMap).map(name => ({ name, value: defectMap[name] }));
    const colors = ['#ef4444', '#f59e0b', '#8b5cf6', '#ec4899'];

    option = {
      title: { text: '缺陷占比', left: 'center', textStyle: { fontSize: 16, fontWeight: 'bold' }, top: 10 },
      tooltip: { 
        trigger: 'item',
        formatter: '{b}: {c} ({d}%)'
      },
      legend: {
        orient: 'vertical',
        left: 'left',
        top: 'center'
      },
      series: [{
        type: 'pie',
        radius: ['40%', '70%'],
        center: ['60%', '50%'],
        avoidLabelOverlap: true,
        itemStyle: {
          borderRadius: 8,
          borderColor: '#fff',
          borderWidth: 2
        },
        label: {
          show: true,
          formatter: '{b}\n{c} ({d}%)'
        },
        emphasis: {
          label: {
            show: true,
            fontSize: 14,
            fontWeight: 'bold'
          }
        },
        data: data.map((item, index) => ({
          ...item,
          itemStyle: { color: colors[index % colors.length] }
        }))
      }]
    };
  }

  if (currentChart === 'line') {
    const lineMap = {};
    currentLines.forEach(line => {
      lineMap[line.name] = records.filter(r => r.lineId === line.id).length;
    });

    const names = Object.keys(lineMap);
    const values = names.map(name => lineMap[name]);
    const colors = ['#3b82f6', '#22c55e', '#f59e0b', '#ef4444', '#8b5cf6'];

    option = {
      title: { text: '产线统计', left: 'center', textStyle: { fontSize: 16, fontWeight: 'bold' }, top: 10 },
      tooltip: { 
        trigger: 'axis',
        axisPointer: { type: 'shadow' }
      },
      grid: {
        left: '3%',
        right: '4%',
        bottom: '3%',
        top: '15%',
        containLabel: true
      },
      xAxis: {
        type: 'category',
        data: names,
        axisLabel: {
          interval: 0,
          rotate: 30
        }
      },
      yAxis: {
        type: 'value',
        minInterval: 1
      },
      series: [{
        data: values,
        type: 'bar',
        barWidth: '60%',
        itemStyle: {
          color: function(params) {
            return colors[params.dataIndex % colors.length];
          },
          borderRadius: [4, 4, 0, 0]
        },
        label: {
          show: true,
          position: 'top',
          formatter: '{c}'
        }
      }]
    };
  }

  if (currentChart === 'level') {
    const levelMap = {};
    LEVEL_ORDER.forEach(level => {
      levelMap[level] = records.filter(r => r.labelLevel === level).length;
    });

    console.log('能级统计 - levelMap:', levelMap);
    console.log('能级统计 - records sample:', records.slice(0, 3).map(r => ({ labelLevel: r.labelLevel })));

    const allLevels = [...LEVEL_ORDER];
    const data = allLevels.map(level => levelMap[level] || 0);
    const maxValue = Math.max(...data, 1); // 确保至少为1，避免雷达图显示异常
    const indicator = allLevels.map(level => ({ name: level, max: maxValue + 1 }));
    const colors = ['#22c55e', '#3b82f6', '#f59e0b', '#f97316', '#ef4444', '#8b5cf6', '#ec4899', '#14b8a6'];

    option = {
      title: { text: '能级统计', left: 'center', textStyle: { fontSize: 16, fontWeight: 'bold' }, top: 10 },
      tooltip: { 
        trigger: 'item'
      },
      radar: {
        indicator: indicator,
        radius: '70%',
        center: ['50%', '60%']
      },
      series: [{
        type: 'radar',
        data: [{
          value: data,
          name: '能级分布',
          areaStyle: {
            color: 'rgba(59, 130, 246, 0.2)'
          },
          lineStyle: {
            color: '#3b82f6',
            width: 2
          },
          itemStyle: {
            color: '#3b82f6'
          },
          label: {
            show: true,
            position: 'inside',
            formatter: '{c}'
          }
        }]
      }]
    };
  }

  if (currentChart === 'status') {
    option = {
      title: { text: '正常/缺陷占比', left: 'center', textStyle: { fontSize: 16, fontWeight: 'bold' }, top: 10 },
      tooltip: { 
        trigger: 'item',
        formatter: '{b}: {c} ({d}%)'
      },
      legend: {
        orient: 'vertical',
        left: 'left',
        top: 'center'
      },
      series: [{
        type: 'pie',
        radius: ['40%', '70%'],
        center: ['60%', '50%'],
        avoidLabelOverlap: true,
        itemStyle: {
          borderRadius: 8,
          borderColor: '#fff',
          borderWidth: 2
        },
        label: {
          show: true,
          formatter: '{b}\n{c} ({d}%)'
        },
        data: [
          { name: '正常', value: normal, itemStyle: { color: '#22c55e' } },
          { name: '缺陷', value: defect, itemStyle: { color: '#ef4444' } }
        ]
      }]
    };
  }

  if (currentChart === 'appliance') {
    const applianceMap = {};
    records.forEach(record => {
      if (record.applianceType) {
        applianceMap[record.applianceType] = (applianceMap[record.applianceType] || 0) + 1;
      }
    });

    const names = Object.keys(applianceMap);
    const values = names.map(name => applianceMap[name]);
    const colors = ['#3b82f6', '#22c55e', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#14b8a6', '#f43f5e', '#06b6d4', '#84cc16', '#f97316', '#a855f7'];

    option = {
      title: { text: '电器类型统计', left: 'center', textStyle: { fontSize: 16, fontWeight: 'bold' }, top: 10 },
      tooltip: { 
        trigger: 'axis',
        axisPointer: { type: 'shadow' }
      },
      grid: {
        left: '3%',
        right: '4%',
        bottom: '3%',
        top: '15%',
        containLabel: true
      },
      xAxis: {
        type: 'category',
        data: names,
        axisLabel: {
          interval: 0,
          rotate: 45
        }
      },
      yAxis: {
        type: 'value',
        minInterval: 1
      },
      series: [{
        data: values,
        type: 'bar',
        barWidth: '60%',
        itemStyle: {
          color: function(params) {
            return colors[params.dataIndex % colors.length];
          },
          borderRadius: [4, 4, 0, 0]
        },
        label: {
          show: true,
          position: 'top',
          formatter: '{c}'
        }
      }]
    };
  }

  chartInstance.setOption(option, true);
}

// 更新统计数据
function updateStats() {
  const records = getChartBaseRecords();

  const total = records.length;
  const normal = records.filter(r => {
    const types = r.defectTypes || (r.defectType ? [r.defectType] : []);
    return types.length === 0 || types.every(dt => dt === 'NORMAL');
  }).length;
  const defect = total - normal;
  const processed = records.filter(r => r.processed).length;
  const pending = total - processed;

  const todayStart = getTodayStart();
  const monthStart = getMonthStart();

  const todayCount = records.filter(r => new Date(r.time).getTime() >= todayStart).length;
  const monthCount = records.filter(r => new Date(r.time).getTime() >= monthStart).length;

  const statTotal = document.getElementById('statTotal');
  const statNormal = document.getElementById('statNormal');
  const statDefect = document.getElementById('statDefect');
  const statPending = document.getElementById('statPending');
  const statToday = document.getElementById('statToday');
  const statMonth = document.getElementById('statMonth');
  
  if (statTotal) statTotal.textContent = total;
  if (statNormal) statNormal.textContent = normal;
  if (statDefect) statDefect.textContent = defect;
  if (statPending) statPending.textContent = pending;
  if (statToday) statToday.textContent = todayCount;
  if (statMonth) statMonth.textContent = monthCount;
}

// 强制刷新图表数据
function forceRefreshChart() {
  const chartTab = document.getElementById('tab-charts');
  if (chartTab && !chartTab.classList.contains('hidden')) {
    // 图表可见时直接刷新
    initChart();
  } else if (chartInstance) {
    // 图表不可见但实例存在时，只更新数据
    refreshChart();
  }
}

// 切换标签页
function showTab(tabName) {
  const tabSections = document.querySelectorAll('.tab-section');
  tabSections.forEach(tab => tab.classList.add('hidden'));

  const targetTab = document.getElementById('tab-' + tabName);
  if (targetTab) targetTab.classList.remove('hidden');

  const menuItems = document.querySelectorAll('.menu-item');
  menuItems.forEach(item => item.classList.remove('active'));

  const activeItem = document.querySelector(`.menu-item[data-tab="${tabName}"]`);
  if (activeItem) activeItem.classList.add('active');

  const titles = {
    dashboard: { title: '数据总览', subtitle: '实时查看检测数据与统计信息' },
    detect: { title: '检测中心', subtitle: '拍照检测、OCR识别与缺陷分析' },
    records: { title: '检测记录', subtitle: '查看和筛选历史检测数据' },
    charts: { title: '统计图表', subtitle: '多维度数据分析与可视化' },
    lines: { title: '产线配置', subtitle: '管理检测产线与设备' },
    users: { title: '用户管理', subtitle: '管理系统用户与权限' }
  };

  const info = titles[tabName] || titles.dashboard;

  const pageTitle = document.getElementById('pageTitle');
  const pageSubtitle = document.getElementById('pageSubtitle');

  if (pageTitle) pageTitle.textContent = info.title;
  if (pageSubtitle) pageSubtitle.textContent = info.subtitle;

  if (tabName === 'charts') {
    setTimeout(() => {
      initChart();
      initOperatorFilter();
    }, 50);
  }

  if (tabName === 'dashboard') {
    updateStats();
    renderRecentRecords();
  }

  if (tabName === 'records') renderRecords();
  if (tabName === 'users') renderUserList();
  if (tabName === 'lines') renderLineList();
}

// 渲染用户列表
function renderUserList() {
  const list = document.getElementById('userList');
  if (!list) return;

  const displayUsers = users.filter(u => u.role !== 'qc');
  list.innerHTML = displayUsers.map(u => `
    <div class="user-item">
      <div class="user-avatar-sm">${escapeHtml(u.name ? u.name.charAt(0) : u.username.charAt(0))}</div>
      <div class="user-details">
        <div class="user-name-row">
          ${escapeHtml(u.name || u.username)}
          <span class="user-role-badge ${u.role}">${u.role === 'admin' ? '管理员' : '操作员'}</span>
        </div>
        <div class="user-meta-row">账号：${escapeHtml(u.username)}</div>
      </div>
      <div class="line-actions">
        <button class="btn btn-secondary btn-sm" onclick="editUser(${u.id})">编辑</button>
        <button class="btn btn-danger btn-sm" onclick="deleteUser(${u.id})">删除</button>
      </div>
    </div>
  `).join('');
}

// 添加用户
function addUser() {
  const username = prompt('请输入用户名:');
  if (!username) return;
  
  const saved = localStorage.getItem('users');
  if (saved) {
    users = JSON.parse(saved);
  }
  
  if (users.some(u => u.username === username)) {
    showToast('用户名已存在', 'error');
    return;
  }

  const name = prompt('请输入姓名:');
  if (!name) return;
  const password = prompt('请输入密码:');
  if (!password) return;
  const role = prompt('请输入角色 (admin/operator):', 'operator');
  if (!role || (role !== 'admin' && role !== 'operator')) {
    showToast('角色只能是 admin 或 operator', 'error');
    return;
  }

  users.push({ id: Date.now(), username, password, role, name });
  saveUsersToStorage();
  renderUserList();
  initOperatorFilter();
  showToast('用户添加成功', 'success');
}

// 删除用户
function deleteUser(userId) {
  if (!confirm('确定要删除该用户吗？')) return;
  const index = users.findIndex(u => u.id === userId);
  if (index > -1) {
    users.splice(index, 1);
    saveUsersToStorage();
    renderUserList();
    initOperatorFilter();
    showToast('用户删除成功', 'success');
  }
}

// 编辑用户
function editUser(userId) {
  const user = users.find(u => u.id === userId);
  if (!user) return;

  const newName = prompt('请输入新姓名:', user.name);
  if (newName === null) return;
  const newRole = prompt('请输入新角色 (admin/operator):', user.role);
  if (newRole === null) return;
  if (newRole !== 'admin' && newRole !== 'operator') {
    showToast('角色只能是 admin 或 operator', 'error');
    return;
  }

  user.name = newName || user.name;
  user.role = newRole || user.role;

  saveUsersToStorage();
  renderUserList();
  initOperatorFilter();
  updateMenuByRole();
  showToast('用户修改成功', 'success');
}

// 打开帮助模态框
function openHelpModal() { 
  const helpModal = document.getElementById('helpModal');
  if (helpModal) helpModal.classList.remove('hidden'); 
}

// 添加测试记录（用于调试）
function addTestRecord() {
  // 小的base64图片（1x1红色像素）
  const testImage = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==';
  
  // 模拟检测结果
  const result = {
    id: Date.now(),
    productId: 'P' + getCurrentTimeStr() + '00',
    operator: currentUser ? currentUser.username : 'admin',
    operatorName: currentUser ? currentUser.name : '管理员',
    lineId: currentLineId,
    labelLevel: '一级能效',
    defectType: 'NORMAL',
    defectDetail: '检测完成',
    confidence: 0.95,
    time: new Date().toISOString(),
    processed: true,
    imageData: testImage,
    originalImageData: testImage,
    applianceType: applianceType
  };
  
  // 添加到记录
  currentDetectResult = result;
  allRecords.unshift(result);

  if (isUsingServerStorage) {
    saveRecordToServer(result);
    totalRecords++;
    totalPages = Math.ceil(totalRecords / RECORDS_PER_PAGE);
  } else {
    saveToLocalStorage();
  }

  renderRecentRecords();
  renderRecords();
  updateStats();
  forceRefreshChart();

  showToast('测试记录已添加！', 'success');
  console.log('添加了测试记录:', result);
}

// 关闭帮助模态框
function closeHelpModal(e) {
  const helpModal = document.getElementById('helpModal');
  if (!e || e.target === helpModal || e.target.closest('.modal-close')) {
    if (helpModal) helpModal.classList.add('hidden');
  }
}

// 查看图片
function viewImage(id) {
  const record = allRecords.find(r => r.id === id);
  if (record && record.imageData) {
    const modalImage = document.getElementById('modalImage');
    const imageModal = document.getElementById('imageModal');
    if (modalImage) modalImage.src = record.imageData;
    if (imageModal) imageModal.classList.remove('hidden');
  }
}

// 关闭图片模态框
function closeImageModal() { 
  const imageModal = document.getElementById('imageModal');
  if (imageModal) imageModal.classList.add('hidden'); 
}

// 将base64图片数据转换为Excel可用的格式
function base64ToArrayBuffer(base64) {
  const base64Data = base64.split(',')[1];
  if (!base64Data) return null;
  
  const binaryString = window.atob(base64Data);
  const bytes = new Uint8Array(binaryString.length);
  for (let i = 0; i < binaryString.length; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes.buffer;
}

// 搜索产品编号
function searchByProductId() {
  const searchInput = document.getElementById('searchInput');
  if (!searchInput) return;
  
  currentSearchQuery = searchInput.value.trim();
  renderRecords();
  showToast(`搜索产品编号: ${currentSearchQuery}`, 'info');
}

function clearSearch() {
  const searchInput = document.getElementById('searchInput');
  if (searchInput) {
    searchInput.value = '';
  }
  currentSearchQuery = '';
  renderRecords();
  showToast('搜索已清除', 'info');
}

// 导出Excel - 带图片版本
function exportToExcel() {
  try {
    let records = getFilteredRecordsForCurrentView();
    
    // 根据选择的时间范围过滤
    const exportRange = document.getElementById('exportRange');
    if (exportRange) {
      const range = exportRange.value;
      const now = new Date();
      let startDate;
      
      switch (range) {
        case 'today':
          startDate = new Date(now.getFullYear(), now.getMonth(), now.getDate());
          break;
        case '7d':
          startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
          break;
        case '30d':
          startDate = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
          break;
        case '365d':
          startDate = new Date(now.getTime() - 365 * 24 * 60 * 60 * 1000);
          break;
        default:
          startDate = null;
      }
      
      if (startDate) {
        records = records.filter(r => new Date(r.time) >= startDate);
      }
    }
    
    if (!records.length) return showToast('暂无可导出的数据', 'warning');

    // 检查XLSX库是否加载
    if (typeof XLSX === 'undefined') {
      showToast('Excel导出库未加载', 'error');
      return;
    }

    // 创建工作簿
    const wb = XLSX.utils.book_new();
    
    // 准备数据（删除图片列）
    const data = records.map(r => {
      const defectTypes = r.defectTypes || (r.defectType ? [r.defectType] : []);
      const defectTypeLabels = defectTypes.map(dt => DEFECT_TYPE_LABELS[dt] || dt);
      return {
        产品编号: r.productId || 'N/A',
        检测时间: formatDateTime(r.time),
        操作人员: r.operatorName || r.operator,
        产线: currentLines.find(l => l.id === r.lineId)?.name || r.lineId,
        电器类别: r.applianceType || '-',
        能效等级: r.labelLevel,
        缺陷类型: defectTypeLabels.join('、'),
        缺陷说明: (r.defectDetails || []).join('；') || r.defectDetail || '',
        置信度: `${(r.confidence * 100).toFixed(1)}%`,
        处理状态: r.processed ? '已处理' : '未处理'
      };
    });

    // 计算详细统计数据
    const total = records.length;
    const normal = records.filter(r => {
      const types = r.defectTypes || (r.defectType ? [r.defectType] : []);
      return types.length === 0 || types.every(dt => dt === 'NORMAL');
    }).length;
    const defect = total - normal;
    const processed = records.filter(r => r.processed).length;
    
    // 计算百分比
    const normalPercent = total > 0 ? ((normal / total) * 100).toFixed(1) : '0.0';
    const defectPercent = total > 0 ? ((defect / total) * 100).toFixed(1) : '0.0';
    
    // 计算平均置信度
    const avgConfidence = records.reduce((sum, r) => sum + (r.confidence || 0), 0) / total;
    const highConfidenceCount = records.filter(r => (r.confidence || 0) > 0.9).length;
    const highConfidenceRate = total > 0 ? ((highConfidenceCount / total) * 100).toFixed(1) : '0.0';
    
    // 统计各缺陷类型
    const defectTypes = {};
    records.forEach(r => {
      const types = r.defectTypes || (r.defectType ? [r.defectType] : []);
      types.forEach(dt => {
        if (dt !== 'NORMAL') {
          defectTypes[dt] = (defectTypes[dt] || 0) + 1;
        }
      });
    });
    
    // 统计产线性能
    const linePerformance = {};
    records.forEach(r => {
      if (!linePerformance[r.lineId]) {
        linePerformance[r.lineId] = { total: 0, defect: 0 };
      }
      linePerformance[r.lineId].total++;
      const types = r.defectTypes || (r.defectType ? [r.defectType] : []);
      if (!types.every(dt => dt === 'NORMAL')) {
        linePerformance[r.lineId].defect++;
      }
    });
    
    // 统计时间分布
    const timeDistribution = {};
    records.forEach(r => {
      const hour = new Date(r.time).getHours();
      const hourStr = `${hour}:00`;
      timeDistribution[hourStr] = (timeDistribution[hourStr] || 0) + 1;
    });
    
    // 统计电器类型分布
    const applianceTypeDistribution = {};
    records.forEach(r => {
      if (r.applianceType) {
        applianceTypeDistribution[r.applianceType] = (applianceTypeDistribution[r.applianceType] || 0) + 1;
      }
    });
    
    // 统计置信度分布
    const confidenceDistribution = {
      low: 0,  // < 0.7
      medium: 0,  // 0.7-0.9
      high: 0  // > 0.9
    };
    records.forEach(r => {
      const confidence = r.confidence || 0;
      if (confidence < 0.7) {
        confidenceDistribution.low++;
      } else if (confidence < 0.9) {
        confidenceDistribution.medium++;
      } else {
        confidenceDistribution.high++;
      }
    });
    
    // 构建汇总数据
    const summaryData = [
      {},
      { 产品编号: '', 检测时间: '汇总统计', 操作人员: '', 产线: '', 电器类别: '', 能效等级: '', 缺陷类型: '', 缺陷说明: '', 置信度: '', 处理状态: '' },
      { 产品编号: '', 检测时间: '总检测数', 操作人员: total, 产线: '', 电器类别: '', 能效等级: '', 缺陷类型: '', 缺陷说明: '', 置信度: '', 处理状态: '' },
      { 产品编号: '', 检测时间: '正常标签', 操作人员: `${normal} (${normalPercent}%)`, 产线: '', 电器类别: '', 能效等级: '', 缺陷类型: '', 缺陷说明: '', 置信度: '', 处理状态: '' },
      { 产品编号: '', 检测时间: '缺陷标签', 操作人员: `${defect} (${defectPercent}%)`, 产线: '', 电器类别: '', 能效等级: '', 缺陷类型: '', 缺陷说明: '', 置信度: '', 处理状态: '' },
      { 产品编号: '', 检测时间: '已处理', 操作人员: processed, 产线: '', 电器类别: '', 能效等级: '', 缺陷类型: '', 缺陷说明: '', 置信度: '', 处理状态: '' },
      { 产品编号: '', 检测时间: '未处理', 操作人员: total - processed, 产线: '', 电器类别: '', 能效等级: '', 缺陷类型: '', 缺陷说明: '', 置信度: '', 处理状态: '' },
      { 产品编号: '', 检测时间: '平均置信度', 操作人员: `${(avgConfidence * 100).toFixed(1)}%`, 产线: '', 电器类别: '', 能效等级: '', 缺陷类型: '', 缺陷说明: '', 置信度: '', 处理状态: '' },
      { 产品编号: '', 检测时间: '高置信度(>0.9)占比', 操作人员: `${highConfidenceRate}%`, 产线: '', 电器类别: '', 能效等级: '', 缺陷类型: '', 缺陷说明: '', 置信度: '', 处理状态: '' }
    ];
    
    // 添加各缺陷类型统计
    Object.entries(defectTypes).forEach(([type, count]) => {
      const percent = total > 0 ? ((count / total) * 100).toFixed(1) : '0.0';
      const defectPercentOfTotal = defect > 0 ? ((count / defect) * 100).toFixed(1) : '0.0';
      summaryData.push({
        产品编号: '',
        检测时间: `缺陷类型: ${DEFECT_TYPE_LABELS[type] || type}`,
        操作人员: `${count} (${percent}%)`,
        产线: `占缺陷总数: ${defectPercentOfTotal}%`,
        电器类别: '',
        能效等级: '',
        缺陷类型: '',
        缺陷说明: '',
        置信度: '',
        处理状态: ''
      });
    });
    
    // 添加产线性能统计
    summaryData.push({ 产品编号: '', 检测时间: '', 操作人员: '', 产线: '', 电器类别: '', 能效等级: '', 缺陷类型: '', 缺陷说明: '', 置信度: '', 处理状态: '' });
    summaryData.push({ 产品编号: '', 检测时间: '产线性能统计', 操作人员: '', 产线: '', 电器类别: '', 能效等级: '', 缺陷类型: '', 缺陷说明: '', 置信度: '', 处理状态: '' });
    Object.entries(linePerformance).forEach(([lineId, performance]) => {
      const lineName = currentLines.find(l => l.id === lineId)?.name || lineId;
      const defectRate = performance.total > 0 ? ((performance.defect / performance.total) * 100).toFixed(1) : '0.0';
      summaryData.push({
        产品编号: '',
        检测时间: `产线: ${lineName}`,
        操作人员: `检测数: ${performance.total}`,
        产线: `缺陷数: ${performance.defect}`,
        电器类别: `缺陷率: ${defectRate}%`,
        能效等级: '',
        缺陷类型: '',
        缺陷说明: '',
        置信度: '',
        处理状态: ''
      });
    });
    
    // 添加电器类型分布统计
    summaryData.push({ 产品编号: '', 检测时间: '', 操作人员: '', 产线: '', 电器类别: '', 能效等级: '', 缺陷类型: '', 缺陷说明: '', 置信度: '', 处理状态: '' });
    summaryData.push({ 产品编号: '', 检测时间: '电器类型分布', 操作人员: '', 产线: '', 电器类别: '', 能效等级: '', 缺陷类型: '', 缺陷说明: '', 置信度: '', 处理状态: '' });
    Object.entries(applianceTypeDistribution)
      .sort((a, b) => b[1] - a[1])
      .forEach(([type, count]) => {
        const percent = total > 0 ? ((count / total) * 100).toFixed(1) : '0.0';
        summaryData.push({
          产品编号: '',
          检测时间: `电器类型: ${type}`,
          操作人员: `检测数: ${count}`,
          产线: `占比: ${percent}%`,
          电器类别: '',
          能效等级: '',
          缺陷类型: '',
          缺陷说明: '',
          置信度: '',
          处理状态: ''
        });
      });
    
    // 添加置信度分布统计
    summaryData.push({ 产品编号: '', 检测时间: '', 操作人员: '', 产线: '', 电器类别: '', 能效等级: '', 缺陷类型: '', 缺陷说明: '', 置信度: '', 处理状态: '' });
    summaryData.push({ 产品编号: '', 检测时间: '置信度分布', 操作人员: '', 产线: '', 电器类别: '', 能效等级: '', 缺陷类型: '', 缺陷说明: '', 置信度: '', 处理状态: '' });
    summaryData.push({
      产品编号: '',
      检测时间: '低置信度 (< 0.7)',
      操作人员: `检测数: ${confidenceDistribution.low}`,
      产线: `占比: ${total > 0 ? ((confidenceDistribution.low / total) * 100).toFixed(1) : '0.0'}%`,
      电器类别: '',
      能效等级: '',
      缺陷类型: '',
      缺陷说明: '',
      置信度: '',
      处理状态: ''
    });
    summaryData.push({
      产品编号: '',
      检测时间: '中置信度 (0.7-0.9)',
      操作人员: `检测数: ${confidenceDistribution.medium}`,
      产线: `占比: ${total > 0 ? ((confidenceDistribution.medium / total) * 100).toFixed(1) : '0.0'}%`,
      电器类别: '',
      能效等级: '',
      缺陷类型: '',
      缺陷说明: '',
      置信度: '',
      处理状态: ''
    });
    summaryData.push({
      产品编号: '',
      检测时间: '高置信度 (> 0.9)',
      操作人员: `检测数: ${confidenceDistribution.high}`,
      产线: `占比: ${total > 0 ? ((confidenceDistribution.high / total) * 100).toFixed(1) : '0.0'}%`,
      电器类别: '',
      能效等级: '',
      缺陷类型: '',
      缺陷说明: '',
      置信度: '',
      处理状态: ''
    });
    
    // 添加时间分布统计
    summaryData.push({ 产品编号: '', 检测时间: '', 操作人员: '', 产线: '', 电器类别: '', 能效等级: '', 缺陷类型: '', 缺陷说明: '', 置信度: '', 处理状态: '' });
    summaryData.push({ 产品编号: '', 检测时间: '时间分布统计', 操作人员: '', 产线: '', 电器类别: '', 能效等级: '', 缺陷类型: '', 缺陷说明: '', 置信度: '', 处理状态: '' });
    Object.entries(timeDistribution)
      .sort((a, b) => b[1] - a[1])
      .forEach(([hour, count]) => {
        const percent = total > 0 ? ((count / total) * 100).toFixed(1) : '0.0';
        summaryData.push({
          产品编号: '',
          检测时间: `时段: ${hour}`,
          操作人员: `检测数: ${count}`,
          产线: `占比: ${percent}%`,
          电器类别: '',
          能效等级: '',
          缺陷类型: '',
          缺陷说明: '',
          置信度: '',
          处理状态: ''
        });
      });

    // 合并数据
    const allData = [...data, ...summaryData];

    // 创建工作表
    const ws = XLSX.utils.json_to_sheet(allData);
    
    // 设置列宽（删除图片列）
    ws['!cols'] = [
      { wch: 20 },  // 产品编号
      { wch: 20 },  // 检测时间
      { wch: 15 },  // 操作员
      { wch: 15 },  // 产线
      { wch: 12 },  // 电器类别
      { wch: 12 },  // 能效等级
      { wch: 12 },  // 缺陷类型
      { wch: 20 },  // 缺陷说明
      { wch: 12 },  // 置信度
      { wch: 12 }   // 处理状态
    ];

    // 添加工作表到工作簿（只添加一次）
    XLSX.utils.book_append_sheet(wb, ws, '检测记录');



    // 生成文件名
    const now = new Date();
    const filename = `检测记录_${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}.xlsx`;

    // 下载文件
    XLSX.writeFile(wb, filename);
    
    showToast(`已导出 ${records.length} 条记录`, 'success');
  } catch (error) {
    console.error('导出Excel失败:', error);
    showToast('导出失败：' + error.message, 'error');
  }
}

// 刷新所有数据
function refreshAll() {
  updateStats();
  renderRecentRecords();
  renderRecords();
  forceRefreshChart();
  showToast('数据已刷新', 'success');
}

// 请求OCR识别
function requestOCR(imageData) {
  return postJson(`${ML_API_BASE}/ocr`, {
    imageBase64: imageData,
    lineId: currentLineId
  });
}

// 运行OCR
function runOCR() {
  if (!currentImageData) {
    showToast('请先上传图片', 'warning');
    return;
  }

  const ocrResult = document.getElementById('ocrResult');
  if (ocrResult) ocrResult.textContent = '正在识别...';

  requestOCR(currentImageData)
    .then(result => {
      if (ocrResult) {
        const score = typeof result.score === 'number' ? `（置信度 ${(result.score * 100).toFixed(1)}%）` : '';
        ocrResult.textContent = `${result.text || 'OCR识别完成'}${score}`;
      }
      showToast('OCR识别完成', 'success');
    })
    .catch(error => {
      if (ocrResult) ocrResult.textContent = 'OCR识别失败，请检查模型服务。';
      showToast(error.message || 'OCR识别失败', 'error');
    });
}

window.runOCR = runOCR;

// AI分析函数
async function analyzeWithAI() {
  console.log('开始AI分析');
  showToast('正在生成AI分析，请稍候...', 'info');
  
  // 显示加载状态
  showAILoading();
  
  try {
    // 获取日期范围
    const exportRange = document.getElementById('exportRange').value;
    const filteredRecords = filterRecordsByDateRange(allRecords, exportRange);
    
    if (filteredRecords.length === 0) {
      hideAILoading();
      showToast('所选时间范围内暂无检测记录，无法进行分析', 'error');
      return;
    }
    
    // 准备详细的分析数据
    const analysisData = {
      records: filteredRecords.map(record => ({
        productId: record.productId,
        defectType: record.defectType,
        defectDetail: record.defectDetail,
        labelLevel: record.labelLevel,
        confidence: record.confidence,
        time: record.time,
        applianceType: record.applianceType,
        lineId: record.lineId
      })),
      stats: getStats(filteredRecords),
      totalRecords: filteredRecords.length,
      generatedAt: new Date().toISOString(),
      detailedStats: {
        defectTypeDistribution: calculateDefectTypeDistribution(filteredRecords),
        applianceTypeDistribution: calculateApplianceTypeDistribution(filteredRecords),
        linePerformance: calculateLinePerformance(filteredRecords),
        timeDistribution: calculateTimeDistribution(filteredRecords),
        confidenceDistribution: calculateConfidenceDistribution(filteredRecords)
      }
    };
    
    console.log('生成默认分析结果');
    // 直接使用默认分析，确保快速响应
    const defaultAnalysis = generateDefaultAnalysis(analysisData);
    
    console.log('显示分析结果');
    // 显示分析结果
    displayAIAnalysis(defaultAnalysis);
    showToast('AI分析生成成功', 'success');
  } catch (error) {
    console.error('AI分析失败:', error);
    hideAILoading();
    showToast('AI分析失败，请重试', 'error');
  }
}

// 计算缺陷类型分布
function calculateDefectTypeDistribution(records) {
  const distribution = {};
  records.forEach(record => {
    const defectTypes = record.defectTypes || (record.defectType ? [record.defectType] : ['NORMAL']);
    defectTypes.forEach(dt => {
      distribution[dt] = (distribution[dt] || 0) + 1;
    });
  });
  return distribution;
}

// 计算电器类型分布
function calculateApplianceTypeDistribution(records) {
  const distribution = {};
  records.forEach(record => {
    const applianceType = record.applianceType || 'other';
    distribution[applianceType] = (distribution[applianceType] || 0) + 1;
  });
  return distribution;
}

// 计算产线性能
function calculateLinePerformance(records) {
  const performance = {};
  records.forEach(record => {
    const lineId = record.lineId || 'unknown';
    if (!performance[lineId]) {
      performance[lineId] = { total: 0, normal: 0, defect: 0 };
    }
    performance[lineId].total++;
    if (record.defectType === 'NORMAL') {
      performance[lineId].normal++;
    } else {
      performance[lineId].defect++;
    }
  });
  // 计算正常率和缺陷率
  Object.keys(performance).forEach(lineId => {
    const p = performance[lineId];
    p.normalRate = p.total > 0 ? (p.normal / p.total) * 100 : 0;
    p.defectRate = p.total > 0 ? (p.defect / p.total) * 100 : 0;
  });
  return performance;
}

// 计算时间分布
function calculateTimeDistribution(records) {
  const distribution = {};
  records.forEach(record => {
    const hour = new Date(record.time).getHours();
    distribution[hour] = (distribution[hour] || 0) + 1;
  });
  return distribution;
}

// 计算置信度分布
function calculateConfidenceDistribution(records) {
  const distribution = {
    low: 0,  // < 0.7
    medium: 0,  // 0.7-0.9
    high: 0  // > 0.9
  };
  records.forEach(record => {
    const confidence = record.confidence || 0;
    if (confidence < 0.7) {
      distribution.low++;
    } else if (confidence < 0.9) {
      distribution.medium++;
    } else {
      distribution.high++;
    }
  });
  return distribution;
}

// 计算能效分布（只统计1-5级）
function calculateEnergyEfficiencyDistribution(records) {
  const distribution = {
    '一级能效': 0,
    '二级能效': 0,
    '三级能效': 0,
    '四级能效': 0,
    '五级能效': 0
  };
  records.forEach(record => {
    const level = record.labelLevel;
    if (distribution.hasOwnProperty(level)) {
      distribution[level]++;
    }
  });
  return distribution;
}

// 生成缺陷类型分布图表的HTML
function generateDefectTypeChartHTML(distribution) {
  const defectTypeMap = {
    'NORMAL': '正常',
    'DAMAGE': '破损',
    'STAIN': '污渍',
    'WRINKLE': '褶皱',
    'POSITION_DEVIATION': '位置偏差'
  };
  
  const labels = Object.keys(distribution).map(key => defectTypeMap[key] || key);
  const values = Object.values(distribution);
  const colors = ['#22c55e', '#ef4444', '#f59e0b', '#8b5cf6', '#3b82f6'];
  
  // 处理空数据情况
  if (labels.length === 0 || values.every(val => val === 0)) {
    return '<div style="display: flex; justify-content: center; align-items: center; height: 100%; font-size: 14px; color: #666;">暂无数据</div>';
  }
  
  let html = '<div style="display: flex; flex-wrap: wrap; justify-content: center; align-items: center; height: 100%;">';
  
  // 生成饼图
  html += '<div style="width: 120px; height: 120px; margin-right: 20px; position: relative;">';
  html += '<svg width="120" height="120" viewBox="0 0 120 120">';
  
  let startAngle = 0;
  const total = values.reduce((sum, val) => sum + val, 0);
  
  // 处理total为0的情况
  if (total > 0) {
    values.forEach((value, index) => {
      const angle = (value / total) * 360;
      const endAngle = startAngle + angle;
      
      const startX = 60 + 50 * Math.cos((startAngle - 90) * Math.PI / 180);
      const startY = 60 + 50 * Math.sin((startAngle - 90) * Math.PI / 180);
      const endX = 60 + 50 * Math.cos((endAngle - 90) * Math.PI / 180);
      const endY = 60 + 50 * Math.sin((endAngle - 90) * Math.PI / 180);
      
      const largeArcFlag = angle > 180 ? 1 : 0;
      
      html += `<path d="M 60 60 L ${startX} ${startY} A 50 50 0 ${largeArcFlag} 1 ${endX} ${endY} Z" fill="${colors[index % colors.length]}" />`;
      startAngle = endAngle;
    });
  } else {
    // 显示一个默认的灰色圆
    html += '<circle cx="60" cy="60" r="50" fill="#e5e7eb" />';
  }
  
  html += '</svg>';
  html += '</div>';
  
  // 生成图例
  html += '<div style="flex: 1; min-width: 200px;">';
  labels.forEach((label, index) => {
    const value = values[index];
    const percentage = total > 0 ? ((value / total) * 100).toFixed(1) : 0;
    html += `<div style="display: flex; align-items: center; margin-bottom: 8px;">`;
    html += `<div style="width: 12px; height: 12px; background-color: ${colors[index % colors.length]}; margin-right: 8px;"></div>`;
    html += `<span style="font-size: 12px;">${label}: ${value} (${percentage}%)</span>`;
    html += '</div>';
  });
  html += '</div>';
  html += '</div>';
  
  return html;
}

// 生成电器类型分布图表的HTML
function generateApplianceTypeChartHTML(distribution) {
  const labels = Object.keys(distribution);
  const values = Object.values(distribution);
  const colors = ['#3b82f6', '#22c55e', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#14b8a6', '#f43f5e', '#06b6d4', '#84cc16', '#f97316', '#a855f7'];
  
  // 处理空数据情况
  if (labels.length === 0 || values.every(val => val === 0)) {
    return '<div style="display: flex; justify-content: center; align-items: center; height: 100%; font-size: 14px; color: #666;">暂无数据</div>';
  }
  
  let html = '<div style="display: flex; flex-direction: column; height: 100%; justify-content: center;">';
  
  // 生成柱状图
  const maxValue = Math.max(...values);
  labels.forEach((label, index) => {
    const value = values[index];
    const percentage = maxValue > 0 ? (value / maxValue) * 100 : 0;
    html += `<div style="display: flex; align-items: center; margin-bottom: 10px;">`;
    html += `<span style="width: 80px; font-size: 12px; margin-right: 10px;">${label}</span>`;
    html += `<div style="flex: 1; height: 20px; background-color: #f3f4f6; border-radius: 4px; overflow: hidden;">`;
    html += `<div style="height: 100%; width: ${percentage}%; background-color: ${colors[index % colors.length]}; border-radius: 4px;"></div>`;
    html += '</div>';
    html += `<span style="width: 40px; font-size: 12px; margin-left: 10px; text-align: right;">${value}</span>`;
    html += '</div>';
  });
  
  html += '</div>';
  
  return html;
}

// 生成基于实际数据的默认分析
function generateDefaultAnalysis(analysisData) {
  const { stats, detailedStats, records } = analysisData;
  const total = stats.total;
  const normal = stats.normal;
  const defect = stats.defect;
  const normalRate = stats.normalRate;
  const defectRate = stats.defectRate;
  
  // 生成总体总结
  let summary = `基于${total}条检测记录的分析，系统总体运行状态${normalRate > 80 ? '良好' : '一般'}。正常标签占比${normalRate.toFixed(1)}%，缺陷标签占比${defectRate.toFixed(1)}%。`;
  
  // 分析缺陷类型
  const defectTypes = Object.entries(detailedStats.defectTypeDistribution)
    .filter(([type]) => type !== 'NORMAL')
    .sort((a, b) => b[1] - a[1]);
  
  if (defectTypes.length > 0) {
    const topDefect = defectTypes[0];
    summary += ` 主要缺陷类型为${DEFECT_TYPE_LABELS[topDefect[0]] || topDefect[0]}，占缺陷总数的${((topDefect[1] / defect) * 100).toFixed(1)}%。`;
  }
  
  // 分析电器类型
  const applianceTypes = Object.entries(detailedStats.applianceTypeDistribution)
    .sort((a, b) => b[1] - a[1]);
  
  if (applianceTypes.length > 0) {
    const topAppliance = applianceTypes[0];
    summary += ` 检测最多的电器类型为${topAppliance[0]}，占总检测数的${((topAppliance[1] / total) * 100).toFixed(1)}%。`;
  }
  
  // 分析产线性能
  const linePerformance = Object.entries(detailedStats.linePerformance)
    .sort((a, b) => b[1].normalRate - a[1].normalRate);
  
  if (linePerformance.length > 1) {
    const bestLine = linePerformance[0];
    const worstLine = linePerformance[linePerformance.length - 1];
    summary += ` 表现最好的产线是${bestLine[0]}，正常率${bestLine[1].normalRate.toFixed(1)}%；表现最差的产线是${worstLine[0]}，正常率${worstLine[1].normalRate.toFixed(1)}%。`;
  }
  
  // 分析置信度
  const confidence = detailedStats.confidenceDistribution;
  const highConfidenceRate = ((confidence.high / total) * 100).toFixed(1);
  summary += ` 高置信度检测（>0.9）占比${highConfidenceRate}%，系统检测可靠性${highConfidenceRate > 70 ? '较高' : '一般'}。`;
  
  // 生成关键发现
  const keyFindings = [];
  
  if (defectTypes.length > 0) {
    keyFindings.push(`主要缺陷类型为${DEFECT_TYPE_LABELS[defectTypes[0][0]] || defectTypes[0][0]}，共${defectTypes[0][1]}次检测`);
  }
  
  if (applianceTypes.length > 0) {
    keyFindings.push(`检测最多的电器类型为${applianceTypeMap[applianceTypes[0][0]] || applianceTypes[0][0]}，共${applianceTypes[0][1]}次检测`);
  }
  
  if (linePerformance.length > 1) {
    keyFindings.push(`产线${linePerformance[0][0]}表现最佳，正常率${linePerformance[0][1].normalRate.toFixed(1)}%`);
    keyFindings.push(`产线${linePerformance[linePerformance.length - 1][0]}表现最差，正常率${linePerformance[linePerformance.length - 1][1].normalRate.toFixed(1)}%`);
  }
  
  keyFindings.push(`高置信度检测（>0.9）占比${highConfidenceRate}%`);
  keyFindings.push(`正常标签占比${normalRate.toFixed(1)}%，缺陷标签占比${defectRate.toFixed(1)}%`);
  
  // 分析时间分布
  const timeDistribution = Object.entries(detailedStats.timeDistribution)
    .sort((a, b) => b[1] - a[1]);
  
  if (timeDistribution.length > 0) {
    const peakHour = timeDistribution[0][0];
    const peakCount = timeDistribution[0][1];
    // 格式化时间为 HH:00 格式
    const formattedTime = `${peakHour.toString().padStart(2, '0')}:00`;
    keyFindings.push(`检测高峰期为${formattedTime}，共${peakCount}次检测`);
  }
  
  // 生成改进建议
  const recommendations = [];
  
  if (defectRate > 20) {
    recommendations.push(`针对主要缺陷类型${DEFECT_TYPE_LABELS[defectTypes[0][0]] || defectTypes[0][0]}，建议加强该类型缺陷的检测标准和培训`);
  }
  
  if (linePerformance.length > 1) {
    recommendations.push(`对表现较差的产线${linePerformance[linePerformance.length - 1][0]}进行设备检查和校准`);
  }
  
  if (highConfidenceRate < 70) {
    recommendations.push(`提高检测置信度，建议调整摄像头参数和检测算法`);
  }
  
  recommendations.push(`定期对检测设备进行维护和校准，确保检测准确性`);
  recommendations.push(`建立缺陷类型数据库，持续优化检测模型`);
  if (timeDistribution.length > 0) {
    const peakHour = timeDistribution[0][0];
    const formattedTime = `${peakHour.toString().padStart(2, '0')}:00`;
    recommendations.push(`根据检测高峰期${formattedTime}，合理安排人员和设备资源`);
  }
  recommendations.push(`对不同电器类型制定针对性的检测标准`);
  recommendations.push(`加强操作人员培训，提高检测技能和判断能力`);
  
  // 评估风险等级
  let riskLevel = 'medium';
  if (normalRate > 90 && highConfidenceRate > 80) {
    riskLevel = 'low';
  } else if (normalRate < 70 || highConfidenceRate < 50) {
    riskLevel = 'high';
  }
  
  // 生成行业动态信息
  const industryNews = `根据最新行业动态，2024-2025年能效标识管理迎来新要求：
• 新版《能源效率标识管理办法》强化了生产者和进口商的标识备案责任
• 能效信息码的推广应用实现了产品全生命周期追溯
• 智能检测技术的普及提升了检测效率和准确性
• 建议关注能效检测新技术，如AI视觉检测和区块链溯源`;

  // 生成最新法规信息
  const latestRegulations = `最新能效标识相关法规标准：
• 《能源效率标识管理办法》（2023年修订版）
• GB 24850-202X 平板电视能效限定值及能效等级
• GB 21455-202X 房间空气调节器能效限定值及能效等级
• GB 12021.2-202X 家用电冰箱能效限定值及能效等级`;

  return {
    summary: summary,
    keyFindings: keyFindings,
    recommendations: recommendations,
    riskLevel: riskLevel,
    industryNews: industryNews,
    latestRegulations: latestRegulations
  };
}

// 显示AI分析加载状态
function showAILoading() {
  console.log('显示加载状态');
  // 隐藏空状态和结果，显示加载状态
  const emptyElement = document.querySelector('.ai-analysis-empty');
  if (emptyElement) {
    emptyElement.classList.add('hidden');
  }
  const resultElement = document.getElementById('aiAnalysisResult');
  if (resultElement) {
    resultElement.classList.add('hidden');
  }
  
  // 创建或显示加载状态
  let loadingElement = document.querySelector('.ai-analysis-loading');
  if (!loadingElement) {
    console.log('创建加载元素');
    loadingElement = document.createElement('div');
    loadingElement.className = 'ai-analysis-loading';
    loadingElement.innerHTML = `
      <div style="text-align: center; padding: 40px 20px;">
        <div style="display: inline-block; width: 40px; height: 40px; border: 4px solid #e2e8f0; border-top: 4px solid #3b82f6; border-radius: 50%; animation: spin 1s linear infinite;"></div>
        <div style="margin-top: 16px; font-size: 14px; color: var(--text-secondary);">正在思考中...</div>
        <div style="margin-top: 8px; font-size: 12px; color: var(--text-secondary);">分析检测数据，生成专业建议</div>
      </div>
      <style>
        @keyframes spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
      </style>
    `;
    const contentElement = document.getElementById('aiAnalysisContent');
    if (contentElement) {
      contentElement.appendChild(loadingElement);
      console.log('加载元素已添加');
    } else {
      console.error('未找到aiAnalysisContent元素');
    }
  } else {
    loadingElement.classList.remove('hidden');
    console.log('显示现有加载元素');
  }
}

// 隐藏AI分析加载状态
function hideAILoading() {
  console.log('隐藏加载状态');
  const loadingElement = document.querySelector('.ai-analysis-loading');
  if (loadingElement) {
    loadingElement.classList.add('hidden');
    console.log('加载元素已隐藏');
  } else {
    console.error('未找到ai-analysis-loading元素');
  }
}

// 显示AI分析结果
function displayAIAnalysis(result) {
  console.log('显示AI分析结果');
  // 隐藏加载状态
  hideAILoading();
  
  // 隐藏空状态，显示结果
  const emptyElement = document.querySelector('.ai-analysis-empty');
  if (emptyElement) {
    emptyElement.classList.add('hidden');
  }
  const resultElement = document.getElementById('aiAnalysisResult');
  if (resultElement) {
    resultElement.classList.remove('hidden');
    console.log('显示结果元素');
  } else {
    console.error('未找到aiAnalysisResult元素');
  }
  
  // 设置分析时间
  const timeElement = document.getElementById('aiAnalysisTime');
  if (timeElement) {
    timeElement.textContent = new Date().toLocaleString();
  }
  
  // 设置总体总结
  const summaryElement = document.getElementById('aiSummary');
  if (summaryElement) {
    summaryElement.textContent = result.summary || '暂无总结';
  }
  
  // 设置关键发现
  const keyFindingsElement = document.getElementById('aiKeyFindings');
  if (keyFindingsElement) {
    keyFindingsElement.innerHTML = '';
    (result.keyFindings || []).forEach(finding => {
      const li = document.createElement('li');
      li.textContent = finding;
      keyFindingsElement.appendChild(li);
    });
  }
  
  // 设置改进建议
  const recommendationsElement = document.getElementById('aiRecommendations');
  if (recommendationsElement) {
    recommendationsElement.innerHTML = '';
    (result.recommendations || []).forEach(recommendation => {
      const li = document.createElement('li');
      li.textContent = recommendation;
      recommendationsElement.appendChild(li);
    });
  }
  
  // 设置风险评估
  const riskLevelElement = document.getElementById('aiRiskLevel');
  if (riskLevelElement) {
    riskLevelElement.textContent = result.riskLevel || 'medium';
    riskLevelElement.className = `risk-badge ${result.riskLevel || 'medium'}`;
  }
  
  // 设置行业动态
  const industryNewsElement = document.getElementById('aiIndustryNews');
  if (industryNewsElement) {
    industryNewsElement.textContent = result.industryNews || '暂无行业动态信息';
  }
  
  // 设置最新法规
  const latestRegulationsElement = document.getElementById('aiLatestRegulations');
  if (latestRegulationsElement) {
    latestRegulationsElement.textContent = result.latestRegulations || '暂无最新法规信息';
  }
}
