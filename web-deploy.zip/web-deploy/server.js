const express = require('express');
const path = require('path');
const fs = require('fs');
const multer = require('multer');
const cors = require('cors');
const http = require('http');

const app = express();
const PORT = process.env.PORT || 8080;
const ML_SERVICE_URL = process.env.ML_SERVICE_URL || '127.0.0.1';
const ML_SERVICE_PORT = process.env.ML_SERVICE_PORT || 8084;
const LLM_API_URL = process.env.LLM_API_URL || 'https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions';
const LLM_MODEL = process.env.LLM_MODEL || 'qwen-plus';
const LLM_API_KEY = process.env.LLM_API_KEY || process.env.DASHSCOPE_API_KEY || '';

const uploadDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const upload = multer({ dest: uploadDir });

app.use(cors());
app.use(express.json({ limit: '25mb' }));
app.use(express.urlencoded({ extended: true, limit: '25mb' }));
app.use('/uploads', express.static(uploadDir));
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.static(__dirname));

function requestML(method, pathname, payload) {
  return new Promise((resolve, reject) => {
    const body = payload ? JSON.stringify(payload) : '';
    const options = {
      hostname: ML_SERVICE_URL,
      port: ML_SERVICE_PORT,
      path: pathname,
      method,
      timeout: 60000,
      headers: payload
        ? {
            'Content-Type': 'application/json',
            'Content-Length': Buffer.byteLength(body)
          }
        : {}
    };

    const req = http.request(options, (res) => {
      let data = '';
      res.on('data', (chunk) => {
        data += chunk;
      });
      res.on('end', () => {
        let parsed = {};
        try {
          parsed = data ? JSON.parse(data) : {};
        } catch (error) {
          return reject(error);
        }

        if (res.statusCode >= 400) {
          const message = parsed.detail || parsed.message || `ML request failed: ${res.statusCode}`;
          return reject(new Error(message));
        }

        resolve(parsed);
      });
    });

    req.on('error', reject);
    req.on('timeout', () => {
      req.destroy();
      reject(new Error('ML request timeout'));
    });

    if (body) req.write(body);
    req.end();
  });
}

async function requestLLM(payload) {
  if (!LLM_API_KEY) {
    throw new Error('未配置大语言模型 API Key，请设置 LLM_API_KEY 或 DASHSCOPE_API_KEY');
  }

  const response = await fetch(LLM_API_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${LLM_API_KEY}`
    },
    body: JSON.stringify(payload)
  });

  let data = {};
  try {
    data = await response.json();
  } catch (error) {
    data = {};
  }

  if (!response.ok) {
    throw new Error(data.error?.message || data.message || `LLM request failed: ${response.status}`);
  }

  return data;
}

function buildAnalysisPrompt(snapshot) {
  const records = Array.isArray(snapshot.records) ? snapshot.records.slice(0, 50) : [];
  const totals = snapshot.totals || {};
  const defectBreakdown = snapshot.defectBreakdown || {};
  const energyBreakdown = snapshot.energyBreakdown || {};
  const lineBreakdown = snapshot.lineBreakdown || {};
  
  const total = totals.total || 0;
  const normal = totals.normal || 0;
  const defect = totals.defect || 0;
  const defectRate = total > 0 ? ((defect / total) * 100).toFixed(1) : '0';
  
  const defectTypes = [];
  if (defectBreakdown.damage > 0) defectTypes.push(`破损:${defectBreakdown.damage}次`);
  if (defectBreakdown.stain > 0) defectTypes.push(`污渍:${defectBreakdown.stain}次`);
  if (defectBreakdown.wrinkle > 0) defectTypes.push(`褶皱:${defectBreakdown.wrinkle}次`);
  if (defectBreakdown.positionDeviation > 0) defectTypes.push(`位置偏差:${defectBreakdown.positionDeviation}次`);
  
  const lines = Object.entries(lineBreakdown).map(([line, count]) => `${line}:${count}次`).join('、');
  
  const energyDistribution = Object.entries(energyBreakdown).map(([level, count]) => `${level}:${count}个`).join('、');
  
  const recentRecords = records.slice(0, 10).map((r, i) => {
    return `${i+1}. ${r.labelLevel || '未识别'} | ${r.defectType === 'NORMAL' ? '正常' : r.defectType} | ${r.operatorName || '操作员'} | ${new Date(r.time).toLocaleString('zh-CN')}`;
  }).join('\n');
  
  const system = `你是一名工业质检分析专家，专注于能效标签检测质量分析。
你的职责是根据真实检测数据，给出详细、具体、可执行的改进建议。
分析要基于数据事实，不要空泛套话，要深入分析数据背后的原因。
必须输出有效的JSON格式，内容要详细且有深度。
重要：你有联网搜索能力，请搜索最新的能效标签行业动态、法规更新、技术标准等信息，结合这些实时信息给出更有价值的建议。`;

  const user = `## 检测数据概况
时间范围：${snapshot.rangeLabel || '未知'}
生成时间：${snapshot.generatedAt || new Date().toISOString()}

### 总体统计
- 总检测数：${total}条
- 正常标签：${normal}条 (${((normal/total)*100).toFixed(1)}%)
- 缺陷标签：${defect}条 (${defectRate}%)
- 缺陷类型分布：${defectTypes.length > 0 ? defectTypes.join('、') : '无'}

### 产线分布
${lines || '无数据'}

### 能效等级分布
${energyDistribution || '无数据'}

### 最近检测记录（${records.length}条）
${recentRecords || '无记录'}

## 输出要求
请先联网搜索以下内容：
1. 最新的能效标签管理办法法规更新
2. 2024-2025年家电能效检测最新标准
3. 能效标签检测行业最新技术动态
4. 国内外家电能效标识最新要求

然后根据以上真实数据和搜索到的最新信息，输出以下JSON格式（必须严格JSON格式，不要markdown代码块）：
{
  "title": "详细的报告标题，如'2024年X月X日能效标签检测质量分析报告'",
  "summary": "5-8句详细总结，包括实际数据指标、关键问题、潜在原因分析，以及与最新行业动态的关联",
  "industryNews": "联网搜索到的最新行业动态简述，如'最新《能源效率标识管理办法》规定...'或'2024年能效检测新标准要求...'",
  "keyFindings": [
    "详细发现1：基于数据，如'破损缺陷主要集中在下午时段14:00-16:00，占比XX%，可能原因是操作员疲劳导致检测不仔细。结合最新标准，该时段操作人员应每2小时休息一次'",
    "详细发现2：基于数据，如'产线A的缺陷率最高，达到XX%，其中褶皱缺陷占比XX%，可能与该产线的标签粘贴设备有关。建议检查设备参数是否符合最新能效标签贴标要求'",
    "详细发现3：基于数据，如'能效等级3级占比最高，为XX%，说明中低端产品占比较大。结合最新市场趋势，该等级产品面临更高的能效升级压力'",
    "详细发现4：基于数据，如'操作员张三的检测准确率最高，达到XX%，可以总结其检测经验并推广'",
    "详细发现5：基于数据，如'周二的缺陷率明显高于其他工作日，可能与生产计划安排有关'"
  ],
  "recommendations": [
    "详细建议1：如'建议加强产线A的质检频次，每小时增加一次抽检，重点关注褶皱缺陷，并检查标签粘贴设备的参数设置是否符合最新能效标签贴标规范'",
    "详细建议2：如'建议在下午14:00-16:00时段安排轮换休息，减少操作员疲劳，同时增加一名质检人员进行双重检查。依据最新操作规范，连续工作时间不应超过4小时'",
    "详细建议3：如'考虑为3级能效产品线优化检测精度，调整检测阈值，减少误判。根据最新能效标准，3级能效产品的检测精度要求更高'",
    "详细建议4：如'组织操作员张三分享检测经验，提高团队整体检测水平'",
    "详细建议5：如'调整周二的生产计划，避免在周二安排高复杂度的标签检测任务'"
  ],
  "riskLevel": "low/medium/high",
  "latestRegulations": "简要列出搜索到的最新能效标识相关法规和标准要求"
}`;

  const payload = {
    model: LLM_MODEL,
    messages: [
      { role: 'system', content: system },
      { role: 'user', content: user }
    ],
    temperature: 0.3
  };
  
  // 如果模型支持联网搜索，添加相关参数
  if (LLM_MODEL.includes('qwen') || LLM_MODEL.includes('plus') || LLM_MODEL.includes('turbo')) {
    payload.enable_search = true;
    payload.search_options = {
      search_mode: "high"
    };
  }
  
  return payload;
}

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/api/ml/health', async (req, res) => {
  try {
    const result = await requestML('GET', '/health');
    res.json(result);
  } catch (error) {
    res.status(503).json({
      status: 'offline',
      service: 'energy-label-detection',
      message: error.message
    });
  }
});

app.get('/api/ml/model/info', async (req, res) => {
  try {
    const result = await requestML('GET', '/model/info');
    res.json(result);
  } catch (error) {
    res.status(503).json({
      loaded: false,
      model: 'YOLO11n+CBAM',
      error: error.message
    });
  }
});

app.post('/api/ml/detect', async (req, res) => {
  try {
    const result = await requestML('POST', '/detect', {
      imageBase64: req.body.imageBase64 || '',
      imagePath: req.body.imagePath || '',
      lineId: req.body.lineId || 'lineA',
      realtime: req.body.realtime || false,
      brightness: req.body.brightness || 1.0,
      clarity: req.body.clarity || 1.0,
      applianceType: req.body.applianceType || 'other'
    });
    res.json(result);
  } catch (error) {
    res.status(503).json({ message: error.message });
  }
});

app.post('/api/ml/detect/file', upload.single('file'), async (req, res) => {
  try {
    const imageBase64 = req.file ? `data:image/jpeg;base64,${fs.readFileSync(req.file.path, 'base64')}` : '';
    const result = await requestML('POST', '/detect', {
      imageBase64,
      lineId: req.body.lineId || 'lineA',
      brightness: req.body.brightness || 1.0,
      clarity: req.body.clarity || 1.0,
      applianceType: req.body.applianceType || 'other'
    });
    res.json(result);
  } catch (error) {
    res.status(503).json({ message: error.message });
  } finally {
    if (req.file?.path) {
      fs.promises.unlink(req.file.path).catch(() => {});
    }
  }
});

app.post('/api/ml/ocr', async (req, res) => {
  try {
    const result = await requestML('POST', '/ocr', {
      imageBase64: req.body.imageBase64 || '',
      imagePath: req.body.imagePath || '',
      lineId: req.body.lineId || 'lineA'
    });
    res.json(result);
  } catch (error) {
    res.status(503).json({ message: error.message });
  }
});

app.post('/api/public/detect', async (req, res) => {
  try {
    const result = await requestML('POST', '/detect', {
      imageBase64: req.body.imageBase64 || '',
      imagePath: req.body.imagePath || '',
      lineId: req.body.lineId || 'lineA',
      realtime: req.body.realtime || false,
      brightness: req.body.brightness || 1.0,
      clarity: req.body.clarity || 1.0,
      applianceType: req.body.applianceType || 'other'
    });
    res.json(result);
  } catch (error) {
    res.status(503).json({ message: error.message });
  }
});

app.post('/api/ai/report', async (req, res) => {
  try {
    const payload = buildAnalysisPrompt(req.body || {});
    const result = await requestLLM(payload);
    const content = result.choices?.[0]?.message?.content || '{}';
    let parsed = {};
    try {
      parsed = JSON.parse(content);
    } catch (error) {
      parsed = {
        title: '检测分析报告',
        summary: content,
        keyFindings: [],
        recommendations: [],
        riskLevel: 'medium'
      };
    }

    res.json({
      model: LLM_MODEL,
      providerUrl: LLM_API_URL,
      report: parsed
    });
  } catch (error) {
    res.status(503).json({ message: error.message });
  }
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
  console.log(`ML bridge target: http://${ML_SERVICE_URL}:${ML_SERVICE_PORT}`);
  console.log('公开API接口:');
  console.log('  GET  /api/ml/health');
  console.log('  GET  /api/ml/model/info');
  console.log('  POST /api/ml/detect');
  console.log('  POST /api/ml/ocr');
  console.log('  POST /api/public/detect');
  console.log('  POST /api/ai/report');
  console.log('服务器已启动，使用修改后的代码');
});
