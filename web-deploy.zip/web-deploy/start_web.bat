@echo off
echo ========================================
echo Energy Label System - Web Service
echo ========================================
echo.
echo Starting web service on port 3000...
echo Model service should be available at http://localhost:8080
echo.
echo Open in browser: http://localhost:3000
echo.

node server.js

pause
