@echo off
echo ========================================
echo Energy Label System - Full Startup
echo ========================================
echo.

echo [1/4] Checking Python...
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo Python not found. Please install Python first.
    pause
    exit /b 1
)
echo Python OK
echo.

echo [2/4] Checking Node.js...
node --version >nul 2>&1
if %errorlevel% neq 0 (
    echo Node.js not found. Please install Node.js first.
    pause
    exit /b 1
)
echo Node.js OK
echo.

echo [3/4] Installing dependencies if needed...
if not exist "node_modules" (
    call npm install
)

pip install -r requirements.txt -q
echo.

echo [4/4] Starting services...
start "YOLO Model Service" cmd /k "cd /d %~dp0 && python ml_service.py"
timeout /t 2 /nobreak >nul

echo.
echo Model service: http://localhost:8080
echo Web service:   http://localhost:3000
echo Open http://localhost:3000 in your browser.
echo.

node server.js
