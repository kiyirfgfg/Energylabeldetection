import base64
import io
import json
import os
import sqlite3
import time
import threading
from datetime import datetime
from pathlib import Path
from tempfile import NamedTemporaryFile
from typing import Dict, List, Optional
from zipfile import ZipFile

import uvicorn
from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from PIL import Image
from pydantic import BaseModel


PROJECT_ROOT = Path(__file__).resolve().parent
MODEL_ZIP_PATH = PROJECT_ROOT / "模型.zip"
EXTRACT_ROOT = PROJECT_ROOT / "models" / "zip_yolo_model"
YOLO_CONFIG_DIR = PROJECT_ROOT / "_tmp_ultralytics"
STATE_FILE = EXTRACT_ROOT / "extract_state.json"
DB_PATH = PROJECT_ROOT / "records.db"

MODEL_PORT = 8084
MODEL_HOST = "127.0.0.1"

RECORDS_PER_PAGE = 50

ENERGY_LABELS = {
    "energy_1": "一级能效",
    "energy_2": "二级能效",
    "energy_3": "三级能效",
    "energy_4": "四级能效",
    "energy_5": "五级能效",
}

DEFECT_TYPE_MAP = {
    "defect_damage": "DAMAGE",
    "defect_stain": "STAIN",
    "defect_wrinkle": "WRINKLE",
}

DEFECT_DETAIL_MAP = {
    "NORMAL": "未检测到明显缺陷",
    "DAMAGE": "检测到标签破损或缺口",
    "STAIN": "检测到标签表面污渍",
    "WRINKLE": "检测到标签褶皱",
    "POSITION_DEVIATION": "检测到标签位置偏差",
}

IGNORE_CLASSES = {"anchor_box", "anchor_box1", "anchor_box2", "anchor_box3"}


class DetectRequest(BaseModel):
    imageBase64: Optional[str] = None
    imagePath: Optional[str] = None
    lineId: Optional[str] = None
    realtime: Optional[bool] = False
    brightness: Optional[float] = 1.0
    clarity: Optional[float] = 1.0
    applianceType: Optional[str] = "other"
    positionThreshold: Optional[float] = 100.0
    defectThreshold: Optional[float] = 0.5
    damageThreshold: Optional[float] = 0.5
    stainThreshold: Optional[float] = 0.5
    wrinkleThreshold: Optional[float] = 0.5


class HealthMonitor:
    def __init__(self, runtime, check_interval=60, max_retries=3):
        self.runtime = runtime
        self.check_interval = check_interval
        self.max_retries = max_retries
        self._monitor_thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        self._health_history: List[Dict] = []
        self._retry_count = 0
        self._is_recovering = False
        self._start_monitor()

    def _start_monitor(self):
        if self._monitor_thread is not None and self._monitor_thread.is_alive():
            return
        self._stop_event.clear()
        self._monitor_thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self._monitor_thread.start()

    def _stop_monitor(self):
        self._stop_event.set()
        if self._monitor_thread is not None:
            self._monitor_thread.join(timeout=5)

    def _monitor_loop(self):
        while not self._stop_event.is_set():
            try:
                self._stop_event.wait(self.check_interval)
                if self._stop_event.is_set():
                    break

                health = self.runtime.health()
                timestamp = datetime.now().isoformat()

                health_record = {
                    "timestamp": timestamp,
                    "available": health["available"],
                    "status": health["status"],
                    "message": health["message"],
                }
                self._health_history.append(health_record)

                if len(self._health_history) > 100:
                    self._health_history.pop(0)

                if not health["available"] and not self._is_recovering:
                    self._attempt_recovery()

            except Exception as e:
                print(f"[HealthMonitor] Error in monitor loop: {e}")

    def _attempt_recovery(self):
        self._is_recovering = True
        print(f"[HealthMonitor] Model unavailable, attempting recovery (attempt {self._retry_count + 1}/{self.max_retries})")

        for attempt in range(self.max_retries):
            try:
                print(f"[HealthMonitor] Recovery attempt {attempt + 1}/{self.max_retries}...")

                self.runtime._setup()

                if self.runtime.model is not None:
                    print("[HealthMonitor] Recovery successful!")
                    self._retry_count = 0
                    self._is_recovering = False
                    return

            except Exception as e:
                print(f"[HealthMonitor] Recovery attempt {attempt + 1} failed: {e}")
                time.sleep(10)

        print("[HealthMonitor] All recovery attempts failed")
        self._is_recovering = False
        self._retry_count += 1

    def get_health_history(self, limit=10) -> List[Dict]:
        return self._health_history[-limit:]

    def get_status_summary(self) -> Dict:
        recent = self._health_history[-10:] if self._health_history else []
        available_count = sum(1 for h in recent if h["available"])
        return {
            "monitoring_active": self._monitor_thread is not None and self._monitor_thread.is_alive(),
            "is_recovering": self._is_recovering,
            "retry_count": self._retry_count,
            "recent_availability": f"{available_count}/{len(recent)}" if recent else "N/A",
            "last_check": recent[-1]["timestamp"] if recent else None,
        }


class ZipYoloRuntime:
    def __init__(self):
        self.model_zip_path = MODEL_ZIP_PATH
        self.extract_root = EXTRACT_ROOT
        self.yolo_dir: Optional[Path] = None
        self.weights_path: Optional[Path] = None
        self.args_path: Optional[Path] = None
        self.model = None
        self.names: Dict[int, str] = {}
        self.status = "offline"
        self.message = ""
        self.last_error: Optional[str] = None
        self._setup()

    def _setup(self):
        try:
            # 尝试从模型.zip加载
            try:
                self.yolo_dir = self._extract_from_zip()
                self.weights_path = next(self.yolo_dir.rglob("best.pt"))
                args_candidates = list(self.yolo_dir.rglob("args.yaml"))
                self.args_path = args_candidates[0] if args_candidates else None
            except FileNotFoundError:
                # 模型.zip不存在，尝试从已解压的目录加载
                print("[INFO] 模型.zip不存在，尝试从已解压目录加载模型")
                extract_dirs = [
                    Path("models/zip_yolo_model/weights"),  # 优先使用这个有效的模型
                    Path("_tmp_extract/b/AF-CLIP-main-b"),
                    Path("_tmp_model_check/模型"),
                    Path("_tmp_zip_check/模型"),
                    Path("_tmp_modelzip/outer/模型")
                ]
                
                found = False
                for extract_dir in extract_dirs:
                    if extract_dir.exists():
                        weights_candidates = list(extract_dir.rglob("best.pt"))
                        if weights_candidates:
                            self.weights_path = weights_candidates[0]
                            self.yolo_dir = self.weights_path.parent
                            args_candidates = list(self.yolo_dir.rglob("args.yaml"))
                            self.args_path = args_candidates[0] if args_candidates else None
                            print(f"[INFO] 从已解压目录加载模型: {self.weights_path}")
                            found = True
                            break
                
                if not found:
                    raise FileNotFoundError("未找到模型文件，请确保模型已解压")

            os.environ["YOLO_CONFIG_DIR"] = str(YOLO_CONFIG_DIR)
            YOLO_CONFIG_DIR.mkdir(parents=True, exist_ok=True)

            from ultralytics import YOLO

            self.model = YOLO(str(self.weights_path))
            self.names = dict(self.model.names)
            self.status = "ready"
            self.message = "已加载 YOLO 模型"
            self.last_error = None
        except Exception as exc:
            self.model = None
            self.names = {}
            self.status = "offline"
            self.last_error = str(exc)
            self.message = f"模型加载失败: {exc}"

    def reload(self):
        self._setup()

    def _current_zip_state(self) -> Dict[str, object]:
        stat = self.model_zip_path.stat()
        return {
            "size": stat.st_size,
            "mtime_ns": stat.st_mtime_ns,
        }

    def _is_extract_fresh(self, yolo_root: Path) -> bool:
        if not STATE_FILE.exists() or not yolo_root.exists():
            return False
        try:
            saved = json.loads(STATE_FILE.read_text(encoding="utf-8"))
        except Exception:
            return False
        return saved == self._current_zip_state()

    def _clear_extract_root(self):
        if not self.extract_root.exists():
            return
        for child in sorted(self.extract_root.rglob("*"), reverse=True):
            if child.is_file():
                child.unlink()
            elif child.is_dir():
                child.rmdir()

    def _extract_from_zip(self) -> Path:
        self.extract_root.mkdir(parents=True, exist_ok=True)
        
        if self.model_zip_path.exists():
            self._clear_extract_root()
            self.extract_root.mkdir(parents=True, exist_ok=True)

            with ZipFile(self.model_zip_path) as outer_zip:
                outer_files = outer_zip.namelist()
                print(f"[DEBUG] 模型.zip 内容: {outer_files}")
                
                # 寻找内部的zip文件
                nested_names = [name for name in outer_files if name.endswith(".zip")]
                if not nested_names:
                    raise FileNotFoundError("模型.zip 中未找到内部zip文件")
                
                # 使用找到的第一个zip文件
                nested_name = nested_names[0]
                print(f"[DEBUG] 使用内部zip文件: {nested_name}")
                nested_bytes = io.BytesIO(outer_zip.read(nested_name))

            with ZipFile(nested_bytes) as nested_zip:
                nested_zip.extractall(self.extract_root)

            # 找到实际的yolo目录
            yolo_dirs = list(self.extract_root.rglob("best.pt"))
            if not yolo_dirs:
                raise FileNotFoundError("解压后未找到 best.pt")
            
            actual_yolo_root = yolo_dirs[0].parent
            print(f"[DEBUG] 实际模型目录: {actual_yolo_root}")
            return actual_yolo_root
        else:
            raise FileNotFoundError(f"未找到模型压缩包: {self.model_zip_path}")

    def health(self) -> Dict[str, object]:
        return {
            "available": self.model is not None,
            "status": self.status,
            "message": self.message,
            "lastError": self.last_error,
            "modelZipPath": str(self.model_zip_path),
            "weightsPath": str(self.weights_path) if self.weights_path else "",
            "extractRoot": str(self.extract_root),
            "classNames": self.names,
            "ultralytics_available": self._check_ultralytics(),
        }

    def _check_ultralytics(self) -> bool:
        try:
            import ultralytics
            return True
        except ImportError:
            return False

    def _decode_image(self, image_base64: str) -> Image.Image:
        payload = image_base64.split(",", 1)[-1]
        return Image.open(io.BytesIO(base64.b64decode(payload))).convert("RGB")

    def _predict(self, image_base64: str, brightness: float = 1.0, clarity: float = 1.0):
        if self.model is None:
            raise RuntimeError(self.message or "YOLO model is unavailable")

        image = self._decode_image(image_base64)

        if brightness != 1.0 or clarity != 1.0:
            from PIL import ImageEnhance
            if brightness != 1.0:
                enhancer = ImageEnhance.Brightness(image)
                image = enhancer.enhance(brightness)
            if clarity != 1.0:
                enhancer = ImageEnhance.Contrast(image)
                image = enhancer.enhance(clarity)

        with NamedTemporaryFile(suffix=".jpg", delete=False) as tmp:
            temp_path = Path(tmp.name)
            image.save(temp_path, format="JPEG", quality=95)

        try:
            results = self.model.predict(source=str(temp_path), verbose=False, imgsz=640, conf=0.05)  # 降低模型内部阈值
            return results[0]
        finally:
            try:
                temp_path.unlink()
            except OSError:
                pass

    def _serialize_detections(self, result) -> List[Dict[str, object]]:
        boxes = getattr(result, "boxes", None)
        if boxes is None or boxes.cls is None or len(boxes) == 0:
            return []

        detections = []
        for cls_id, conf, xyxy in zip(boxes.cls.tolist(), boxes.conf.tolist(), boxes.xyxy.tolist()):
            class_name = self.names.get(int(cls_id), str(int(cls_id)))
            detections.append(
                {
                    "classId": int(cls_id),
                    "className": class_name,
                    "confidence": round(float(conf), 4),
                    "bbox": [round(float(value), 2) for value in xyxy],
                }
            )

        detections.sort(key=lambda item: item["confidence"], reverse=True)
        return detections

    def infer(self, image_base64: str, brightness: float = 1.0, clarity: float = 1.0, applianceType: str = "other", positionThreshold: float = 100.0, defectThreshold: float = 0.5, damageThreshold: float = 0.5, stainThreshold: float = 0.5, wrinkleThreshold: float = 0.5) -> Dict[str, object]:
        result = self._predict(image_base64, brightness, clarity)
        detections = self._serialize_detections(result)

        defect_threshold_map = {
            "defect_damage": damageThreshold,
            "defect_stain": stainThreshold,
            "defect_wrinkle": wrinkleThreshold,
        }

        defect_detections_filtered = []
        for det in detections:
            if det["className"] in defect_threshold_map:
                if det["confidence"] >= defect_threshold_map[det["className"]]:
                    defect_detections_filtered.append(det)
            elif det["className"] in ENERGY_LABELS or det["className"] == "energy_label":
                if det["confidence"] >= defectThreshold:
                    defect_detections_filtered.append(det)

        filtered_detections = defect_detections_filtered
        
        # 调试：打印模型类别和检测结果
        print(f"[DEBUG] 模型类别: {self.names}")
        print(f"[DEBUG] 所有检测结果: {detections}")
        print(f"[DEBUG] 过滤后检测结果: {filtered_detections}")
        
        # 优先选择 energy_label（整个标签），然后选择1-5级能效，最后选择其他能量标签
        energy_detection = next((item for item in filtered_detections if item["className"] == "energy_label"), None)
        # 如果没有整个标签的检测结果，选择1-5级能效
        if not energy_detection:
            energy_detection = next((item for item in filtered_detections if item["className"] in ["energy_1", "energy_2", "energy_3", "energy_4", "energy_5"]), None)
        # 如果没有1-5级能效的检测结果，再检查其他能量标签
        if not energy_detection:
            energy_detection = next((item for item in filtered_detections if item["className"] in ENERGY_LABELS), None)
        
        print(f"[DEBUG] 选中的能量检测: {energy_detection}")
        
        all_defect_detections = [item for item in filtered_detections if item["className"] in DEFECT_TYPE_MAP]
        useful_detections = [item for item in filtered_detections if item["className"] not in IGNORE_CLASSES]

        # 计算label_level - 优先从检测结果中找到能效等级（energy_1到energy_5）
        energy_level_detection = next((item for item in filtered_detections if item["className"] in ["energy_1", "energy_2", "energy_3", "energy_4", "energy_5"]), None)
        if energy_level_detection:
            label_level = ENERGY_LABELS.get(energy_level_detection["className"], "未识别")
        elif energy_detection:
            label_level = ENERGY_LABELS.get(energy_detection["className"], "未识别")
        else:
            label_level = "未识别"
        print(f"[DEBUG] 最终label_level: {label_level}")

        final_defect_types = []
        final_deviationDirection = ""
        final_deviationValue = ""
        final_deviationArea = ""
        max_confidence = 0.0

        for defect_det in all_defect_detections:
            defect_type = DEFECT_TYPE_MAP.get(defect_det["className"], None)
            if defect_type and defect_type not in final_defect_types:
                final_defect_types.append(defect_type)
            if defect_det["confidence"] > max_confidence:
                max_confidence = defect_det["confidence"]

        if energy_detection and energy_detection["confidence"] > max_confidence:
            max_confidence = energy_detection["confidence"]

        # 位置偏差检测 - 优先使用energy_label（整个标签）的位置
        energy_label_detection = next((item for item in filtered_detections if item["className"] == "energy_label"), None)
        position_detection = energy_label_detection if energy_label_detection else energy_detection

        if position_detection is not None:
            bbox = position_detection["bbox"]
            x1, y1, x2, y2 = bbox
            label_width = x2 - x1
            label_height = y2 - y1
            label_area = label_width * label_height
            image = self._decode_image(image_base64)
            image_width, image_height = image.size
            aspect_ratio = label_width / label_height if label_height > 0 else 0

            min_detectable_area = image_width * image_height * 0.005
            max_allowed_area = image_width * image_height * 0.8
            is_valid_detection = (
                label_area >= min_detectable_area and
                label_area <= max_allowed_area and
                aspect_ratio >= 0.3 and
                aspect_ratio <= 5.0
            )

            if not is_valid_detection and energy_detection != position_detection:
                # 如果energy_label无效，尝试使用energy_detection
                position_detection = energy_detection
                bbox = position_detection["bbox"]
                x1, y1, x2, y2 = bbox
                label_width = x2 - x1
                label_height = y2 - y1
                label_area = label_width * label_height
                aspect_ratio = label_width / label_height if label_height > 0 else 0
                is_valid_detection = (
                    label_area >= min_detectable_area and
                    label_area <= max_allowed_area and
                    aspect_ratio >= 0.3 and
                    aspect_ratio <= 5.0
                )

            if is_valid_detection:
                target_center_x = (x1 + x2) / 2
                target_center_y = (y1 + y2) / 2
                image_center_x = image_width / 2
                image_center_y = image_height / 2

                dx = target_center_x - image_center_x
                dy = target_center_y - image_center_y
                distance = (dx**2 + dy**2)**0.5

                reference_span = max(min(label_width, label_height), 1.0)
                relative_threshold = min(image_width, image_height) * 0.08
                min_threshold = reference_span * 0.12
                threshold = max(min_threshold, relative_threshold, positionThreshold)

                if distance > threshold:
                    if abs(dx) > abs(dy):
                        final_deviationDirection = "右" if dx > 0 else "左"
                    else:
                        final_deviationDirection = "下" if dy > 0 else "上"

                    deviation_pixels = distance
                    deviation_percent = (distance / reference_span) * 100

                    if final_deviationDirection in ["左", "右"]:
                        final_deviationArea = "水平方向"
                    else:
                        final_deviationArea = "垂直方向"

                    final_deviationValue = f"{deviation_pixels:.1f}px ({deviation_percent:.1f}%)"

                    if "POSITION_DEVIATION" not in final_defect_types:
                        final_defect_types.append("POSITION_DEVIATION")

        if energy_detection is None:
            if not all_defect_detections:
                final_defect_types = []
                final_deviationDirection = ""
                final_deviationValue = ""
                final_deviationArea = ""
            # 即使没有能效标签，如果有缺陷检测，也保留缺陷类型

        if not final_defect_types:
            final_defect_types = ["NORMAL"]

        final_defect_type = final_defect_types[0] if final_defect_types else "NORMAL"
        final_defect_details = [DEFECT_DETAIL_MAP.get(dt, "未知缺陷") for dt in final_defect_types]
        final_defect_detail = "；".join(final_defect_details) if len(final_defect_details) > 1 else (final_defect_details[0] if final_defect_details else DEFECT_DETAIL_MAP.get(final_defect_type, "检测完成"))

        confidence_candidates = [item["confidence"] for item in (energy_detection,) + tuple(all_defect_detections) if item]
        if not confidence_candidates and useful_detections:
            confidence_candidates.append(useful_detections[0]["confidence"])
        confidence = max(confidence_candidates) if confidence_candidates else 0.0

        warnings = []
        if not detections:
            warnings.append("未检测到任何目标")
        elif not useful_detections:
            warnings.append("只检测到辅助框，未识别到能效等级或缺陷")
        elif not energy_detection:
            warnings.append("未检测到明确的能效等级目标")

        return {
            "labelLevel": label_level,
            "defectType": final_defect_type,
            "defectTypes": final_defect_types,
            "defectDetail": final_defect_detail,
            "defectDetails": final_defect_details,
            "deviationDirection": final_deviationDirection,
            "deviationValue": final_deviationValue,
            "deviationArea": final_deviationArea,
            "confidence": round(float(confidence), 4),
            "warning": "；".join(warnings),
            "modelMode": "yolo11n_cbam_from_zip",
            "modelVersion": "YOLO11n+CBAM-geli",
            "modelUsed": "模型.zip / yolo11n+CBAM_geli",
            "rawResult": {
                "classNames": self.names,
                "detections": detections,
                "energyDetection": energy_detection,
                "defectDetections": all_defect_detections,
            },
        }

    def ocr(self, image_base64: str) -> Dict[str, object]:
        inference = self.infer(image_base64)
        level_text = inference["labelLevel"]
        if level_text == "未识别":
            text = "未识别到明确能效等级"
        else:
            text = f"识别结果：{level_text}标签"
        return {
            "message": "OCR识别完成",
            "text": text,
            "score": inference["confidence"],
            "fromModel": "yolo11n_cbam_from_zip",
            "rawResult": inference["rawResult"],
        }


app = FastAPI(title="Energy Label ML Service", version="2.2.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

runtime = ZipYoloRuntime()
health_monitor = None


def ensure_runtime():
    if runtime.model is None:
        raise HTTPException(status_code=503, detail=runtime.message)


def image_path_to_data_url(image_path: str) -> str:
    path = Path(image_path)
    if not path.exists():
        raise HTTPException(status_code=400, detail="图片路径不存在")

    with Image.open(path).convert("RGB") as image:
        buffer = io.BytesIO()
        image.save(buffer, format="JPEG", quality=95)

    encoded = base64.b64encode(buffer.getvalue()).decode("utf-8")
    return f"data:image/jpeg;base64,{encoded}"


def resolve_image(req: DetectRequest) -> str:
    if req.imageBase64:
        return req.imageBase64
    if req.imagePath:
        return image_path_to_data_url(req.imagePath)
    raise HTTPException(status_code=400, detail="imageBase64 或 imagePath 不能为空")


def decorate_result(result: Dict[str, object], line_id: Optional[str], started_at: float) -> Dict[str, object]:
    payload = dict(result)
    payload["time"] = datetime.now().isoformat()
    payload["processTime"] = round(time.perf_counter() - started_at, 3)
    payload["lineId"] = line_id or "lineA"
    return payload


def init_database():
    conn = sqlite3.connect(str(DB_PATH))
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            record_id TEXT UNIQUE,
            product_id TEXT,
            operator TEXT,
            operator_name TEXT,
            line_id TEXT,
            label_level TEXT,
            defect_type TEXT,
            defect_types TEXT,
            defect_detail TEXT,
            defect_details TEXT,
            confidence REAL,
            time TEXT,
            processed INTEGER DEFAULT 0,
            appliance_type TEXT,
            image_data TEXT,
            original_image_data TEXT,
            deviation_area TEXT,
            deviation_direction TEXT,
            deviation_value TEXT,
            warning TEXT,
            raw_result TEXT
        )
    """)
    conn.commit()
    conn.close()
    print(f"[Database] Initialized at {DB_PATH}")


def save_record_to_db(record: Dict) -> bool:
    try:
        conn = sqlite3.connect(str(DB_PATH))
        cursor = conn.cursor()
        cursor.execute("""
            INSERT OR REPLACE INTO records (
                record_id, product_id, operator, operator_name, line_id,
                label_level, defect_type, defect_types, defect_detail,
                defect_details, confidence, time, processed, appliance_type,
                image_data, original_image_data, deviation_area,
                deviation_direction, deviation_value, warning, raw_result
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            record.get("id"),
            record.get("productId"),
            record.get("operator"),
            record.get("operatorName"),
            record.get("lineId"),
            record.get("labelLevel"),
            record.get("defectType"),
            json.dumps(record.get("defectTypes", [])),
            record.get("defectDetail"),
            json.dumps(record.get("defectDetails", [])),
            record.get("confidence"),
            record.get("time"),
            1 if record.get("processed") else 0,
            record.get("applianceType"),
            record.get("imageData"),
            record.get("originalImageData"),
            record.get("deviationArea"),
            record.get("deviationDirection"),
            record.get("deviationValue"),
            record.get("warning"),
            json.dumps(record.get("rawResult", {}))
        ))
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        print(f"[Database] Error saving record: {e}")
        return False


def get_records_from_db(page: int = 1, limit: int = RECORDS_PER_PAGE, operator: str = None, line_id: str = None) -> Dict:
    try:
        conn = sqlite3.connect(str(DB_PATH))
        cursor = conn.cursor()

        where_clauses = []
        params = []
        if operator:
            where_clauses.append("operator = ?")
            params.append(operator)
        if line_id:
            where_clauses.append("line_id = ?")
            params.append(line_id)

        where_sql = " AND ".join(where_clauses) if where_clauses else "1=1"

        cursor.execute(f"SELECT COUNT(*) FROM records WHERE {where_sql}", params)
        total = cursor.fetchone()[0]

        offset = (page - 1) * limit
        cursor.execute(f"""
            SELECT record_id, product_id, operator, operator_name, line_id,
                   label_level, defect_type, defect_types, defect_detail,
                   defect_details, confidence, time, processed, appliance_type,
                   image_data, original_image_data, deviation_area,
                   deviation_direction, deviation_value, warning
            FROM records
            WHERE {where_sql}
            ORDER BY time DESC
            LIMIT ? OFFSET ?
        """, params + [limit, offset])

        rows = cursor.fetchall()
        conn.close()

        records = []
        for row in rows:
            records.append({
                "id": row[0],
                "productId": row[1],
                "operator": row[2],
                "operatorName": row[3],
                "lineId": row[4],
                "labelLevel": row[5],
                "defectType": row[6],
                "defectTypes": json.loads(row[7]) if row[7] else [],
                "defectDetail": row[8],
                "defectDetails": json.loads(row[9]) if row[9] else [],
                "confidence": row[10],
                "time": row[11],
                "processed": bool(row[12]),
                "applianceType": row[13],
                "imageData": row[14],
                "originalImageData": row[15],
                "deviationArea": row[16],
                "deviationDirection": row[17],
                "deviationValue": row[18],
                "warning": row[19]
            })

        return {
            "records": records,
            "page": page,
            "limit": limit,
            "total": total,
            "totalPages": (total + limit - 1) // limit
        }
    except Exception as e:
        print(f"[Database] Error getting records: {e}")
        return {"records": [], "page": page, "limit": limit, "total": 0, "totalPages": 0}


@app.on_event("startup")
async def startup_event():
    global health_monitor
    init_database()
    health_monitor = HealthMonitor(runtime, check_interval=30, max_retries=3)
    print("[Startup] Health monitoring started")


@app.on_event("shutdown")
async def shutdown_event():
    if health_monitor:
        health_monitor._stop_monitor()
    print("[Shutdown] Health monitoring stopped")


@app.get("/health")
def health_check():
    health = runtime.health()
    monitor_status = health_monitor.get_status_summary() if health_monitor else {}

    overall_status = "ready" if health["available"] else "offline"
    if health_monitor and health_monitor._is_recovering:
        overall_status = "recovering"

    return {
        "status": overall_status,
        "service": "energy-label-detection",
        "version": "2.2.0",
        "model": "YOLO11n+CBAM",
        "modelLoaded": health["available"],
        "loaded": health["available"],
        "device": "auto",
        "mode": "zip_yolo_runtime",
        "message": health["message"],
        "lastError": health["lastError"],
        "modelZipPath": health["modelZipPath"],
        "weightsPath": health["weightsPath"],
        "monitor": monitor_status,
    }


@app.get("/health/history")
def health_history(limit: int = 10):
    if health_monitor is None:
        raise HTTPException(status_code=503, detail="Health monitor not available")
    return {
        "history": health_monitor.get_health_history(limit),
        "summary": health_monitor.get_status_summary(),
    }


@app.post("/health/reload")
def reload_model():
    global health_monitor
    try:
        if health_monitor:
            health_monitor._stop_monitor()

        runtime.reload()

        if health_monitor:
            health_monitor._start_monitor()

        return {
            "status": "success",
            "message": "Model reloaded successfully" if runtime.model else "Model reload failed",
            "available": runtime.model is not None,
        }
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Reload failed: {exc}")


@app.get("/model/info")
@app.post("/model/info")
def model_info():
    health = runtime.health()
    return {
        "model": "YOLO11n+CBAM",
        "baseModel": "模型.zip / yolo11n+CBAM_geli",
        "device": "auto",
        "loaded": health["available"],
        "modelZipPath": health["modelZipPath"],
        "weightsPath": health["weightsPath"],
        "extractRoot": health["extractRoot"],
        "classNames": health["classNames"],
        "defectTypes": ["NORMAL", "DAMAGE", "STAIN", "WRINKLE", "POSITION_DEVIATION"],
        "energyClasses": list(ENERGY_LABELS.values()),
        "lastError": health["lastError"],
        "ultralyticsAvailable": health["ultralytics_available"],
    }


@app.post("/detect")
def detect(req: DetectRequest):
    ensure_runtime()
    started_at = time.perf_counter()
    try:
        image_data = resolve_image(req)
        result = runtime.infer(image_data, req.brightness, req.clarity, req.applianceType, req.positionThreshold, req.defectThreshold, req.damageThreshold, req.stainThreshold, req.wrinkleThreshold)
        return decorate_result(result, req.lineId, started_at)
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"模型推理失败: {exc}") from exc


@app.post("/detect/file")
async def detect_file(file: UploadFile = File(...), lineId: str = Form("lineA")):
    ensure_runtime()
    started_at = time.perf_counter()
    try:
        contents = await file.read()
        encoded = base64.b64encode(contents).decode("utf-8")
        image_data = f"data:{file.content_type or 'image/jpeg'};base64,{encoded}"
        result = runtime.infer(image_data)
        return decorate_result(result, lineId, started_at)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"文件推理失败: {exc}") from exc


@app.post("/ocr")
def ocr(req: DetectRequest):
    ensure_runtime()
    try:
        image_data = resolve_image(req)
        payload = runtime.ocr(image_data)
        payload["time"] = datetime.now().isoformat()
        return payload
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"OCR失败: {exc}") from exc


class RecordRequest(BaseModel):
    id: Optional[int] = None
    productId: Optional[str] = None
    operator: Optional[str] = None
    operatorName: Optional[str] = None
    lineId: Optional[str] = None
    labelLevel: Optional[str] = None
    defectType: Optional[str] = None
    defectTypes: Optional[List[str]] = None
    defectDetail: Optional[str] = None
    defectDetails: Optional[List[str]] = None
    confidence: Optional[float] = None
    time: Optional[str] = None
    processed: Optional[bool] = False
    applianceType: Optional[str] = None
    imageData: Optional[str] = None
    originalImageData: Optional[str] = None
    deviationArea: Optional[str] = None
    deviationDirection: Optional[str] = None
    deviationValue: Optional[str] = None
    warning: Optional[str] = None
    rawResult: Optional[Dict] = None


@app.post("/records")
def save_record(req: RecordRequest):
    record = req.dict() if hasattr(req, 'dict') else vars(req)
    success = save_record_to_db(record)
    if success:
        return {"status": "success", "message": "Record saved successfully"}
    else:
        raise HTTPException(status_code=500, detail="Failed to save record")


@app.get("/records")
def get_records(page: int = 1, limit: int = RECORDS_PER_PAGE, operator: str = None, lineId: str = None):
    result = get_records_from_db(page, limit, operator, lineId)
    return result


@app.get("/records/count")
def get_records_count():
    try:
        conn = sqlite3.connect(str(DB_PATH))
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM records")
        count = cursor.fetchone()[0]
        conn.close()
        return {"count": count}
    except Exception as e:
        print(f"[Database] Error getting count: {e}")
        return {"count": 0}


@app.delete("/records/{record_id}")
def delete_record(record_id: str):
    try:
        conn = sqlite3.connect(str(DB_PATH))
        cursor = conn.cursor()
        cursor.execute("DELETE FROM records WHERE record_id = ?", (record_id,))
        conn.commit()
        deleted = cursor.rowcount > 0
        conn.close()
        if deleted:
            return {"status": "success", "message": "Record deleted"}
        else:
            raise HTTPException(status_code=404, detail="Record not found")
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to delete record: {e}")


@app.get("/test")
def test():
    return health_check()


@app.get("/test/detect")
def test_detect():
    sample = (
        "data:image/png;base64,"
        "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg=="
    )
    return detect(DetectRequest(imageBase64=sample, lineId="lineA"))


if __name__ == "__main__":
    uvicorn.run(app, host=MODEL_HOST, port=MODEL_PORT)
